#!/system/bin/sh

echo ""
echo "[ARISE] Restoring default values..."
echo ""

settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale

settings delete system pointer_speed

setprop debug.hwui.renderer ""
setprop debug.performance.tuning ""

echo "[ARISE] Cleanup completed"
echo ""