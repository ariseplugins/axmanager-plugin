#!/system/bin/sh

MODDIR=${0%/*}

sleep 15

echo "[ARISE] Starting boot service..."

# wait a bit for system to fully settle
sleep 5

# keep UI responsive
settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.4

# touch responsiveness (safe feel improvement)
settings put system pointer_speed 7

# rendering preference hint
setprop debug.hwui.renderer skiagl

# performance tuning hint
setprop debug.performance.tuning 1

# reduce background pressure (light level only)
cmd activity set-process-limit 3

# ensure settings re-apply after minor system reset behavior
sleep 2

settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.4

echo "[ARISE] Service active"