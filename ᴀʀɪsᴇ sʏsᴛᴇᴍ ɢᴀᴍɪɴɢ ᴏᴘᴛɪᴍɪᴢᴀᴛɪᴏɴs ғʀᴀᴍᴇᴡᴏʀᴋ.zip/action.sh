#!/system/bin/sh

MODDIR=${0%/*}

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "      ARISE PERFORMANCE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

sleep 1

echo "[*] Applying gaming profile..."

# animation responsiveness
settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.4

# touch feel
settings put system pointer_speed 7

# rendering preference
setprop debug.hwui.renderer skiagl

# performance hint
setprop debug.performance.tuning 1

# lightweight multitasking
cmd activity set-process-limit 2

sleep 1

echo ""
echo "[✓] Gaming profile applied"
echo ""