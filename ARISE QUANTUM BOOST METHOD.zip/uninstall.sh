#!/system/bin/sh
# uninstall.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
Z="\033[0m"

clear

echo -e "${C}"
echo "████████████████████████████████████████"
echo "          BOOST RESET ENGINE"
echo "████████████████████████████████████████"
echo -e "${Z}"

sleep 1

echo ""
echo -e "${Y}[ RESET ] restoring standby behavior${Z}"

settings put global app_standby_enabled 1
settings put global settings_enable_monitor_phantom_procs true

sleep 1

echo -e "${Y}[ RESET ] restoring refresh rate${Z}"

settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60

sleep 1

echo -e "${Y}[ RESET ] restoring renderer values${Z}"

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_hint_manager false

sleep 1

echo -e "${Y}[ RESET ] restoring game overlays${Z}"

device_config delete game_overlay com.garena.game.codm
device_config delete game_overlay com.tencent.ig
device_config delete game_overlay com.dts.freefireth
device_config delete game_overlay com.mobile.legends
device_config delete game_overlay com.netease.newspike

sleep 1

echo -e "${Y}[ RESET ] enabling idle restrictions${Z}"

cmd deviceidle enable

sleep 1

echo -e "${Y}[ RESET ] cleaning runtime cache${Z}"

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sleep 1

echo ""
echo -e "${R}◆ QUANTUM BOOST METHOD REMOVED${Z}"
echo ""