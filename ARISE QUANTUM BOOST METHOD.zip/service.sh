#!/system/bin/sh
# service.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
W="\033[1;37m"
D="\033[90m"
Z="\033[0m"

log() {
echo -e "${C}[ BOOST METHOD ]${Z} $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 2
done

sleep 15

RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)

clear

echo -e "${C}"
echo "████████████████████████████████████████████"
echo "          QUANTUM BOOST RUNTIME"
echo "████████████████████████████████████████████"
echo -e "${Z}"

echo ""

if [ "$RAM" -ge 10000000 ]; then
PROFILE="ULTRA COMPETITIVE"
FPS="144"
DOWN="0.85"

elif [ "$RAM" -ge 8000000 ]; then
PROFILE="HIGH PERFORMANCE"
FPS="120"
DOWN="0.78"

elif [ "$RAM" -ge 6000000 ]; then
PROFILE="BALANCED PERFORMANCE"
FPS="90"
DOWN="0.72"

else
PROFILE="STABLE PERFORMANCE"
FPS="60"
DOWN="0.65"
fi

echo -e "${G}[ PROFILE ]${Z} $PROFILE"
echo -e "${G}[ FPS ]${Z} $FPS"
echo -e "${G}[ DOWNSCALE ]${Z} $DOWN"

echo ""

settings put system peak_refresh_rate $FPS
settings put system min_refresh_rate 60

for game in \
com.garena.game.codm \
com.tencent.ig \
com.dts.freefireth \
com.mobile.legends \
com.netease.newspike
do

if pm list packages | grep -q "$game"; then

echo ""
echo -e "${R}◆ GAME DETECTED : $game${Z}"

device_config put game_overlay \
"$game" \
mode=2,downscaleFactor=$DOWN,fps=$FPS

cmd game mode performance "$game" 2>/dev/null

pid=$(pidof "$game")

if [ -n "$pid" ]; then
renice -n -10 -p "$pid"
fi

echo -e "${G}[ FPS ENGINE ] synchronized${Z}"
echo -e "${G}[ BOOST MODE ] enabled${Z}"
echo -e "${G}[ DOWNSCALE ] active${Z}"
echo -e "${G}[ TOUCH ] optimized${Z}"

fi

done

log "cleaning runtime cache"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "runtime boost active"

echo ""
echo -e "${R}▓▒░ QUANTUM BOOST METHOD ACTIVE ░▒▓${Z}"
echo ""