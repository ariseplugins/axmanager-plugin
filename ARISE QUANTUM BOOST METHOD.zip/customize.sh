#!/system/bin/sh
# customize.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
W="\033[1;37m"
D="\033[90m"
Z="\033[0m"

clear

DATE=$(date)
MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')

echo -e "${C}"
echo "████████████████████████████████████████████████"
echo "            QUANTUM BOOST METHOD"
echo "               VIP BOOST EDITION"
echo "████████████████████████████████████████████████"
echo -e "${Z}"

sleep 1

echo ""
echo -e "${G}[ DATE ]${Z} $DATE"
echo -e "${G}[ MODEL ]${Z} $MODEL"
echo -e "${G}[ ANDROID ]${Z} $ANDROID"
echo -e "${G}[ RAM ]${Z} $RAM KB"

echo ""
echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

echo -e "${D}[ BOOST ] preparing aggressive runtime${Z}"
sleep 1
echo -e "${D}[ FPS ] preparing profile switch engine${Z}"
sleep 1
echo -e "${D}[ MEMORY ] preparing runtime cleaner${Z}"
sleep 1
echo -e "${D}[ GAMING ] scanning installed games${Z}"
sleep 1
echo -e "${D}[ SYSTEM ] preparing competitive mode${Z}"
sleep 1

echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

echo ""
echo -e "${G}▓▒░ BOOST METHOD INSTALLED ░▒▓${Z}"
echo ""