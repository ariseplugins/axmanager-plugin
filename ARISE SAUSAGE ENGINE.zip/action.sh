#!/system/bin/sh

# =========================================
# ARISE SAUSAGE MAN OPTIMIZER ENGINE V2
# =========================================

LOG="[ARISE-SAUSAGE-V2]"

echo "$LOG INITIALIZING..."

sleep 0.5

# =========================
# DEVICE INFO
# =========================

MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

echo "$LOG DEVICE: $MODEL"
echo "$LOG ANDROID: $ANDROID"

# =========================
# UI SMOOTHNESS
# =========================

echo "$LOG APPLYING UI SMOOTHNESS..."

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# =========================
# PERFORMANCE CORE
# =========================

echo "$LOG PERFORMANCE CORE..."

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

# =========================
# FRAME PACING CONTROL
# =========================

echo "$LOG FRAME PACING..."

setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 1 > /dev/null 2>&1
setprop debug.sf.frame_rate_multiple_threshold 120 > /dev/null 2>&1

# =========================
# INPUT LATENCY REDUCTION
# =========================

echo "$LOG INPUT RESPONSE..."

setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1
setprop debug.input.velocitytracker.strategy impulse > /dev/null 2>&1

# =========================
# CPU LOAD STABILITY
# =========================

echo "$LOG CPU STABILITY..."

setprop debug.cpuprio 1 > /dev/null 2>&1

# =========================
# THERMAL BEHAVIOR (SAFE)
# =========================

echo "$LOG THERMAL CONTROL..."

setprop debug.thermal.throttle_hint false > /dev/null 2>&1

# =========================
# RENDER PIPELINE CLEANUP
# =========================

echo "$LOG RENDER OPTIMIZATION..."

setprop debug.hwui.use_buffer_age false > /dev/null 2>&1
setprop debug.hwui.render_dirty_regions false > /dev/null 2>&1

# =========================
# SYSTEM UI PERFORMANCE
# =========================

echo "$LOG UI PERFORMANCE..."

setprop persist.sys.ui.hw 1 > /dev/null 2>&1

# =========================
# BACKGROUND CLEANUP
# =========================

echo "$LOG CLEANING BACKGROUND..."

am kill-all > /dev/null 2>&1

# =========================
# STABILITY LOOP
# =========================

echo "$LOG STABILITY CONTROL..."

COUNT=0
while [ $COUNT -lt 4 ]; do
    setprop debug.performance.tuning 1 > /dev/null 2>&1
    sync
    COUNT=$((COUNT+1))
    sleep 0.5
done

sync

echo "$LOG ================================="
echo "$LOG V2 ENGINE ACTIVE"
echo "$LOG SMOOTH + STABLE GAMEPLAY READY"
echo "$LOG ================================="