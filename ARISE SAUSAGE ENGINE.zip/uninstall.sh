#!/system/bin/sh

LOG="[ARISE-SAUSAGE-V2]"

echo "$LOG RESTORING SYSTEM..."

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

setprop debug.performance.tuning 0 > /dev/null 2>&1
setprop debug.hwui.renderer "" > /dev/null 2>&1
setprop debug.sf.latch_unsignaled 0 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 0 > /dev/null 2>&1
setprop debug.hwui.use_buffer_age true > /dev/null 2>&1

am kill-all > /dev/null 2>&1

sync

echo "$LOG DONE"