#!/system/bin/sh

LOG="[ARISE-SAUSAGE-V2]"

PKG="com.GlobalSoFunny.Sausage"

echo "$LOG SERVICE RUNNING..."

while true; do

    APP=$(dumpsys window | grep mCurrentFocus | cut -d "/" -f1 | awk '{print $NF}')

    if echo "$APP" | grep -q "$PKG"; then
        echo "$LOG GAME DETECTED"

        am kill-all > /dev/null 2>&1
        sync > /dev/null 2>&1

        setprop debug.performance.tuning 1 > /dev/null 2>&1
    fi

    sleep 60

done