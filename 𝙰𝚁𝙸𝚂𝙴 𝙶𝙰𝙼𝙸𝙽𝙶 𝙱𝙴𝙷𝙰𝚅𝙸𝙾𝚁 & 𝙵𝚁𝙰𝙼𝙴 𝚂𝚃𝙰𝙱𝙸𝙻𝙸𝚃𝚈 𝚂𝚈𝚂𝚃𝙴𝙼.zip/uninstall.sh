#!/system/bin/sh

echo "[AGBFSS UNINSTALL ENGINE] Starting system restoration..."

# =========================================================
# RESTORE UI ANIMATIONS
# =========================================================

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

echo "[AGBFSS] UI animations restored"

# =========================================================
# RESTORE MEMORY SYSTEM
# =========================================================

settings delete global background_process_limit
settings put global app_standby_enabled 0

echo "[AGBFSS] Memory behavior restored"

# =========================================================
# RESTORE NETWORK FEATURES
# =========================================================

settings put global wifi_scan_always_enabled 1
settings put global ble_scan_always_enabled 1
settings put global nearby_scanning_enabled 1

echo "[AGBFSS] Network scanning restored"

# =========================================================
# RESET INPUT SYSTEM
# =========================================================

settings put system pointer_speed 0

# =========================================================
# RESET GPU FLAGS
# =========================================================

setprop debug.hwui.renderer ""
setprop debug.hwui.use_buffer_age false
setprop debug.egl.swapinterval 1

echo "[AGBFSS] GPU settings reset"

# =========================================================
# RESET GAME SERVICES
# =========================================================

cmd game reset com.garena.game.codm 2>/dev/null

# =========================================================
# CLEANUP
# =========================================================

rm -f /data/local/tmp/agbfss_log.txt 2>/dev/null

echo "[AGBFSS UNINSTALL ENGINE] SYSTEM RESTORED SUCCESSFULLY"
echo "[AGBFSS UNINSTALL ENGINE] ARISE FRAMEWORK REMOVED"