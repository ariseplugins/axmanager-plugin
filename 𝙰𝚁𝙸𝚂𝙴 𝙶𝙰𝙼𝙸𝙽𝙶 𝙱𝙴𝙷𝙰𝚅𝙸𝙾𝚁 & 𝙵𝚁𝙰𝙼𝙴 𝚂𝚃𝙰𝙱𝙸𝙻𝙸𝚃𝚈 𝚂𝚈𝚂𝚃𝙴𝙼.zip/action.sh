#!/system/bin/sh

BASE="$(dirname "$0")"

echo "[AGBFSS ACTION ENGINE] Boot sequence initiated..."
echo "[AGBFSS ACTION ENGINE] Loading ARISE Gaming Behavior Framework..."

# =========================================================
# WAIT FOR SYSTEM BOOT
# =========================================================

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

echo "[AGBFSS ACTION ENGINE] System boot completed."
echo "[AGBFSS ACTION ENGINE] Verifying service layer..."

# =========================================================
# SERVICE INITIALIZATION
# =========================================================

SERVICE_FILE="$BASE/service.sh"

if [ -f "$SERVICE_FILE" ]; then
  echo "[AGBFSS ACTION ENGINE] Service detected. Executing core framework..."
  sh "$SERVICE_FILE"
else
  echo "[AGBFSS ACTION ENGINE] ERROR: service.sh not found"
  exit 1
fi

# =========================================================
# POST INITIALIZATION CHECK
# =========================================================

echo "[AGBFSS ACTION ENGINE] Validating system state..."

sleep 2

echo "[AGBFSS ACTION ENGINE] Framework Status: ACTIVE"
echo "[AGBFSS ACTION ENGINE] ARISE Gaming Behavior System Running"