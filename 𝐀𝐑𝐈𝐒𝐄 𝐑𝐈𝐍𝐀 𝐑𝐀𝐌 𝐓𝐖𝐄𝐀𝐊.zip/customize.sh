brand=$(getprop ro.product.manufacturer)
model=$(getprop ro.product.model)
android=$(getprop ro.build.version.release)

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "      𝐀𝐑𝐈𝐒𝐄 𝐎𝐏𝐓𝐈𝐌𝐈𝐙𝐄𝐑 𝐋𝐀𝐘𝐄𝐑"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "Device   : $brand $model"
echo "Android  : $android"
echo ""

# Loading bar
echo "ARISE: Processing optimization..."
sleep 1

echo "[■□□□□□□□□□] 10%" ; sleep 0.2
echo "[■■□□□□□□□□] 20%" ; sleep 0.3
echo "[■■■□□□□□□□] 30%" ; sleep 0.2
echo "[■■■■□□□□□□] 40%" ; sleep 0.3
echo "[■■■■■□□□□□] 50%" ; sleep 0.2
echo "[■■■■■■□□□□] 60%" ; sleep 0.4
echo "[■■■■■■■□□□] 70%" ; sleep 0.2
echo "[■■■■■■■■□□] 80%" ; sleep 0.4
echo "[■■■■■■■■■□] 90%" ; sleep 0.2
echo "[■■■■■■■■■■] 100%" ; sleep 0.3
echo ""

# ==========================
# ARISE GAME PACKAGE LIST
# ==========================
games="
com.dts.freefireth
com.garena.freefiremax
com.tencent.ig
com.pubg.krmobile
com.pubg.imobile
com.pubg.newstate
com.activision.callofduty.shooter
com.epicgames.fortnite
com.krafton.roadtovalor
com.mobile.legends
com.riotgames.league.wildrift
com.riotgames.league.teamfighttactics
com.miHoYo.GenshinImpact
com.HoYoverse.HonkaiStarRail
com.miHoYo.HonkaiImpact3rd
com.square_enix.android_googleplay.ffxv
com.square_enix.android_googleplay.nierspww
com.netmarble.mherosgb
com.kabam.marvelbattle
com.bandainamcoent.dblegends_ww
com.bandainamcoent.opbrww
com.nexon.bluearchive
com.proximabeta.mf.uamo
com.supercell.clashofclans
com.supercell.clashroyale
com.supercell.brawlstars
com.supercell.boombeach
com.supercell.hayday
com.king.candycrushsaga
com.king.candycrushsodasaga
com.mojang.minecraftpe
com.roblox.client
com.innersloth.spacemafia
com.igg.android.lordsmobile
com.plarium.raidlegends
com.lilithgames.raziel.en
com.lilithgame.roc.gp
com.lilithgames.afk.google
com.ea.gp.fifamobile
com.ea.gp.nbamobile
com.firsttouchgames.dls7
com.konami.pesam
com.nianticlabs.pokemongo
com.sega.sonicdash
com.nexon.kartdrift
com.mihoyo.zenless
com.bandainamcoent.shonenjump.dbzdokkan
com.bandainamcoent.narutoblazing
com.square_enix.android_googleplay.dffoo
"

# ==========================
# ARISE SOCIAL PACKAGE LIST
# ==========================
social="
com.whatsapp
com.instagram.android
com.facebook.katana
com.twitter.android
com.snapchat.android
com.tiktok.android
com.telegram.messenger
com.discord
com.reddit.frontpage
com.linkedin.android
com.pinterest
com.skype.raider
com.viber.voip
com.quora.android
com.wechat
com.linecorp.LGPK
com.kakao.talk
com.clubhouse.app
com.microsoft.teams
org.thoughtcrime.securesms
org.telegram.plus
com.whatsapp.w4b
com.facebook.orca
com.facebook.lite
com.instagram.lite
com.twitter.android.lite
com.beetalk
com.twoo
com.match.android
com.okcupid.okcupid
com.hily.app
com.mico
com.hago.gaming
com.imo.android.imoim
com.badoo.mobile
com.tumblr
com.foursquare.robin
com.zhiliaoapp.musically
com.periscope.android
com.houseparty
com.hike.chat.stickers
com.yubo.chat
com.meetme.android
com.waplog.android
com.azarlive.android
com.streamkar.app
com.holla.video
com.tango.video
"

# ==========================
# ARISE HEAVY PACKAGE LIST
# ==========================
heavy_apps="
com.google.android.youtube
com.google.android.apps.maps
com.google.android.videos
com.google.android.music
com.google.android.apps.photos
com.google.android.apps.docs
com.google.android.gm
com.google.android.calendar
com.google.android.keep
com.google.android.googlequicksearchbox
com.google.android.contacts
com.google.android.dialer
com.google.android.messaging
com.google.android.play.games
com.android.chrome
com.google.android.apps.nbu.paisa.user
com.google.android.apps.subscriptions.red
com.google.android.apps.tachyon
com.google.android.apps.nexuslauncher
com.google.android.apps.walletnfcrel
com.google.android.apps.turbo
com.google.android.apps.work.clouddpc
com.google.android.apps.youtube.music
com.google.ar.core
com.google.vr.vrcore
com.google.android.apps.cloudprint
com.google.android.apps.wellbeing
com.google.android.apps.accessibility.voiceaccess
com.google.android.apps.accessibility.audiomodem
com.google.android.marvin.talkback
com.samsung.android.game.gametools
com.samsung.android.game.gos
com.samsung.android.bixby.agent
com.samsung.android.messaging
com.miui.msa.global
com.miui.weather2
com.coloros.video
com.coloros.gallery3d
com.coloros.music
com.huawei.appmarket
com.huawei.browser
com.oppo.market
com.vivo.easyshare
com.oneplus.filemanager
com.lenovo.anyshare.gps
com.sec.android.app.samsungapps
com.samsung.android.game.gamehome
"

# ==========================
# EXECUTE COMPACTION
# ==========================
all_apps="$games $social $heavy_apps"

for pkg in $all_apps; do
    cmd activity compact full "$pkg" 2>/dev/null
done

# ==========================
# ARISE SYSTEM SETTINGS TUNING
# ==========================
settings put global activity_manager_constants \
"use_compaction=true,"\
"compact_throttle_1=1000,"\
"compact_throttle_2=2000,"\
"compact_throttle_3=500,"\
"compact_throttle_4=3000,"\
"compact_throttle_min_oom_adj=0,"\
"compact_throttle_max_oom_adj=999,"\
"compact_statsd_sample_rate=1.0,"\
"compact_full_rss_throttle_kb=4096,"\
"compact_full_delta_rss_throttle_kb=2048,"\
"compact_proc_state_throttle=11"

# ==========================
# GMS COMPAT CONTROL (ARISE CORE)
# ==========================
a="$(getprop ro.build.version.sdk)"
for b in $(cmd package list packages --user 0 gms | grep -v ia.mo | cut -f2 -d:); do
    cmd activity compat disable-all "$a" "$b"
done