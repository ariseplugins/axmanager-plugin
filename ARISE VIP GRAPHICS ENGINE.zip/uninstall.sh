#!/system/bin/sh

LOG="[ARISE-VIP-V2]"

echo "$LOG RESTORING SYSTEM..."

# restore animations
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

# reset props
setprop debug.performance.tuning 0 > /dev/null 2>&1
setprop debug.hwui.renderer "" > /dev/null 2>&1
setprop debug.choreographer.skipwarning 0 > /dev/null 2>&1
setprop debug.sf.latch_unsignaled 0 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 0 > /dev/null 2>&1
setprop debug.hwui.render_dirty_regions true > /dev/null 2>&1

# cleanup session
am kill-all > /dev/null 2>&1
sync

echo "$LOG SYSTEM RESTORED SUCCESSFULLY"