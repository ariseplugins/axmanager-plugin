#!/system/bin/sh

# =========================================
# ARISE VIP GRAPHICS ENGINE V2
# =========================================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
CYAN="\033[1;36m"
MAGENTA="\033[1;35m"
NC="\033[0m"

LOG="[ARISE-VIP-V2]"

echo -e "${MAGENTA}$LOG =================================${NC}"
echo -e "${MAGENTA}$LOG ENGINE INITIALIZING...${NC}"
echo -e "${MAGENTA}$LOG =================================${NC}"

sleep 0.5

# =========================
# DEVICE DETECTION
# =========================

MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
CPU=$(getprop ro.hardware)
GPU=$(getprop ro.hardware.egl)
ANDROID=$(getprop ro.build.version.release)

echo -e "${YELLOW}$LOG DEVICE CHECK${NC}"
echo "$LOG BRAND : $BRAND"
echo "$LOG MODEL : $MODEL"
echo "$LOG CPU   : $CPU"
echo "$LOG GPU   : $GPU"
echo "$LOG OS    : Android $ANDROID"

sleep 0.5

# =========================
# SYSTEM SMOOTHNESS CORE
# =========================

echo -e "${CYAN}$LOG APPLYING SMOOTHNESS...${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# =========================
# PERFORMANCE ENGINE
# =========================

echo -e "${CYAN}$LOG PERFORMANCE CORE...${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

# =========================
# FRAME STABILITY SYSTEM
# =========================

echo -e "${CYAN}$LOG FRAME STABILITY...${NC}"

setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 1 > /dev/null 2>&1

# =========================
# INPUT RESPONSE BOOST
# =========================

echo -e "${CYAN}$LOG INPUT RESPONSE...${NC}"

setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1

# =========================
# GRAPHICS FEEL MODE
# =========================

echo -e "${CYAN}$LOG GRAPHICS MODE ACTIVE...${NC}"

setprop debug.hwui.render_dirty_regions false > /dev/null 2>&1

# =========================
# BACKGROUND OPTIMIZATION
# =========================

echo -e "${CYAN}$LOG BACKGROUND CLEANUP...${NC}"

am kill-all > /dev/null 2>&1

sync

echo -e "${GREEN}$LOG =================================${NC}"
echo -e "${GREEN}$LOG V2 ENGINE ACTIVE${NC}"
echo -e "${GREEN}$LOG STABLE + SMOOTH READY${NC}"
echo -e "${GREEN}$LOG =================================${NC}"