#!/system/bin/sh

log() {
  echo "[GAME TUNER] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

sleep 5

log "system ready, initializing gaming profile..."

MODEL=$(getprop ro.product.model)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')

log "device: $MODEL"
log "ram detected: $RAM KB"

# =========================
# REAL SYSTEM TWEAKS
# =========================

log "reducing background process load"
cmd activity memory-factor set 0 2>/dev/null

log "disabling unnecessary standby restrictions"
settings put global app_standby_enabled 0

log "improving touch responsiveness feel"
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

log "disabling animation overhead"
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "enabling game driver support"
settings put global game_driver_all_apps 1

log "disabling system idle restrictions during active usage"
cmd deviceidle disable

log "optimizing surface rendering behavior"
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true

log "reducing background system noise"
settings put global settings_enable_monitor_phantom_procs false

log "clearing memory cache safely"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "gaming profile applied successfully"