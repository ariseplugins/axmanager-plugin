#!/system/bin/sh

echo "[GAME STABILITY TUNER] applying user-level optimization..."

# UI smoothness
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# touch tuning
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

# display behavior
cmd display set-match-content-frame-rate-pref 1 2>/dev/null

# game system hint
settings put global game_driver_all_apps 1

echo "[DONE] action layer applied"