#!/system/bin/sh

log() {
  echo "[GAME TUNER REMOVE] $1"
}

log "restoring system defaults..."

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

settings put global game_driver_all_apps 0
settings put global app_standby_enabled 1

cmd activity memory-factor set 1 2>/dev/null
cmd deviceidle enable

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_hint_manager false

log "system restored successfully"