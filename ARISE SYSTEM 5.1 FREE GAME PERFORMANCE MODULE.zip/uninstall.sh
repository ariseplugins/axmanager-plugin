#!/system/bin/sh
# ARISE SYSTEM 5.1 Enhanced – Uninstall

log() {
    echo "[ARISE SYSTEM] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "Boot complete. Reverting system configuration..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

setprop debug.sf.use_phase_offsets_as_durations 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.early_sf_phase_offset_ns 0
setprop debug.sf.late_app_phase_offset_ns 0
setprop debug.sf.late_sf_phase_offset_ns 0
setprop debug.sf.max_frame_buffer_acquired_buffers 0

setprop debug.renderengine.backend default
setprop debug.renderengine.enable_async_cache 0
setprop debug.renderengine.frame_submission_limit 0

settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values

log "Graphics pipeline reset"

settings delete global activity_manager_constants
settings delete global background_process_limit

log "Memory policies reset"

settings delete global alarm_manager_constants
settings delete global sync_max_retry_delay_in_seconds
settings delete global connectivity_metrics_buffer_size

settings delete global background_throttling_enable
settings delete global background_throttling_limit

log "Background system tuning cleared"

settings delete system pointer_speed
settings delete global tap_timeout
settings delete global long_press_timeout
settings delete global multi_press_timeout

log "Input configuration reset"

cmd appops set "$GAME" WAKE_LOCK default
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND default
dumpsys deviceidle whitelist -"${GAME}"

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config clear game android.os.adpf_predict_frame_time
    cmd device_config clear game android.os.adpf_sustained_performance_mode
    log "Advanced performance hints cleared (A13+)"
fi

log "ARISE SYSTEM 5.1 fully removed"