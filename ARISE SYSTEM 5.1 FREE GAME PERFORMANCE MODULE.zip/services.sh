#!/system/bin/sh
# ARISE SYSTEM 5.1 Enhanced Build

log() {
    echo "[ARISE SYSTEM] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System ready. Applying performance profile..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

log "SurfaceFlinger timing tuned"

setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3

settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
settings put global angle_gl_driver_selection_values egl

log "RenderEngine enhanced"

settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 4

log "Memory & service stability applied"

settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000

settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "Background system optimization active"

settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "Input & touch responsiveness tuned"

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    log "Advanced performance layer enabled (A13+)"
fi

cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "ARISE SYSTEM 5.1 active"