#!/system/bin/sh

GREY='\033[90m'
DARK='\033[37m'
DIM='\033[2m'
CYAN='\033[36m'
YELLOW='\033[33m'
RESET='\033[0m'

clear

# ===============================
# BOOT ANIMATION STYLE (NEW)
# ===============================
echo -e "${GREY}INITIALIZING ARISE SYSTEM CORE...${RESET}"
sleep 1
echo -e "${DIM}Loading modules...${RESET}"
sleep 1
echo -e "${DIM}Checking system integrity...${RESET}"
sleep 1
echo -e "${DIM}Preparing CODM environment...${RESET}"
sleep 1
echo ""

# ===============================
# ARISE LOGO
# ===============================
echo -e "${GREY}"
echo " █████╗ ██████╗ ██╗███████╗███████╗"
echo "██╔══██╗██╔══██╗██║██╔════╝██╔════╝"
echo "███████║██████╔╝██║███████╗█████╗  "
echo "██╔══██║██╔══██╗██║╚════██║██╔══╝  "
echo "██║  ██║██║  ██║██║███████║███████╗"
echo "╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝"
echo -e "${RESET}"

echo -e "${GREY}╔══════════════════════════════════════╗${RESET}"
echo -e "${GREY}║        ARISE NONROOT PAID           ║${RESET}"
echo -e "${GREY}║     CYBER GREY ULTRA SYSTEM         ║${RESET}"
echo -e "${GREY}║       NEXT LEVEL EDITION V5         ║${RESET}"
echo -e "${GREY}╚══════════════════════════════════════╝${RESET}"
echo ""

# ===============================
# DEVELOPER PANEL (UPGRADED)
# ===============================
echo -e "${CYAN}========== DEVELOPER PANEL ==========${RESET}"
echo -e "${DARK}Developer : arisestark${RESET}"
echo -e "${DARK}Build     : VIP PAID RELEASE${RESET}"
echo -e "${DARK}Status    : ACTIVE CORE ENGINE${RESET}"
echo -e "${CYAN}=====================================${RESET}"
echo ""

# ===============================
# VIP KEY SYSTEM UI (NEW)
# ===============================
echo -e "${YELLOW}========== VIP ACCESS CHECK ==========${RESET}"
echo -e "${DIM}Checking license key...${RESET}"
sleep 1
echo -e "${DIM}Validating ARISE access...${RESET}"
sleep 1
echo -e "${GREY}[✔] VIP STATUS : GRANTED${RESET}"
echo -e "${GREY}[✔] SYSTEM ACCESS : UNLOCKED${RESET}"
echo -e "${YELLOW}======================================${RESET}"
echo ""

# ===============================
# DEVICE CHECK
# ===============================
echo -e "${CYAN}========== DEVICE SCAN ==========${RESET}"

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo "UNKNOWN")
ANDROID_VER=$(getprop ro.build.version.release)
MODEL=$(getprop ro.product.model)

echo -e "${DARK}Model   : $MODEL${RESET}"
echo -e "${DARK}Android : $ANDROID_VER${RESET}"
echo -e "${DARK}RAM     : $RAM_KB KB${RESET}"
echo -e "${CYAN}=================================${RESET}"
echo ""

# ===============================
# CODM PROFILE DETECTION UI (NEW)
# ===============================
echo -e "${YELLOW}========== CODM PROFILE ==========${RESET}"

if [ "$RAM_KB" -ge 8000000 ]; then
  PROFILE="ULTRA FPS MODE"
elif [ "$RAM_KB" -ge 6000000 ]; then
  PROFILE="BALANCED COMPETITIVE"
else
  PROFILE="STABLE PERFORMANCE"
fi

echo -e "${GREY}Detected Profile : $PROFILE${RESET}"
echo -e "${YELLOW}Applying optimized gameplay layer...${RESET}"
sleep 1
echo -e "${GREY}[✔] CODM PROFILE ACTIVE${RESET}"
echo ""

# ===============================
# INSTALLATION SEQUENCE
# ===============================
echo -e "${DIM}[1/5] Loading ARISE core...${RESET}"
sleep 1
echo -e "${DIM}[2/5] Applying FPS stability layer...${RESET}"
sleep 1
echo -e "${DIM}[3/5] Optimizing touch response...${RESET}"
sleep 1
echo -e "${DIM}[4/5] Reducing background load...${RESET}"
sleep 1
echo -e "${DIM}[5/5] Finalizing system boost...${RESET}"
sleep 1
echo ""

# ===============================
# FINAL PANEL
# ===============================
echo -e "${GREY}╔══════════════════════════════════════╗${RESET}"
echo -e "${GREY}║        INSTALLATION COMPLETE        ║${RESET}"
echo -e "${GREY}║        ARISE SYSTEM ACTIVE          ║${RESET}"
echo -e "${GREY}║      NEXT LEVEL CYBER MODE          ║${RESET}"
echo -e "${GREY}╚══════════════════════════════════════╝${RESET}"
echo ""

echo -e "${DARK}STATUS : READY FOR GAMING${RESET}"
echo -e "${DARK}MODE   : CODM OPTIMIZED${RESET}"
echo ""

# ===============================
# FINAL SYSTEM INFO (UPGRADED)
# ===============================
echo -e "${CYAN}========== ARISE SYSTEM INFO ==========${RESET}"
echo -e "${DARK}Engine : CYBER ARISE CORE V5${RESET}"
echo -e "${DARK}Type   : NONROOT PAID SYSTEM${RESET}"
echo -e "${DARK}Focus  : FPS / STABILITY / LATENCY${RESET}"
echo -e "${DARK}Level  : NEXT GEN UI BUILD${RESET}"
echo -e "${CYAN}======================================${RESET}"