#!/system/bin/sh

log() {
  echo "[ARISE NONROOT PAID] $1"
}

log "Starting ARISE NONROOT PAID RESET / Uninstall..."

log "Resetting animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

log "Resetting display optimizations..."
cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types 0 2>/dev/null

log "Resetting memory & touch boost..."
cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 0

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null
[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null

log "Resetting thermal limits & device idle..."
setprop debug.thermal.throttle.support yes 2>/dev/null
cmd deviceidle enable

setprop debug.stagefright.ccodec 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.late_phase_offset_ns 0
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.hwui.use_hint_manager false

settings put global game_driver_all_apps 0

log "Restoring HWUI & SurfaceFlinger defaults..."
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.overdraw true
setprop debug.sf.hw 0
setprop hw3d.force 0

log "Resetting game overlays & performance mode..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
    device_config put game_overlay "$pkg" mode=0,downscaleFactor=1,fps=0
    cmd game mode none "$pkg"
done

log "Resetting Google packages..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
done

log "Revoking previously granted permissions from Google Play Services..."
cmd package revoke com.google.android.gms android.permission.READ_CONTACTS
cmd package revoke com.google.android.gms android.permission.WRITE_CONTACTS

log "Resetting Android 14+ game flags..."
cmd device_config override game android.os.adpf_prefer_power_efficiency true 2>/dev/null
cmd device_config override game android.os.adpf_hwui_gpu false 2>/dev/null

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "ARISE NONROOT PAID RESET / Uninstall completed successfully."