import { exec } from "https://cdn.jsdelivr.net/npm/kernelsu@1.0.6/+esm";

document.addEventListener('DOMContentLoaded', async () => {
  const launchButton = document.getElementById('launchButton');
  const statusMessage = document.getElementById('statusMessage');
  const mainContent = document.getElementById('mainContent');

  // Function to check if the server is running by trying to access its port
  const checkServerStatus = async () => {
    try {
      const response = await fetch('http://localhost:8080/', { method: 'HEAD', mode: 'no-cors' });
      return true;
    } catch (error) {
      return false;
    }
  };

  // Check server status on page load
  const isServerRunning = await checkServerStatus();

  if (isServerRunning) {
    // If the server is already running, directly redirect to it for a smooth, fast experience.
    window.location.href = 'http://localhost:8080/';
  } else {
    // If the server is not running, show the UI to allow the user to launch it.
    mainContent.classList.remove('hidden');
    mainContent.classList.add('fade-in');
    
    launchButton.addEventListener('click', async () => {
      // Disable the button and show a loading message
      launchButton.disabled = true;
      launchButton.classList.add('opacity-50', 'cursor-not-allowed');
      statusMessage.classList.remove('hidden');
      statusMessage.textContent = 'Executing script... Please wait.';

      try {
        // Execute the shell script to start the server
        const result = await exec('sh /storage/emulated/0/performance-ai/start.sh --ext_setup');
        
        // Wait a moment for the service to start, then initiate the redirect with a visual transition
        statusMessage.textContent = 'Script executed. Redirecting...';
        mainContent.classList.add('out');
        setTimeout(() => {
          window.location.href = 'http://localhost:8080/';
        }, 1000); // 1-second delay for a smooth transition and to allow the service to start
      } catch (error) {
        // Handle any errors during script execution
        statusMessage.textContent = 'Error: Failed to execute script.';
        launchButton.disabled = false;
        launchButton.classList.remove('opacity-50', 'cursor-not-allowed');
      }
    });
  }
});
