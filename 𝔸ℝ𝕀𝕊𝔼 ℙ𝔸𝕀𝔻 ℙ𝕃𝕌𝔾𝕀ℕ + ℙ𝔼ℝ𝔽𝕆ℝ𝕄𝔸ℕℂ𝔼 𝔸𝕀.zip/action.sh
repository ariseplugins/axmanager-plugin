#!/system/bin/sh

GREEN="\033[32m"
RESET="\033[0m"

echo -e "${GREEN}NOTE:${RESET}"
echo -e "${GREEN}Some devices may restrict or block certain system commands.${RESET}"
echo -e "${GREEN}Due to manufacturer limits (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.),${RESET}"
echo -e "${GREEN}this module may work fully, partially, or not at all.${RESET}"
echo -e "${GREEN}Results depend on device model and Android version.${RESET}"
echo -e "${GREEN}Use this module at your own risk.${RESET}"
echo ""

echo -e "${GREEN}ARISE NONROOT PAID — First Time Basic Plugin${RESET}"
echo -e "${GREEN}Please support my channel — Thank you!${RESET}"
echo ""

echo -e "${GREEN}[ARISE NONROOT PAID - Dynamic Gaming Optimizer]${RESET}"
echo -e "${GREEN}Version: 2.0${RESET}"
echo ""

echo -e "${GREEN}Features included in this module:${RESET}"
echo ""

echo -e "${GREEN} 1) Dynamic Device Detection${RESET}"
echo -e "${GREEN}    • Reads RAM, CPU speed, and Android version${RESET}"
echo -e "${GREEN}    • Auto-classifies device (High / Upper-Mid / Mid / Low)${RESET}"
echo -e "${GREEN}    • Automatically selects best downscaleFactor${RESET}"
echo ""

echo -e "${GREEN} 2) Display & FPS Optimization${RESET}"
echo -e "${GREEN}    • Disables animations for faster UI${RESET}"
echo -e "${GREEN}    • Forces match-content frame rate${RESET}"
echo -e "${GREEN}    • Disables HDR types that cause stutter${RESET}"
echo ""

echo -e "${GREEN} 3) Game & ADPF Enhancements${RESET}"
echo -e "${GREEN}    • Enables performance game mode per app${RESET}"
echo -e "${GREEN}    • Applies Android 14+ game performance flags${RESET}"
echo -e "${GREEN}    • Uses Game Overlay downscaling for smoother FPS${RESET}"
echo ""

echo -e "${GREEN} 4) Touch Boost${RESET}"
echo -e "${GREEN}    • Faster touch response${RESET}"
echo -e "${GREEN}    • Enables Qualcomm touchboost when available${RESET}"
echo ""

echo -e "${GREEN} 5) Memory & Cache Tuning${RESET}"
echo -e "${GREEN}    • Reduces background process load${RESET}"
echo -e "${GREEN}    • Improves RAM management${RESET}"
echo -e "${GREEN}    • Forces periodic storage trim${RESET}"
echo ""

echo -e "${GREEN}All features run automatically — plug & play!${RESET}"
echo -e "${GREEN}Safe to uninstall anytime using uninstall.sh${RESET}"
echo ""