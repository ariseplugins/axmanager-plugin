#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐑𝐄𝐒𝐓𝐎𝐑𝐄 𝐄𝐍𝐆𝐈𝐍𝐄
#     𝐒𝐘𝐒𝐓𝐄𝐌 𝐒𝐀𝐅𝐄 𝐑𝐄𝐕𝐄𝐑𝐓
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LOG="/sdcard/arise_restore_log.txt"

GAME="com.garena.game.codm"

log() {
    echo "$(date '+%H:%M:%S') [ARISE RESTORE] $1" | tee -a "$LOG"
}

clear

log "Initializing ARISE system restore engine..."
log "Target package: $GAME"

#━━━━━━━━ SURFACEFLINGER RESET ━━━━━━━━
log "Resetting SurfaceFlinger layer..."

resetprop -p debug.sf.use_phase_offsets_as_durations
resetprop -p debug.sf.early_app_phase_offset_ns
resetprop -p debug.sf.early_sf_phase_offset_ns
resetprop -p debug.sf.late_app_phase_offset_ns
resetprop -p debug.sf.late_sf_phase_offset_ns
resetprop -p debug.sf.max_frame_buffer_acquired_buffers

log "SurfaceFlinger restored"

#━━━━━━━━ RENDER ENGINE RESET ━━━━━━━━
log "Resetting RenderEngine..."

resetprop -p debug.renderengine.backend
resetprop -p debug.renderengine.enable_async_cache
resetprop -p debug.renderengine.frame_submission_limit

settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values

log "RenderEngine restored"

#━━━━━━━━ MEMORY RESET ━━━━━━━━
log "Restoring memory system..."

settings delete global activity_manager_constants
settings delete global background_process_limit
settings delete global cached_apps_freezer

log "Memory system reset"

#━━━━━━━━ BACKGROUND RESET ━━━━━━━━
log "Restoring background system..."

settings delete global alarm_manager_constants
settings delete global sync_max_retry_delay_in_seconds
settings delete global connectivity_metrics_buffer_size
settings delete global background_throttling_enable
settings delete global background_throttling_limit

log "Background system restored"

#━━━━━━━━ INPUT RESET ━━━━━━━━
log "Restoring input configuration..."

settings delete system pointer_speed
settings delete global tap_timeout
settings delete global long_press_timeout
settings delete global multi_press_timeout

log "Input settings restored"

#━━━━━━━━ GAME RESET ━━━━━━━━
log "Resetting game configuration..."

settings delete global game_driver_all_apps
cmd device_config delete game_overlay "$GAME" 2>/dev/null
cmd game mode none "$GAME" 2>/dev/null

log "Game settings reset"

#━━━━━━━━ FINALIZATION ━━━━━━━━
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "ARISE RESTORE COMPLETE"
log "System returned to default state"
log "Reboot recommended for full cleanup"