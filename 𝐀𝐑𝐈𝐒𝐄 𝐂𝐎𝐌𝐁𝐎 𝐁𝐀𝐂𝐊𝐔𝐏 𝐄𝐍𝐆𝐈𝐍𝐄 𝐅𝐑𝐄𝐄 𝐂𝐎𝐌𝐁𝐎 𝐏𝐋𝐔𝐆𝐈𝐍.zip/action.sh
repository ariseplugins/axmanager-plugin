#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐂𝐎𝐌𝐁𝐎 𝐁𝐀𝐂𝐊𝐔𝐏 𝐄𝐍𝐆𝐈𝐍𝐄
#       𝐅𝐑𝐄𝐄 𝐂𝐎𝐌𝐁𝐎 𝐏𝐋𝐔𝐆𝐈𝐍
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RED="\033[1;31m"
CYAN="\033[1;36m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
PURPLE="\033[1;35m"
WHITE="\033[1;97m"
DIM="\033[2;37m"
RESET="\033[0m"

LOG="/sdcard/arise_combo_engine.log"

log() {
    echo -e "${CYAN}[ARISE ENGINE]${RESET} ${WHITE}$1${RESET}" | tee -a "$LOG"
}

GAME="com.garena.game.codm"

clear

echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   ARISE COMBO BACKUP ENGINE${RESET}"
echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Initializing ARISE performance core..."

#━━━━━━━━ BOOT SYNC ━━━━━━━━
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected"

#━━━━━━━━ REAL EFFECT LAYER: MEMORY CLEAN ━━━━━━━━
log "Executing memory stabilization..."

cmd activity kill-all 2>/dev/null
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

settings put global cached_apps_freezer 1
settings put global background_process_limit 3

log "RAM optimized + background reduced"

#━━━━━━━━ REAL EFFECT: TOUCH BOOST LAYER ━━━━━━━━
log "Applying touch response tuning..."

settings put system pointer_speed 7
settings put global touch_exploration_enabled 0
settings put secure long_press_timeout 250
settings put secure multi_press_timeout 180

# kernel touch boost (if supported)
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

log "Touch latency reduced"

#━━━━━━━━ REAL EFFECT: RENDER ENGINE ━━━━━━━━
log "Boosting rendering pipeline..."

setprop debug.hwui.renderer skiaglthreaded
setprop debug.hwui.use_hint_manager true
setprop debug.renderengine.backend skiaglthreaded
setprop debug.performance.tuning 1

settings put global disable_hw_overlays 1
settings put system multicore_packet_scheduler 1

log "GPU rendering optimized"

#━━━━━━━━ REAL EFFECT: GAME SYSTEM ━━━━━━━━
log "Activating game performance layer..."

settings put global game_driver_all_apps 1

cmd device_config put game_overlay "$GAME" mode=2,fps=120,downscaleFactor=0.50 2>/dev/null

cmd game mode performance "$GAME" 2>/dev/null

log "Game overlay applied"

#━━━━━━━━ REAL EFFECT: BACKGROUND CONTROL ━━━━━━━━
log "Restricting background processes..."

settings put global activity_manager_constants \
"max_cached_processes=24,fgservice_min_shown_time=2000"

settings put global background_throttling_enable 1
settings put global background_throttling_limit 40

log "Background throttled"

#━━━━━━━━ NETWORK / LATENCY LAYER ━━━━━━━━
log "Optimizing system responsiveness..."

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "UI latency reduced"

#━━━━━━━━ FINAL STABILITY ━━━━━━━━
log "Finalizing ARISE engine..."

cmd power set-fixed-performance-mode-enabled true 2>/dev/null

sync

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}  ARISE ENGINE ACTIVE (BACKUP)${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "STATUS: STABLE / OPTIMIZED / READY"
log "ENGINE: ARISE COMBO BACKUP V2"
log "LOG SAVED: $LOG"