#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐂𝐎𝐌𝐁𝐎 𝐔𝐈 𝐄𝐍𝐆𝐈𝐍𝐄
#     𝐂𝐎𝐃𝐌 𝐈𝐍𝐒𝐓𝐀𝐋𝐋𝐄𝐑 𝐕𝐈𝐒𝐔𝐀𝐋
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ui_print() {
    echo -e "$1"
}

sleep_cmd() {
    sleep 0.6
}

VERSION="ARISE *⁸"

ui_print " "
ui_print "╔══════════════════════════════╗"
ui_print "   𝐀𝐑𝐈𝐒𝐄 𝐂𝐎𝐃𝐌 𝐔𝐈 𝐄𝐍𝐆𝐈𝐍𝐄"
ui_print "        𝐕𝐄𝐑𝐒𝐈𝐎𝐍 $VERSION"
ui_print "╚══════════════════════════════╝"
ui_print " "

#━━━━━━━━ FEATURE LOADING ━━━━━━━━
ui_print "[■□□□□□□□□□] Initializing ARISE Core Engine..."
sleep_cmd

ui_print "• RAM Cleanup System (Kill-All Boost)"
ui_print "• SurfaceFlinger Frame Optimization"
ui_print "• RenderEngine SkiaGL Thread Boost"
ui_print "• Async Frame Submission Control"
ui_print "• CODM Driver Priority Layer"
sleep_cmd

#━━━━━━━━ MEMORY SYSTEM ━━━━━━━━
ui_print "[■■□□□□□□□□] Loading Memory Engine..."
sleep_cmd

ui_print "• Cached Process Optimization"
ui_print "• Background Process Limiter"
ui_print "• Service Stability Control"

# REAL EFFECT (safe layer)
cmd activity kill-all 2>/dev/null
settings put global background_process_limit 3
settings put global cached_apps_freezer 1

sleep_cmd

#━━━━━━━━ BACKGROUND CONTROL ━━━━━━━━
ui_print "[■■■□□□□□□□] Activating Background System..."
sleep_cmd

ui_print "• Sync Optimization Layer"
ui_print "• Background Throttle Control"
ui_print "• Network Buffer Stabilizer"

settings put global background_throttling_enable 1
settings put global sync_max_retry_delay_in_seconds 3600

sleep_cmd

#━━━━━━━━ INPUT BOOST ━━━━━━━━
ui_print "[■■■■□□□□□□] Enhancing Touch Response..."
sleep_cmd

ui_print "• Touch Latency Reduction"
ui_print "• Tap Response Optimization"
ui_print "• Pointer Speed Calibration"

settings put system pointer_speed 7
settings put secure long_press_timeout 250
settings put secure multi_press_timeout 180

# hardware boost (if supported)
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

sleep_cmd

#━━━━━━━━ GAME PRIORITY ━━━━━━━━
ui_print "[■■■■■□□□□□] Loading Game Priority Engine..."
sleep_cmd

ui_print "• CODM Priority Unlock"
ui_print "• Performance Scheduling Layer"
ui_print "• WakeLock Optimization"

settings put global game_driver_all_apps 1

cmd device_config put game_overlay "com.garena.game.codm" \
mode=2,fps=120,downscaleFactor=0.50 2>/dev/null

sleep_cmd

#━━━━━━━━ FINALIZATION ━━━━━━━━
ui_print "[■■■■■■■■■■] Finalizing ARISE Engine..."
sleep_cmd

ui_print " "
ui_print "━━━━━━━━━━━━━━━━━━━━━━"
ui_print "   MODULE STATUS READY"
ui_print "   CODM OPTIMIZED MODE"
ui_print "   STABLE FPS ENABLED"
ui_print "━━━━━━━━━━━━━━━━━━━━━━"
ui_print " "

# optional system stabilization
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

ui_print "✔ ARISE UI ENGINE ACTIVATED"