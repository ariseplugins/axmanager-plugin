#!/system/bin/sh
logcat -G 128K &>/dev/null

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#      𝐀𝐑𝐈𝐒𝐄 𝐆𝐌𝐒 𝐎𝐏𝐓𝐈𝐌𝐈𝐙𝐄𝐑 𝐋𝐀𝐘𝐄𝐑
#   SYSTEM CLEAN • SERVICE CONTROL • PATCH
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Developer : @ariseplugin
# Engine    : ARISE SYSTEM CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# === PRINT FUNCTION SELECTION ===
if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# === PRINT FUNCTION WRAPPER ===
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf)   printf "$1" ;;
    esac
}

# === LINE SEPARATOR ===
print_line() {
    ui_print "***************************************"
}

# === TRIM PARTITION ===
trim_partition() {
    if [ "$(id -u)" -eq 0 ]; then
        for partition in system vendor data cache metadata odm system_ext product; do
            fstrim -v "/$partition"
        done >/dev/null 2>&1 &
    else
        for partition in system vendor data cache metadata odm system_ext product; do
            sm fstrim "/$partition"
        done >/dev/null 2>&1 &
    fi
    sleep 3
}

# === DELETE TRASH & LOGS ===
delete_trash_logs() {
    for DIR in /data/data/*; do
        if [ -d "${DIR}" ]; then
            rm -rf "${DIR}/cache/"*
            rm -rf "${DIR}/no_backup/"*
            rm -rf "${DIR}/app_webview/"*
            rm -rf "${DIR}/code_cache/"*
        fi
    done

    find /data/data/*/cache/* -delete &>/dev/null
    find /data/data/*/code_cache/* -delete &>/dev/null
    find /data/user_de/*/*/cache/* -delete &>/dev/null
    find /data/user_de/*/*/code_cache/* -delete &>/dev/null
    find /sdcard/Android/data/*/cache/* -delete &>/dev/null
}

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#         ARISE GMS PATCH ENGINE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GMS_PATCH() {
ui_print "- ARISE: Patching XML files"

GMS0="\"com.google.android.gms"\"
STR1="allow-in-power-save package=$GMS0"
STR2="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"

ui_print "- ARISE: Scanning system XML"

SYS_XML="$(
SXML="$(find /system_ext/* /system/* /product/* \
/vendor/* -type f -iname '*.xml' -print)"
for S in $SXML; do
  if grep -qE "$STR1|$STR2" $ROOT$S 2> $NULL; then
    echo "$S"
  fi
done
)"

PATCH_SX() {
for SX in $SYS_XML; do
  mkdir -p "$(dirname $MODPATH$SX)"
  cp -af $ROOT$SX $MODPATH$SX
  ui_print "  ARISE PATCH: $SX"
  sed -i "/$STR1/d;/$STR2/d" $MODPATH/$SX
done

for P in product vendor; do
  if [ -d $MODPATH/$P ]; then
    mkdir -p $MODPATH/system/$P
    mv -f $MODPATH/$P $MODPATH/system/
  fi
done
}

MOD_XML="$(
MXML="$(find /data/adb/* -type f -iname "*.xml" -print)"
for M in $MXML; do
  if grep -qE "$STR1|$STR2" $M; then
    echo "$M"
  fi
done
)"

PATCH_MX() {
ui_print "- ARISE: Checking conflicting modules"
for MX in $MOD_XML; do
  MOD="$(echo "$MX" | awk -F'/' '{print $5}')"
  ui_print "  Removing conflict: $MOD"
  sed -i "/$STR1/d;/$STR2/d" $MX
done
}

PATCH_SX && PATCH_MX

cd /data/data
find . -type f -name '*gms*' -delete
ui_print "- ARISE: Clearing GMS data"
}

# === DEVICE INFO ===
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)

NAME="ARISE GMS OPTIMIZER"
VERSION="ARISE SYSTEM CORE - REVISED-1"
DATE=$(date)

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#           ARISE DISPLAY BANNER
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

print_msg "
╔══════════════════════════════════════════════╗
║              𝐀𝐑𝐈𝐒𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐂𝐎𝐑𝐄              ║
║        GMS OPTIMIZER • PERFORMANCE AI       ║
║      SYSTEM CLEAN • BOOST • PATCH ENGINE    ║
╚══════════════════════════════════════════════╝
"

ui_print ""
sleep 0.5

print_msg " █████╗ ██████╗ ██╗███████╗███████╗ "
print_msg "██╔══██╗██╔══██╗██║██╔════╝██╔════╝ "
print_msg "███████║██████╔╝██║███████╗█████╗   "
print_msg "██╔══██║██╔══██╗██║╚════██║██╔══╝   "
print_msg "██║  ██║██║  ██║██║███████║███████╗ "
print_msg "╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝ "

ui_print ""
print_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_msg " ARISE ENGINE : ACTIVE"
print_msg " MODE         : SYSTEM OPTIMIZATION"
print_msg " GMS CONTROL  : ENABLED"
print_msg " DEVELOPER    : @ariseplugin"
print_msg "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""

#━━━━━━━━ EXECUTION ━━━━━━━━

print_msg "- Name            : ${NAME}"
print_msg "- Version         : ${VERSION}"
print_msg "- Android Version : ${ANDROIDVERSION:-Unknown}"
print_msg "- Date            : ${DATE}"
print_line
print_msg "- Device          : ${DEVICES:-Unknown}"
print_msg "- Manufacturer    : ${MANUFACTURER:-Unknown}"
print_line

print_msg "- Trimming partitions..."
trim_partition &>/dev/null
print_msg "- Cleaning cache & logs..."
delete_trash_logs &>/dev/null

sleep 2

# === PATCH EXECUTION ===
if [ "$AXERON" == "true" ]; then
    yes=yes
else
    GMS_PATCH
    ui_print "- ARISE: Setting permissions"
    set_perm_recursive $MODPATH 0 0 0755 0755
fi

logcat -c &>/dev/null
#━━━━━━━━ END OF ARISE MODULE ━━━━━━━━