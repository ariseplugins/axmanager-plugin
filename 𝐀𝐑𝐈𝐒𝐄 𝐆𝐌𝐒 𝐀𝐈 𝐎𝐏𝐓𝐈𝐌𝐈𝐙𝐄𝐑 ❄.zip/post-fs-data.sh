#!/sbin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#        𝐀𝐑𝐈𝐒𝐄 𝐆𝐌𝐒 𝐃𝐎𝐙𝐄 𝐏𝐀𝐓𝐂𝐇 𝐄𝐍𝐆𝐈𝐍𝐄
#     SYSTEM PRIVACY • DOZE CONTROL CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Developer : @ariseplugin
# Engine    : ARISE SYSTEM CORE
# Module    : GMS DOZE PATCH
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MODDIR=${0%/*}
dir=$MODDIR

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#            GMS DOZE FUNCTIONS
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

gms_doze_patch() {

GMS0="\"com.google.android.gms"\"
STR1="allow-unthrottled-location package=$GMS0"
STR2="allow-ignore-location-settings package=$GMS0"
STR3="allow-in-power-save package=$GMS0"
STR4="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"

find /data/adb/* -type f -iname "*.xml" -print |
while IFS= read -r XML; do
  for X in $XML; do
    if grep -qE "$STR1|$STR2|$STR3|$STR4" $X 2> $NULL; then
      sed -i "/$STR1/d;/$STR2/d;/$STR3/d;/$STR4/d" $X
    fi
  done
done

}

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#             EXECUTION CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

gms_doze_patch

#━━━━━━━━ END OF ARISE MODULE ━━━━━━━━