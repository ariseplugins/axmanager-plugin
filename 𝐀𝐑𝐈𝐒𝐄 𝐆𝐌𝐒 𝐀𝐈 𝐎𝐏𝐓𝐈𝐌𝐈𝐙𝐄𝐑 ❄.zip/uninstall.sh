#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#        𝐀𝐑𝐈𝐒𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐂𝐎𝐑𝐄
#     GMS RESTORE • NETWORK SYNC ENGINE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Developer : @ariseplugin
# Engine    : ARISE EXECUTION LAYER
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ARISE_EXEC() {

# Don't modify anything after this
pm enable com.google.android.gms/.auth.managed.admin.DeviceAdminReceiver;pm enable com.google.android.gms/.mdm.receivers.MdmDeviceAdminReceiver;pm enable com.google.android.gms/.chimera.GmsIntentOperationService;dumpsys deviceidle unforce;dumpsys deviceidle disable all;settings put global gms_checkin_timeout_min 6;settings delete secure assistant;settings delete secure smartspace;settings delete global google_core_control;settings delete global hotword_detection_enabled;settings delete secure systemui.google.opa_enabled;settings delete secure adaptive_connectivity_enabled;settings delete system gearhead:driving_mode_settings_enabled;for a in $(cmd package list packages -a | cut -f2 -d: | grep "gms" | grep -v "revanced");do dumpsys deviceidle whitelist +"$a";dumpsys deviceidle sys-whitelist +"$a";am set-inactive --user 0 "$a" false;cmd activity compat reset-all "$gms";pm log-visibility "$a" --enable;am set-standby-bucket --user 0 "$a" active;cmd app_hibernation set-state "$a" false;cmd tare set-vip 0 "$a" false;am set-foreground-service-delegate --user 0 "$a" start;cmd activity unfreeze --sticky "$(pidof $a)";cmd connectivity set-package-networking-enabled true "$a";cmd connectivity set-background-networking-enabled-for-uid "$a" true;cmd sdk_sandbox start "$a";cmd appops reset "$a";done

}

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EXECUTE ARISE CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ARISE_EXEC