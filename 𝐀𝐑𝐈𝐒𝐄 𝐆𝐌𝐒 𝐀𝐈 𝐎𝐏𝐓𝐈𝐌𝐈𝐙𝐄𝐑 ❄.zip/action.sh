# --- ARISE GMS OPTIMIZATION CHECKER ---
# Developer: @ariseplugin | @fckstark69

GMS="com.google.android.gms"
NULL="/dev/null"

INK='\033[38;5;81m'
NEON='\033[38;5;51m'
WHITE='\033[1;37m'
GREEN='\033[1;92m'
YELLOW='\033[1;93m'
RED='\033[1;91m'
RESET='\033[0m'

echo -e "${NEON}╔══════════════════════════════════════╗${RESET}"
echo -e "${NEON}║        ARISE SYSTEM ANALYZER        ║${RESET}"
echo -e "${NEON}║     GMS OPTIMIZATION CHECK CORE     ║${RESET}"
echo -e "${NEON}╚══════════════════════════════════════╝${RESET}"

CHK_OPT() {
    echo ""
    echo -e "${INK}[•] Checking Google Play Services optimization status...${RESET}"

    # --- ROOT / ADB MODE DETECTION ---
    ROOT_MODE=false
    if command -v su >/dev/null 2>&1; then
       ROOT_MODE=true
    fi

    if [ "$ROOT_MODE" = true ]; then
        # --- ROOT MODE ---
        if cmd deviceidle whitelist | grep -q "$GMS"; then
            echo -e "${GREEN}[✓] $1 Optimized${RESET}"
            echo -e "${WHITE}→ Managed by Doze Mode (idle allowed)${RESET}"
            echo -e "${WHITE}→ Background CPU load reduced${RESET}"
            echo -e "${WHITE}→ Battery efficient state active${RESET}"
        else
            echo -e "${YELLOW}[!] $1 Not fully optimized${RESET}"
            echo -e "${WHITE}→ Not found in Doze whitelist${RESET}"
        fi

    else
        # --- NON-ROOT MODE ---
        if dumpsys deviceidle >/dev/null 2>&1; then
            OPT_STATE=$(dumpsys deviceidle 2> $NULL | grep -m 1 "mDeepEnabled=")
            if echo "$OPT_STATE" | grep -q "true"; then
                echo -e "${GREEN}[✓] $1 Optimized (Doze Active)${RESET}"
                echo -e "${WHITE}→ System battery saver behavior enabled${RESET}"
                echo -e "${WHITE}→ Background sync delayed during idle${RESET}"
            else
                echo -e "${RED}[X] $1 Not Optimized${RESET}"
                echo -e "${WHITE}→ App is NOT restricted by Doze${RESET}"
                echo -e "${WHITE}→ Runs actively in background services${RESET}"
                echo -e "${YELLOW}⚠ Requires ROOT/ADB for modification${RESET}"
            fi
        fi
    fi
}

echo ""
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

CHK_OPT "Google Play Services status"

echo ""
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}ARISE ENGINE: ANALYSIS COMPLETE${RESET}"
echo -e "${WHITE}DEVELOPERS: @ariseplugin | @fckstark69${RESET}"
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"