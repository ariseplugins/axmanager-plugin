#!/system/bin/sh
# action.sh

# =========================================================
# VELOCITY ACTION ENGINE
# =========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}"
echo "========================================================"
echo "               VELOCITY ACTION ENGINE"
echo "========================================================"
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[1/18] disabling animation delays${RESET}"
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
sleep 1

echo -e "${GREEN}[2/18] optimizing touch responsiveness${RESET}"
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
sleep 1

echo -e "${GREEN}[3/18] reducing background standby${RESET}"
settings put global app_standby_enabled 0
sleep 1

echo -e "${GREEN}[4/18] enabling game driver support${RESET}"
settings put global game_driver_all_apps 1
sleep 1

echo -e "${GREEN}[5/18] reducing phantom process monitoring${RESET}"
settings put global settings_enable_monitor_phantom_procs false
sleep 1

echo -e "${GREEN}[6/18] optimizing display synchronization${RESET}"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
sleep 1

echo -e "${GREEN}[7/18] tuning HWUI rendering${RESET}"
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
sleep 1

echo -e "${GREEN}[8/18] reducing idle restrictions${RESET}"
cmd deviceidle disable
sleep 1

echo -e "${GREEN}[9/18] optimizing memory factor${RESET}"
cmd activity memory-factor set 0 2>/dev/null
sleep 1

echo -e "${GREEN}[10/18] optimizing frame pacing${RESET}"
setprop debug.sf.frame_rate_multiple_threshold 90
sleep 1

echo -e "${GREEN}[11/18] optimizing rendering pipeline${RESET}"
setprop debug.stagefright.ccodec 4
sleep 1

echo -e "${GREEN}[12/18] optimizing graphics engine${RESET}"
setprop debug.hwui.renderer skiagl
sleep 1

echo -e "${GREEN}[13/18] reducing launcher redraws${RESET}"
cmd package bg-dexopt-job 2>/dev/null
sleep 1

echo -e "${GREEN}[14/18] applying runtime cleanup${RESET}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sleep 1

echo -e "${GREEN}[15/18] optimizing thermal balancing${RESET}"
setprop debug.thermal.throttle.support no 2>/dev/null
sleep 1

echo -e "${GREEN}[16/18] optimizing game responsiveness${RESET}"
cmd power set-fixed-performance-mode-enabled true 2>/dev/null
sleep 1

echo -e "${GREEN}[17/18] stabilizing gaming environment${RESET}"
settings put global fstrim_mandatory_interval 1
sleep 1

echo -e "${GREEN}[18/18] finalizing runtime engine${RESET}"
sleep 1

echo ""
echo -e "${RED}[DONE] velocity runtime optimization applied${RESET}"
echo ""