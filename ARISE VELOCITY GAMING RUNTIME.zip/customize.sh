#!/system/bin/sh
# customize.sh

# =========================================================
# VELOCITY GAMING RUNTIME INSTALLER
# =========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
WHITE="\033[1;37m"
GREY="\033[90m"
RESET="\033[0m"

clear

DATE=$(date)
DEVICE=$(getprop ro.product.brand)
MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)
SOC=$(getprop ro.board.platform)

echo -e "${CYAN}"
echo "========================================================"
echo "             VELOCITY GAMING RUNTIME"
echo "========================================================"
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[DATE]${RESET} ${WHITE}$DATE${RESET}"
echo -e "${GREEN}[BRAND]${RESET} ${WHITE}$DEVICE${RESET}"
echo -e "${GREEN}[MODEL]${RESET} ${WHITE}$MODEL${RESET}"
echo -e "${GREEN}[ANDROID]${RESET} ${WHITE}$ANDROID${RESET}"
echo -e "${GREEN}[SOC]${RESET} ${WHITE}$SOC${RESET}"
echo ""

sleep 1

echo -e "${YELLOW}[INFO] scanning gaming environment...${RESET}"
sleep 1

echo -e "${YELLOW}[INFO] preparing optimization layers...${RESET}"
sleep 1

echo -e "${YELLOW}[INFO] configuring runtime permissions...${RESET}"
sleep 1

echo -e "${YELLOW}[INFO] verifying service engine integrity...${RESET}"
sleep 1

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

sleep 1

echo ""
echo -e "${CYAN}"
echo "========================================================"
echo "              INSTALLATION COMPLETED"
echo "========================================================"
echo -e "${RESET}"

echo -e "${WHITE}Reboot recommended for full gaming optimization${RESET}"
echo ""