#!/system/bin/sh
# service.sh

# ==========================================================
# QUANTUM CODM SERVICE ENGINE
# ==========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
GREY="\033[90m"
RESET="\033[0m"

log() {
echo -e "${CYAN}[QUANTUM ENGINE]${RESET} $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 2
done

sleep 10

DATE=$(date)
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
REFRESH=$(settings get system peak_refresh_rate 2>/dev/null || echo 60)

clear

echo -e "${CYAN}"
echo "###########################################################"
echo "#               QUANTUM CODM SERVICE ENGINE               #"
echo "###########################################################"
echo -e "${RESET}"

echo -e "${GREEN}[DATE]${RESET} ${WHITE}$DATE${RESET}"
echo -e "${GREEN}[BRAND]${RESET} ${WHITE}$BRAND${RESET}"
echo -e "${GREEN}[MODEL]${RESET} ${WHITE}$MODEL${RESET}"
echo -e "${GREEN}[ANDROID]${RESET} ${WHITE}$ANDROID${RESET}"
echo -e "${GREEN}[RAM]${RESET} ${WHITE}$RAM KB${RESET}"
echo -e "${GREEN}[REFRESH RATE]${RESET} ${WHITE}$REFRESH Hz${RESET}"

echo ""
sleep 1

# ==========================================================
# DEVICE PROFILE DETECTION
# ==========================================================

if [ "$RAM" -ge 10000000 ]; then
PROFILE="ULTRA FPS PROFILE"
FPSMODE="144"
DOWNSCALE="0.85"

elif [ "$RAM" -ge 8000000 ]; then
PROFILE="HIGH FPS PROFILE"
FPSMODE="120"
DOWNSCALE="0.78"

elif [ "$RAM" -ge 6000000 ]; then
PROFILE="BALANCED FPS PROFILE"
FPSMODE="90"
DOWNSCALE="0.72"

else
PROFILE="STABLE FPS PROFILE"
FPSMODE="60"
DOWNSCALE="0.65"
fi

echo ""
echo -e "${YELLOW}[PROFILE DETECTED]${RESET} ${WHITE}$PROFILE${RESET}"
echo -e "${YELLOW}[TARGET FPS]${RESET} ${WHITE}$FPSMODE FPS${RESET}"
echo -e "${YELLOW}[DOWNSCALE]${RESET} ${WHITE}$DOWNSCALE${RESET}"
echo ""

sleep 1

# ==========================================================
# MAIN OPTIMIZATION
# ==========================================================

log "preparing gaming runtime"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

settings put global app_standby_enabled 0
settings put global settings_enable_monitor_phantom_procs false

cmd activity memory-factor set 0 2>/dev/null

cmd display set-match-content-frame-rate-pref 1 2>/dev/null

settings put global game_driver_all_apps 1

cmd deviceidle disable

setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
setprop debug.stagefright.ccodec 4
setprop debug.sf.frame_rate_multiple_threshold 90
setprop debug.hwui.renderer skiagl

settings put system peak_refresh_rate $FPSMODE
settings put system min_refresh_rate 60

# ==========================================================
# CODM DETECTION
# ==========================================================

if pm list packages | grep -q "com.garena.game.codm"; then

echo -e "${GREEN}[CODM DETECTED] applying FPS profile${RESET}"

cmd game mode performance com.garena.game.codm 2>/dev/null

device_config put game_overlay \
com.garena.game.codm \
mode=2,downscaleFactor=$DOWNSCALE,fps=$FPSMODE

cmd package compile -m speed \
--check-prof true \
com.garena.game.codm

pid=$(pidof com.garena.game.codm)

if [ -n "$pid" ]; then
renice -n -5 -p $pid
fi

fi

# ==========================================================
# PERFORMANCE BOOST
# ==========================================================

log "optimizing runtime responsiveness"

cmd power set-fixed-performance-mode-enabled true 2>/dev/null

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sleep 1

echo ""
echo -e "${RED}[ENGINE ACTIVE] QUANTUM FPS ENGINE ENABLED${RESET}"
echo ""