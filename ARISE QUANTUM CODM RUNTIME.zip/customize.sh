#!/system/bin/sh
# customize.sh

# ==========================================================
# QUANTUM CODM RUNTIME INSTALLER
# ==========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
RED="\033[1;31m"
YELLOW="\033[1;33m"
WHITE="\033[1;37m"
GREY="\033[90m"
RESET="\033[0m"

clear

DATE=$(date)
DEVICE=$(getprop ro.product.brand)
MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)
SOC=$(getprop ro.board.platform)

echo -e "${CYAN}"
echo "#########################################################"
echo "#               QUANTUM CODM RUNTIME                    #"
echo "#########################################################"
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[SYSTEM DATE]${RESET} ${WHITE}$DATE${RESET}"
echo -e "${GREEN}[DEVICE BRAND]${RESET} ${WHITE}$DEVICE${RESET}"
echo -e "${GREEN}[DEVICE MODEL]${RESET} ${WHITE}$MODEL${RESET}"
echo -e "${GREEN}[ANDROID VERSION]${RESET} ${WHITE}$ANDROID${RESET}"
echo -e "${GREEN}[SOC PLATFORM]${RESET} ${WHITE}$SOC${RESET}"

echo ""
sleep 1

echo -e "${YELLOW}[CHECK] scanning CODM environment...${RESET}"
sleep 1

echo -e "${YELLOW}[CHECK] preparing FPS stability engine...${RESET}"
sleep 1

echo -e "${YELLOW}[CHECK] preparing refresh synchronization...${RESET}"
sleep 1

echo -e "${YELLOW}[CHECK] configuring runtime permissions...${RESET}"
sleep 1

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

sleep 1

echo ""
echo -e "${CYAN}"
echo "#########################################################"
echo "#               INSTALLATION COMPLETE                   #"
echo "#########################################################"
echo -e "${RESET}"

echo -e "${WHITE}Reboot device for full runtime activation${RESET}"
echo ""