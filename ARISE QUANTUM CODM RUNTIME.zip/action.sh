#!/system/bin/sh
# action.sh

# ==========================================================
# QUANTUM FPS ACTION ENGINE
# ==========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}"
echo "#########################################################"
echo "#                QUANTUM ACTION ENGINE                  #"
echo "#########################################################"
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[1/20] disabling animation delays${RESET}"
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
sleep 1

echo -e "${GREEN}[2/20] optimizing touch response${RESET}"
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
sleep 1

echo -e "${GREEN}[3/20] enabling game driver optimization${RESET}"
settings put global game_driver_all_apps 1
sleep 1

echo -e "${GREEN}[4/20] reducing phantom process interference${RESET}"
settings put global settings_enable_monitor_phantom_procs false
sleep 1

echo -e "${GREEN}[5/20] reducing standby activity${RESET}"
settings put global app_standby_enabled 0
sleep 1

echo -e "${GREEN}[6/20] optimizing display synchronization${RESET}"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
sleep 1

echo -e "${GREEN}[7/20] optimizing HWUI rendering${RESET}"
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
sleep 1

echo -e "${GREEN}[8/20] optimizing SurfaceFlinger timing${RESET}"
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late_phase_offset_ns 1500000
sleep 1

echo -e "${GREEN}[9/20] optimizing frame pacing${RESET}"
setprop debug.sf.frame_rate_multiple_threshold 90
sleep 1

echo -e "${GREEN}[10/20] optimizing rendering pipeline${RESET}"
setprop debug.stagefright.ccodec 4
sleep 1

echo -e "${GREEN}[11/20] enabling skiagl renderer${RESET}"
setprop debug.hwui.renderer skiagl
sleep 1

echo -e "${GREEN}[12/20] reducing idle restrictions${RESET}"
cmd deviceidle disable
sleep 1

echo -e "${GREEN}[13/20] optimizing runtime memory${RESET}"
cmd activity memory-factor set 0 2>/dev/null
sleep 1

echo -e "${GREEN}[14/20] optimizing thermal balance${RESET}"
setprop debug.thermal.throttle.support no 2>/dev/null
sleep 1

echo -e "${GREEN}[15/20] enabling stable gaming mode${RESET}"
cmd power set-fixed-performance-mode-enabled true 2>/dev/null
sleep 1

echo -e "${GREEN}[16/20] optimizing launcher redraws${RESET}"
cmd package bg-dexopt-job 2>/dev/null
sleep 1

echo -e "${GREEN}[17/20] optimizing runtime cleanup${RESET}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sleep 1

echo -e "${GREEN}[18/20] stabilizing refresh behavior${RESET}"
settings put system peak_refresh_rate 144
sleep 1

echo -e "${GREEN}[19/20] optimizing gaming responsiveness${RESET}"
settings put system min_refresh_rate 60
sleep 1

echo -e "${GREEN}[20/20] finalizing FPS engine${RESET}"
sleep 1

echo ""
echo -e "${RED}[DONE] quantum runtime optimization complete${RESET}"
echo ""