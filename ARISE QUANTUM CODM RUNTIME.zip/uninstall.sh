#!/system/bin/sh
# uninstall.sh

# ==========================================================
# QUANTUM RESET ENGINE
# ==========================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}"
echo "#########################################################"
echo "#                 QUANTUM RESET ENGINE                  #"
echo "#########################################################"
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[RESET] restoring animations${RESET}"

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

sleep 1

echo -e "${GREEN}[RESET] restoring standby behavior${RESET}"

settings put global app_standby_enabled 1
settings put global settings_enable_monitor_phantom_procs true

sleep 1

echo -e "${GREEN}[RESET] restoring display synchronization${RESET}"

cmd display set-match-content-frame-rate-pref 0 2>/dev/null

sleep 1

echo -e "${GREEN}[RESET] restoring refresh rate${RESET}"

settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60

sleep 1

echo -e "${GREEN}[RESET] restoring HWUI values${RESET}"

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_hint_manager false

sleep 1

echo -e "${GREEN}[RESET] restoring thermal defaults${RESET}"

setprop debug.thermal.throttle.support yes 2>/dev/null

sleep 1

echo -e "${GREEN}[RESET] enabling idle restrictions${RESET}"

cmd deviceidle enable

sleep 1

echo -e "${GREEN}[RESET] restoring CODM profile${RESET}"

cmd game mode standard com.garena.game.codm 2>/dev/null

device_config delete game_overlay com.garena.game.codm

sleep 1

echo -e "${GREEN}[RESET] cleaning runtime cache${RESET}"

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sleep 1

echo ""
echo -e "${RED}[DONE] quantum runtime removed successfully${RESET}"
echo ""