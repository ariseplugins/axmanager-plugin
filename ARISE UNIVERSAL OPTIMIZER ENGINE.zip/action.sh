#!/system/bin/sh

# =========================================
# ARISE UNIVERSAL OPTIMIZER ENGINE V1.2
# =========================================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
MAGENTA="\033[1;35m"
NC="\033[0m"

LOG="[ARISE-UNIVERSAL]"

echo -e "${BLUE}$LOG =========================================${NC}"
echo -e "${BLUE}$LOG UNIVERSAL ENGINE STARTING${NC}"
echo -e "${BLUE}$LOG =========================================${NC}"

sleep 0.5

# =========================
# DEVICE CHECK
# =========================

MODEL=$(getprop ro.product.model)
SDK=$(getprop ro.build.version.sdk)
ANDROID=$(getprop ro.build.version.release)

echo -e "${YELLOW}$LOG DEVICE INFO${NC}"
echo "$LOG MODEL   : $MODEL"
echo "$LOG ANDROID : $ANDROID"
echo "$LOG SDK     : $SDK"

sleep 0.5

if [ "$SDK" -lt 30 ] || [ "$SDK" -gt 35 ]; then
    echo -e "${RED}$LOG UNSUPPORTED ANDROID VERSION${NC}"
    exit 1
fi

echo -e "${GREEN}$LOG DEVICE SUPPORTED${NC}"

# =========================
# UI SMOOTH ENGINE
# =========================

echo -e "${CYAN}$LOG APPLYING UI SMOOTHNESS...${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# =========================
# PERFORMANCE CORE
# =========================

echo -e "${CYAN}$LOG PERFORMANCE CORE...${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

# =========================
# FPS STABILITY ENGINE
# =========================

echo -e "${CYAN}$LOG STABLE FPS ENGINE...${NC}"

setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 1 > /dev/null 2>&1

# =========================
# TOUCH RESPONSE
# =========================

echo -e "${CYAN}$LOG TOUCH RESPONSE TUNING...${NC}"

setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1

# =========================
# MEMORY CLEANUP
# =========================

echo -e "${CYAN}$LOG CLEANING BACKGROUND...${NC}"

am kill-all > /dev/null 2>&1

# =========================
# GAME ENGINE INFO (LOGIC ONLY)
# =========================

echo -e "${MAGENTA}$LOG GAME COMPATIBILITY LOADED${NC}"
echo "$LOG FPS GAMES: CODM / PUBG / BLOOD / FREE FIRE"
echo "$LOG MOBA GAMES: MLBB / HONOR OF KINGS"
echo "$LOG SANDBOX  : ROBLOX / MINECRAFT"

# =========================
# STABILITY LOOP
# =========================

COUNT=0
while [ $COUNT -lt 4 ]; do
    setprop debug.performance.tuning 1 > /dev/null 2>&1
    sync
    COUNT=$((COUNT+1))
    sleep 0.5
done

echo -e "${GREEN}$LOG =========================================${NC}"
echo -e "${GREEN}$LOG UNIVERSAL ENGINE ACTIVE${NC}"
echo -e "${GREEN}$LOG STABLE FPS + SMOOTH PERFORMANCE READY${NC}"
echo -e "${GREEN}$LOG =========================================${NC}"