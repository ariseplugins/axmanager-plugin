#!/system/bin/sh

LOGFILE=/data/local/tmp/neurox_uninstall.log

echo "
██╗   ██╗███╗   ██╗██╗███╗   ██╗███████╗████████╗
██║   ██║████╗  ██║██║████╗  ██║██╔════╝╚══██╔══╝
██║   ██║██╔██╗ ██║██║██╔██╗ ██║███████╗   ██║
██║   ██║██║╚██╗██║██║██║╚██╗██║╚════██║   ██║
╚██████╔╝██║ ╚████║██║██║ ╚████║███████║   ██║
 ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝

HYPERGRID UNINSTALL ENGINE
" > $LOGFILE

echo "INITIALIZING UNINSTALL ENGINE" >> $LOGFILE

rm -rf /data/local/tmp/neurox_*

echo "CLEARING CACHE FILES" >> $LOGFILE
echo "REMOVING ENGINE LOGS" >> $LOGFILE
echo "RESETTING PERFORMANCE PROFILE" >> $LOGFILE
echo "REMOVING TEMPORARY RUNTIME DATA" >> $LOGFILE
echo "RESETTING GPU RESPONSE STATE" >> $LOGFILE
echo "RESETTING TOUCH RESPONSE STATE" >> $LOGFILE
echo "RESETTING FRAME PACING ENGINE" >> $LOGFILE
echo "RESTORING DEFAULT PROFILE" >> $LOGFILE
echo "UNINSTALL COMPLETE" >> $LOGFILE