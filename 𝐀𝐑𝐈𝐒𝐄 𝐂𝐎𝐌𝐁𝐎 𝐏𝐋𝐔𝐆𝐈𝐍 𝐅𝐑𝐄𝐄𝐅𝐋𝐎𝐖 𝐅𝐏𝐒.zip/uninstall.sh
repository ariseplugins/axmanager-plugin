#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#     𝗔𝗥𝗜𝗦𝗘 𝗖𝗢𝗠𝗕𝗢 𝗥𝗘𝗦𝗘𝗧 𝗘𝗡𝗚𝗜𝗡𝗘
#   SAFE RESTORE / GAME RESET MODULE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RED="\033[1;31m"
CYAN="\033[1;36m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
WHITE="\033[1;97m"
RESET="\033[0m"

package="com.garena.game.codm"

log() {
  echo -e "${CYAN}[ARISE RESET]${RESET} ${WHITE}$1${RESET}"
}

clear

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   ARISE COMBO RESET ENGINE${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Starting system rollback process..."

#━━━━━━━━ DISPLAY RESET ━━━━━━━━
settings put system peak_refresh_rate 90.0
settings put system min_refresh_rate 60.0
log "Refresh rate reset (60Hz baseline)"

#━━━━━━━━ RENDER RESET ━━━━━━━━
setprop debug.hwui.renderer ""
settings put global sem_enhanced_cpu_responsiveness 0
log "Rendering + CPU boost reverted"

#━━━━━━━━ GAME RESET ━━━━━━━━
cmd device_config delete game_overlay "$package" 2>/dev/null

if [ "$(getprop ro.build.version.release)" -ge 12 ]; then
    cmd game reset "$package" 2>/dev/null
fi

log "Game overlay and mode reset completed"

#━━━━━━━━ BACKGROUND RESET ━━━━━━━━
cmd appops set "$package" RUN_ANY_IN_BACKGROUND deny
cmd appops set "$package" RUN_IN_BACKGROUND deny

dumpsys deviceidle whitelist -"$package" 2>/dev/null
am set-standby-bucket "$package" restricted

log "Background restrictions restored"

#━━━━━━━━ PERFORMANCE RESET ━━━━━━━━
cmd power set-fixed-performance-mode-enabled false 2>/dev/null
log "Performance mode disabled"

#━━━━━━━━ EXTRA ARISE RESET LAYER ━━━━━━━━
cmd activity reset-restrictions "$package" 2>/dev/null
cmd appops reset "$package" 2>/dev/null
cmd device_config reset 2>/dev/null

sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   ARISE RESET COMPLETE${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "All optimizations reverted successfully"
log "System returned to default state"