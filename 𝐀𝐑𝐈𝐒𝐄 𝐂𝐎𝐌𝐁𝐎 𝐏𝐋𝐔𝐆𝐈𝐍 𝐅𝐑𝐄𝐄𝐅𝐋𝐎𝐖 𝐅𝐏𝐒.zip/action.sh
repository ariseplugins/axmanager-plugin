#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#     𝗔𝗥𝗜𝗦𝗘 𝗖𝗢𝗠𝗕𝗢 𝗣𝗟𝗨𝗚𝗜𝗡
# 𝗙𝗥𝗘𝗘𝗙𝗟𝗢𝗪 𝗙𝗣𝗦/𝗦𝗧𝗔𝗕𝗟𝗘/𝟲𝟬/𝟵𝟬/𝟭𝟮𝟬/𝟭𝟰𝟰𝗛𝗭
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RED="\033[1;31m"
GREEN="\033[1;32m"
CYAN="\033[1;36m"
BLUE="\033[1;34m"
YELLOW="\033[1;33m"
PURPLE="\033[1;35m"
GRAY="\033[1;90m"
WHITE="\033[1;97m"
RESET="\033[0m"

LOG="/sdcard/ARISE_COMBO_PLUGIN.log"

log() {
    echo -e "${CYAN}[ARISE COMBO]${RESET} ${WHITE}$1${RESET}" | tee -a "$LOG"
}

clear

echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝗔𝗥𝗜𝗦𝗘 𝗖𝗢𝗠𝗕𝗢 𝗣𝗟𝗨𝗚𝗜𝗡 ENGINE${RESET}"
echo -e "${CYAN} FREEFLOW FPS / STABLE / HZ ADAPTIVE${RESET}"
echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Initializing ARISE COMBO ENGINE..."

package="com.garena.game.codm"

#━━━━━━━━ DEVICE INFO ━━━━━━━━
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

echo -e "${BLUE}━━━━━━━━ DEVICE INFO ━━━━━━━━${RESET}"
echo -e "${WHITE}RAM     : ${GREEN}${RAM_KB} KB${RESET}"
echo -e "${WHITE}CPU     : ${GREEN}${CPU_MAX_FREQ}${RESET}"
echo -e "${WHITE}ANDROID : ${GREEN}${ANDROID_VER}${RESET}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

log "Device scan completed"

#━━━━━━━━ PROFILE ENGINE ━━━━━━━━
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  downscale="0.53"
  fps="120"
  CLASS="𝗛𝗜𝗚𝗛-𝗘𝗡𝗗 𝗦𝗧𝗔𝗕𝗟𝗘"
elif [ "$RAM_KB" -ge 6000000 ]; then
  downscale="0.49"
  fps="120"
  CLASS="𝗨𝗣𝗣𝗘𝗥 𝗠𝗜𝗗 𝗦𝗧𝗔𝗕𝗟𝗘"
elif [ "$RAM_KB" -ge 4000000 ]; then
  downscale="0.47"
  fps="90"
  CLASS="𝗠𝗜𝗗 𝗙𝗣𝗦 𝗦𝗧𝗔𝗕𝗟𝗘"
else
  downscale="0.45"
  fps="60"
  CLASS="𝗟𝗢𝗪 𝗘𝗡𝗗 𝗦𝗧𝗔𝗕𝗟𝗘"
fi

echo -e "${YELLOW}━━━━━━━━ PERFORMANCE PROFILE ━━━━━━━━${RESET}"
echo -e "${WHITE}CLASS   : ${CYAN}$CLASS${RESET}"
echo -e "${WHITE}FPS     : ${CYAN}$fps${RESET}"
echo -e "${WHITE}SCALE   : ${CYAN}$downscale${RESET}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

log "Profile selected: $CLASS"

#━━━━━━━━ GAME ENGINE ━━━━━━━━
log "Applying Game Overlay..."
cmd device_config put game_overlay "$package" mode=2,downscaleFactor="$downscale",useAngle=false,fps="$fps",loadingBoost=1073741824
log "Game overlay applied"

log "Setting Game Mode..."
if [ "$ANDROID_VER" = "12" ]; then
    cmd game set --mode 2 --downscale "$downscale" --fps "$fps" "$package"
else
    cmd game mode 2 "$package"
fi

#━━━━━━━━ DISPLAY ENGINE ━━━━━━━━
log "Forcing refresh rate..."
settings put system peak_refresh_rate $fps
settings put system min_refresh_rate $fps

#━━━━━━━━ RENDER ENGINE ━━━━━━━━
setprop debug.force-opengl 1
settings put system multicore_packet_scheduler 1

#━━━━━━━━ COMPILE ENGINE ━━━━━━━━
log "Compiling CODM for performance..."
cmd package compile -m speed-profile -f "$package"

#━━━━━━━━ BACKGROUND ENGINE ━━━━━━━━
cmd appops set "$package" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$package" RUN_IN_BACKGROUND allow

#━━━━━━━━ SYSTEM BOOST ━━━━━━━━
dumpsys deviceidle whitelist +"$package"
am set-standby-bucket "$package" active
cmd power set-fixed-performance-mode-enabled true

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝗔𝗥𝗜𝗦𝗘 𝗖𝗢𝗠𝗕𝗢 𝗣𝗟𝗨𝗚𝗜𝗡 ACTIVE${RESET}"
echo -e "${GREEN}   FPS STABLE + HZ ADAPTIVE ENGINE${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

log "CODM optimization completed"
log "Final FPS: $fps | Scale: $downscale"
log "Log saved: $LOG"