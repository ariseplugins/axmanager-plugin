#!/system/bin/sh

ui_print ""
ui_print "========================================"
ui_print "        𝙰𝚁𝙸𝚂𝙴 𝚄𝙽𝙸𝙽𝚂𝚃𝙰𝙻𝙻𝙴𝚁"
ui_print "========================================"
ui_print ""

ui_print "[INFO] Restoring default Android behavior..."
ui_print "[INFO] Removing ARISE system tuning layer..."
ui_print ""

# Restore animation values
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

# Reset memory behavior
cmd activity memory-factor reset 2>/dev/null

# Restore thermal default behavior
setprop debug.thermal.throttle.support true 2>/dev/null

# Optional cache clean hint
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

ui_print ""
ui_print "[OK] System behavior restored successfully"
ui_print "[OK] ARISE framework removed safely"
ui_print ""

ui_print "========================================"
ui_print "           — ARISE SYSTEM —"
ui_print "========================================"
ui_print ""