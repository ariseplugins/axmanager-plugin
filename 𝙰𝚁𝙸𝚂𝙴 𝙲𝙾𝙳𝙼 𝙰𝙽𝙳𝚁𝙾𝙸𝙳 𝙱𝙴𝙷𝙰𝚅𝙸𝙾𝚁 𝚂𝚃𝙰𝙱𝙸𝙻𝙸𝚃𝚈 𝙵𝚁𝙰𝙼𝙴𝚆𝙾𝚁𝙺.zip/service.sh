#!/system/bin/sh

# ARISE CODM ANDROID BEHAVIOR STABILITY FRAMEWORK
# Engine Layer - Service Runtime Optimization

log() {
  echo "[ARISE ENGINE] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed. Starting ARISE CODM Behavior Engine..."

FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)

log "Detected refresh rate: $FPS"

CHIPSET=$(getprop ro.hardware | tr 'A-Z' 'a-z')
SOC_VENDOR=$(getprop ro.soc.manufacturer | tr 'A-Z' 'a-z')

IS_MTK=0
IS_QCOM=0
IS_UNISOC=0

echo "$CHIPSET $SOC_VENDOR" | grep -q "mtk\|mediatek" && IS_MTK=1
echo "$CHIPSET $SOC_VENDOR" | grep -q "qcom\|qualcomm" && IS_QCOM=1
echo "$CHIPSET $SOC_VENDOR" | grep -q "unisoc\|spreadtrum" && IS_UNISOC=1

SAFE_FPS=60

# MEDIATEK
if [ "$IS_MTK" -eq 1 ]; then
  log "MediaTek detected - Applying SAFE Stability Mode"

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null

  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 1800000 > "$cpu" 2>/dev/null
  done

  setprop vendor.thermal.throttle.enable true
  setprop persist.vendor.mtk.thermal.limit 1

  log "MTK stability profile applied"
fi

# SNAPDRAGON
if [ "$IS_QCOM" -eq 1 ]; then
  log "Snapdragon detected - Applying SAFE Stability Mode"

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null

  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 2000000 > "$cpu" 2>/dev/null
  done

  setprop debug.hwui.max_fps $SAFE_FPS
  setprop debug.hwui.force_gpu_rendering true

  log "Snapdragon stability profile applied"
fi

# UNISOC
if [ "$IS_UNISOC" -eq 1 ]; then
  log "UNISOC detected - Applying SAFE Stability Mode"

  settings put system peak_refresh_rate $SAFE_FPS 2>/dev/null
  settings put system min_refresh_rate $SAFE_FPS 2>/dev/null

  for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    echo 1600000 > "$cpu" 2>/dev/null
  done

  setprop persist.vendor.sys.sprd.log 0
  setprop persist.sys.sprd.log 0

  log "UNISOC stability profile applied"
fi

# DEVICE INFO
RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

log "Device Info - RAM: $RAM_KB | CPU: $CPU_MAX_FREQ | Android: $ANDROID_VER"

# DEVICE CLASS
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.5
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.49
  CLASS="MID-HIGH"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.48
  CLASS="MID"
else
  DOWNSCALE=0.47
  CLASS="LOW-END"
fi

log "Device Class: $CLASS | Downscale: $DOWNSCALE"

# UI OPTIMIZATION
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# DISPLAY OPTIMIZATION
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null

# MEMORY OPTIMIZATION
cmd activity memory-factor set 0 2>/dev/null
settings put global settings_enable_monitor_phantom_procs false
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1

# TOUCH RESPONSE
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null

# THERMAL
setprop debug.thermal.throttle.support no 2>/dev/null

# GAME LOOP APPLY
log "Applying ARISE stability profile to installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=$FPS

  cmd game mode performance "$pkg"

  log "Optimized: $pkg"
done

# ANDROID 14+
if [ "$ANDROID_VER" -ge 14 ]; then
  log "Applying Android 14+ game behavior flags..."

  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
fi

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "ARISE ENGINE successfully applied"