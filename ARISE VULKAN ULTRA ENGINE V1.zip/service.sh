#!/system/bin/sh

log() {
echo "[ARISE VULKAN ENGINE V1] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 2
done

log "Boot detected. Starting VULKAN ULTRA ENGINE V1..."

# =========================
# DEVICE DETECTION
# =========================

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')

if [ "$RAM_KB" -ge 8000000 ]; then
CLASS="HIGH"
DOWNSCALE=0.75
MODE="QUALITY"
elif [ "$RAM_KB" -ge 5000000 ]; then
CLASS="MID"
DOWNSCALE=0.60
MODE="BALANCED"
else
CLASS="LOW"
DOWNSCALE=0.50
MODE="ULTRA FPS"
fi

log "Device Class: $CLASS | Mode: $MODE | Scale: $DOWNSCALE"

# =========================
# VULKAN / RENDER CORE
# =========================

setprop debug.hwui.renderer skiagl 2>/dev/null
setprop debug.renderengine.backend skiagl 2>/dev/null
setprop debug.hwui.use_hint_manager true 2>/dev/null
setprop debug.hwui.render_dirty_regions false 2>/dev/null

# =========================
# FRAME STABILITY
# =========================

setprop debug.sf.use_frame_rate_priority 1 2>/dev/null
setprop debug.sf.frame_rate_multiple_threshold 60 2>/dev/null
setprop debug.sf.enable_gl_backpressure 1 2>/dev/null
setprop debug.sf.early_phase_offset_ns 500000 2>/dev/null
setprop debug.sf.late_phase_offset_ns 1500000 2>/dev/null

# =========================
# GPU BALANCE
# =========================

setprop debug.hwui.target_cpu_time_percent 70 2>/dev/null
setprop debug.hwui.target_gpu_time_percent 70 2>/dev/null

# =========================
# DISPLAY CONTROL
# =========================

settings put system peak_refresh_rate 90 2>/dev/null
settings put system min_refresh_rate 90 2>/dev/null
settings put system refresh_rate_mode 3 2>/dev/null

device_config put surface_flinger refresh_rate_switching true 2>/dev/null

# =========================
# MEMORY OPTIMIZATION
# =========================

settings put global background_process_limit 3
settings put global cached_apps_freezer 1
settings put global app_standby_enabled 0

# =========================
# TOUCH BOOST
# =========================

settings put system pointer_speed 7

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null

# =========================
# I/O PERFORMANCE
# =========================

echo 0 > /proc/sys/vm/dirty_background_ratio 2>/dev/null
echo 20 > /proc/sys/vm/dirty_ratio 2>/dev/null

# =========================
# THERMAL
# =========================

setprop debug.thermal.throttle.support yes 2>/dev/null

# =========================
# GAME ENGINE
# =========================

settings put global game_driver_all_apps 1 2>/dev/null
settings put global game_mode 2 2>/dev/null
device_config put game frame_rate_throttling false 2>/dev/null

# =========================
# GAME PROFILE LOOP
# =========================

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

cmd device_config put game_overlay "$pkg" \
mode=2,downscaleFactor=$DOWNSCALE,fps=90

cmd game mode performance "$pkg"

log "Optimized: $pkg"
done

# =========================
# CLEAN SYSTEM
# =========================

pm trim-caches 32G 2>/dev/null
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "VULKAN ENGINE V1 ACTIVE"