#!/system/bin/sh

ui_print "ARISE VULKAN ENGINE INSTALLING..."
sleep 1
ui_print "Detecting device..."
sleep 1
ui_print "Applying Vulkan profile..."
sleep 1
ui_print "Optimizing performance..."
sleep 1
ui_print "INSTALL COMPLETE"