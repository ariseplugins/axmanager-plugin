#!/system/bin/sh

log() {
echo "[ARISE VULKAN RESET] $1"
}

log "Restoring system defaults..."

settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
settings put system pointer_speed 5

settings delete global game_driver_all_apps
settings delete global game_mode

cmd deviceidle enable

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "RESET COMPLETE"