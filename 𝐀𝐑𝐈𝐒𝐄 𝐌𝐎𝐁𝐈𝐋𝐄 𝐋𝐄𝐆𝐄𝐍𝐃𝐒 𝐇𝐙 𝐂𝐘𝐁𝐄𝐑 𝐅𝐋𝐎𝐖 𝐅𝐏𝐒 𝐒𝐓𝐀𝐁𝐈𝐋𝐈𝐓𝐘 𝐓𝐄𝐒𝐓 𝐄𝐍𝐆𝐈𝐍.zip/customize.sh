#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐌𝐋 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 𝐄𝐍𝐆𝐈𝐍𝐄 V2
#   FPS / STABILITY / PERFORMANCE CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GAME="com.mobile.legends"

#━━━━━━━━ COLORS ━━━━━━━━
RED='\033[1;31m'
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
PURPLE='\033[1;35m'
GRAY='\033[90m'
WHITE='\033[1;37m'
RESET='\033[0m'

#━━━━━━━━ ENGINE LOG ━━━━━━━━
log() {
  echo -e "${CYAN}[ARISE CORE]${RESET} ${WHITE}$1${RESET}"
}

clear

echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐌𝐋 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 𝐕2${RESET}"
echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Booting ARISE performance engine..."
sleep 1

log "Checking system compatibility..."
sleep 1

#━━━━━━━━ DEVICE SCAN ━━━━━━━━
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo "UNKNOWN")
ANDROID=$(getprop ro.build.version.release)

echo -e "${YELLOW}━━━━ SYSTEM ANALYSIS ━━━━${RESET}"
echo -e "${WHITE}RAM     : ${GREEN}$RAM KB${RESET}"
echo -e "${WHITE}CPU     : ${GREEN}$CPU${RESET}"
echo -e "${WHITE}ANDROID : ${GREEN}$ANDROID${RESET}"
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

#━━━━━━━━ PROFILE ENGINE ━━━━━━━━
if [ "$RAM" -ge 8000000 ]; then
  PROFILE="ULTRA CYBER FLOW"
  FPS="144"
elif [ "$RAM" -ge 6000000 ]; then
  PROFILE="COMPETITIVE FLOW"
  FPS="120"
elif [ "$RAM" -ge 4000000 ]; then
  PROFILE="BALANCED FLOW"
  FPS="90"
else
  PROFILE="STABLE FLOW"
  FPS="60"
fi

echo -e "${CYAN}━━━━ PROFILE ENGINE ━━━━${RESET}"
echo -e "${WHITE}MODE : ${GREEN}$PROFILE${RESET}"
echo -e "${WHITE}FPS  : ${GREEN}$FPS HZ${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

#━━━━━━━━ SYSTEM OPTIMIZATION CORE ━━━━━━━━

log "Disabling system animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "Applying refresh rate lock..."
settings put system peak_refresh_rate $FPS
settings put system min_refresh_rate $FPS

log "Boosting touch response..."
settings put system pointer_speed 7
settings put secure long_press_timeout 150

log "Optimizing background processes..."
settings put global background_process_limit 3
cmd deviceidle disable

log "Enabling rendering engine boost..."
setprop debug.hwui.renderer skiaglthreaded
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.sf.latch_unsignaled 1

log "Game optimization layer..."
cmd package compile -m speed-profile -f "$GAME" 2>/dev/null
cmd appops set "$GAME" RUN_IN_BACKGROUND allow 2>/dev/null

#━━━━━━━━ FINAL STAGE ━━━━━━━━
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐌𝐋 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 ACTIVE${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

echo -e "${WHITE}STATUS : ${GREEN}ENGINE ONLINE${RESET}"
echo -e "${WHITE}GAME   : ${CYAN}MOBILE LEGENDS${RESET}"
echo -e "${WHITE}FPS    : ${CYAN}$FPS STABLE${RESET}"
echo -e "${WHITE}MODE   : ${CYAN}$PROFILE${RESET}"
echo ""

log "ARISE ML CYBER FLOW V2 READY"