#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 𝐄𝐍𝐆𝐈𝐍𝐄
#   MAX GRAPHICS + FPS STABILITY CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GAME="com.garena.game.codm"

#━━━━━━━━ COLORS ━━━━━━━━
RED='\033[1;31m'
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
PURPLE='\033[1;35m'
WHITE='\033[1;37m'
RESET='\033[0m'

log() {
  echo -e "${CYAN}[ARISE ENGINE]${RESET} ${WHITE}$1${RESET}"
}

clear

echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 ENGINE${RESET}"
echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

#━━━━━━━━ BOOT CHECK ━━━━━━━━
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "System ready. Initializing ARISE engine..."
sleep 1

#━━━━━━━━ GPU / GRAPHICS ━━━━━━━━
log "Applying graphics & GPU boost..."

settings put global force_gpu_rendering 1
settings put global enable_gpu_debug_layers 0
setprop debug.hwui.renderer skiaglthreaded
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.hwui.force_gpu_rendering true

#━━━━━━━━ UI / ANIMATION ━━━━━━━━
log "Optimizing UI animations..."

settings put global window_animation_scale 0.4
settings put global transition_animation_scale 0.4
settings put global animator_duration_scale 0.4

settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

#━━━━━━━━ FPS CONTROL ━━━━━━━━
log "Locking refresh rate & FPS stability..."

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
settings put system refresh_rate_mode 2

#━━━━━━━━ TOUCH BOOST ━━━━━━━━
log "Enhancing touch responsiveness..."

settings put system pointer_speed 7
settings put global gesture_touches_enabled 1

#━━━━━━━━ PERFORMANCE MODE ━━━━━━━━
log "Enabling performance mode..."

cmd power set-fixed-performance-mode-enabled true
settings put global battery_saver_enabled 0
settings put global game_mode_enabled 1
settings put global low_power 0

#━━━━━━━━ MEMORY OPTIMIZATION ━━━━━━━━
log "Optimizing memory system..."

settings put global background_process_limit 1
settings put global cached_apps_freezer enabled
cmd activity kill-all 2>/dev/null

#━━━━━━━━ NETWORK BOOST ━━━━━━━━
log "Applying network optimization..."

settings put global tcp_fastopen_enabled 1
settings put global low_latency_network_mode 1
settings put global wifi_scan_throttle_enabled 0

#━━━━━━━━ GAME ENGINE APPLY ━━━━━━━━
log "Applying ARISE engine to installed apps..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  device_config put game_overlay "$pkg" mode=2,downscaleFactor=0.49,fps=144 2>/dev/null
  cmd game mode performance "$pkg" 2>/dev/null

  pid=$(pidof "$pkg")
  if [ -n "$pid" ]; then
    renice -n -5 -p "$pid" 2>/dev/null
  fi

  log "Optimized: $pkg"

done

#━━━━━━━━ CLEAN CACHE ━━━━━━━━
log "Cleaning system cache..."
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

#━━━━━━━━ FINISH ━━━━━━━━
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐂𝐘𝐁𝐄𝐑 𝐅𝐋𝐎𝐖 ACTIVE${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Engine successfully deployed"
log "Stable FPS + Smooth Touch + Optimized Rendering ACTIVE"
log "Restart recommended for full effect"