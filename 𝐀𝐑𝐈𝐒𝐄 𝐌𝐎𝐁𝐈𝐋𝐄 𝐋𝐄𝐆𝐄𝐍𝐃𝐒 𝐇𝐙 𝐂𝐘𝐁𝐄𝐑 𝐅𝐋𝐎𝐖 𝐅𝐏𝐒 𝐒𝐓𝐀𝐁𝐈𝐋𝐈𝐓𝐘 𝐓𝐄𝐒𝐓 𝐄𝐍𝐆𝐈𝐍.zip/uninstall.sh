#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#   𝐀𝐑𝐈𝐒𝐄 𝐑𝐄𝐒𝐄𝐓 𝐄𝐍𝐆𝐈𝐍𝐄
#   SYSTEM TWEAK RESTORE CORE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

#━━━━━━━━ COLORS ━━━━━━━━
CYAN='\033[1;36m'
WHITE='\033[1;37m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RESET='\033[0m'

log() {
  echo -e "${CYAN}[ARISE RESET]${RESET} ${WHITE}$1${RESET}"
}

clear

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐑𝐄𝐒𝐄𝐓 𝐄𝐍𝐆𝐈𝐍𝐄${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "Initializing system rollback..."
sleep 1

#━━━━━━━━ GRAPHICS RESET ━━━━━━━━
log "Resetting graphics & GPU settings..."

settings delete global force_msaa 2>/dev/null
settings delete global force_gpu_rendering 2>/dev/null
settings delete global debug_hwui_renderer 2>/dev/null
settings delete global enable_gpu_debug_layers 2>/dev/null

setprop debug.force-opengl 0
setprop debug.hwui.renderer ""
setprop debug.hwui.force_gpu 0

#━━━━━━━━ UI RESET ━━━━━━━━
log "Restoring UI animations..."

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

settings delete secure long_press_timeout 2>/dev/null
settings delete secure multi_press_timeout 2>/dev/null

#━━━━━━━━ REFRESH RATE RESET ━━━━━━━━
log "Restoring refresh rate system..."

settings delete system peak_refresh_rate 2>/dev/null
settings delete system min_refresh_rate 2>/dev/null
settings delete system refresh_rate_mode 2>/dev/null

#━━━━━━━━ TOUCH RESET ━━━━━━━━
log "Resetting touch input..."

settings put system pointer_speed 5
settings delete global gesture_touches_enabled 2>/dev/null

#━━━━━━━━ PERFORMANCE RESET ━━━━━━━━
log "Disabling performance mode..."

cmd power set-fixed-performance-mode-enabled false
settings put global low_power 1
settings put global battery_saver_enabled 1

#━━━━━━━━ MEMORY RESET ━━━━━━━━
log "Restoring memory system..."

settings delete global cached_apps_freezer 2>/dev/null
settings delete global background_process_limit 2>/dev/null
settings delete global enable_zram 2>/dev/null

#━━━━━━━━ THERMAL RESET ━━━━━━━━
log "Restoring thermal control..."

setprop debug.thermal.throttle.support yes
settings delete global thermal_limit_refresh_rate 2>/dev/null

#━━━━━━━━ NETWORK RESET ━━━━━━━━
log "Restoring network settings..."

settings delete global tcp_fastopen_enabled 2>/dev/null
settings delete global low_latency_network_mode 2>/dev/null
settings delete global wifi_scan_throttle_enabled 2>/dev/null

#━━━━━━━━ GAME RESET ━━━━━━━━
log "Resetting game overlays..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  device_config delete game_overlay "$pkg" 2>/dev/null
  cmd game mode reset "$pkg" 2>/dev/null
done

#━━━━━━━━ CLEANUP ━━━━━━━━
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

#━━━━━━━━ FINAL STATUS ━━━━━━━━
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}   𝐀𝐑𝐈𝐒𝐄 𝐑𝐄𝐒𝐄𝐓 COMPLETE${RESET}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

log "System fully restored to default state"
log "Restart recommended for full effect"