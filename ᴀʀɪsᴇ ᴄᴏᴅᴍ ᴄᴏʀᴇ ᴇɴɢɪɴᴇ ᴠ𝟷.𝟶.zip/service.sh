#!/system/bin/sh

LOG="/data/local/tmp/arise_codm.log"

DATE=$(date)

MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
ANDROID=$(getprop ro.build.version.release)

echo "[$DATE] CODM ENGINE BOOTED" >> $LOG
echo "Device: $MODEL ($DEVICE)" >> $LOG
echo "Android: $ANDROID" >> $LOG

# basic safe tuning
settings put global background_process_limit 3
settings put global wifi_scan_always_enabled 0
settings put global ble_scan_always_enabled 0

# rendering stability
setprop debug.hwui.renderer skiagl
setprop debug.sf.disable_backpressure 1
setprop debug.sf.late.sf.idle 1