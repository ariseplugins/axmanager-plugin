#!/system/bin/sh

LOG="/data/local/tmp/arise_codm.log"

settings put global background_process_limit 5
settings put global wifi_scan_always_enabled 1
settings put global ble_scan_always_enabled 1

setprop debug.hwui.renderer ""
setprop debug.sf.disable_backpressure 0

echo "ARISE CODM ENGINE REMOVED" >> $LOG