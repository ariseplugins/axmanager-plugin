#!/system/bin/sh

# =========================================
# ARISE CODM AUTO PERFORMANCE ENGINE
# SINGLE EXECUTION MODE (NO TOGGLE)
# =========================================

PKG="$1"

# ===== COLORS =====
GREEN='\033[1;32m'
RED='\033[1;31m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
RESET='\033[0m'

# =========================================
# BANNER
# =========================================
clear

echo "${CYAN}"
echo "===================================="
echo "        ARISE CODM ENGINE          "
echo "===================================="
echo "${RESET}"

echo "${GREEN}Initializing CODM Performance Engine...${RESET}"
echo ""

# =========================================
# DEVICE INFO
# =========================================
MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

echo "${CYAN}[DEVICE]${RESET}"
echo "Model   : $MODEL"
echo "Android : $ANDROID"
echo ""

# =========================================
# APPLY PERFORMANCE TWEAKS
# =========================================

echo "${YELLOW}[STEP] Applying system optimizations...${RESET}"

# Background limit
settings put global background_process_limit 2

# Game performance mode
cmd game mode performance "$PKG" 2>/dev/null

# GPU renderer tweak
setprop debug.hwui.renderer skiagl

# Frame stability tweak
setprop debug.sf.disable_backpressure 1

# Input responsiveness
settings put system pointer_speed 7

# Kill unnecessary cache pressure
cmd package trim-caches 1000000000 2>/dev/null

# =========================================
# STABILIZATION LAYER
# =========================================

echo "${YELLOW}[STEP] Stabilizing system pipeline...${RESET}"

setprop debug.sf.enable_hwc_vsync 1
setprop debug.sf.late.sf.idle 1

settings put global disable_multisample true

# =========================================
# DEVICE OPTIMIZATION
# =========================================

echo "${YELLOW}[STEP] Optimizing device behavior...${RESET}"

cmd deviceidle disable 2>/dev/null
cmd deviceidle whitelist +$PKG 2>/dev/null

# =========================================
# FINAL STATUS
# =========================================

echo ""
echo "${GREEN}[SUCCESS] CODM ENGINE ACTIVE${RESET}"
echo "${CYAN}[OWNER] @ariseplugin | @fckstark69${RESET}"
echo ""
echo "${GREEN}Performance profile applied successfully.${RESET}"