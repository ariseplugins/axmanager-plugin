#!/system/bin/sh

PKG="$1"
DATE=$(date)

if [ "$PKG" != "com.garena.game.codm" ]; then
    echo "[$DATE] Not CODM - exit"
    exit 0
fi

echo "[$DATE] CODM DETECTED - ARISE ENGINE START"

# performance stability
settings put global background_process_limit 2

# rendering
setprop debug.hwui.renderer skiagl
setprop debug.sf.disable_backpressure 1

# input feel
settings put system pointer_speed 7

# cache stability
cmd package trim-caches 500000000 2>/dev/null

# priority mode
cmd activity set-standby-bucket "$PKG" active

echo "[ARISE] STABLE MODE ACTIVE"
echo "Developers: @ariseplugin @fckstark69"