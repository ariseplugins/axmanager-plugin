#!/system/bin/sh
# customize.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
W="\033[1;37m"
D="\033[90m"
Z="\033[0m"

clear

DATE=$(date)
MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)
BRAND=$(getprop ro.product.brand)
SOC=$(getprop ro.board.platform)

echo -e "${C}"
echo "████████████████████████████████████████████████████████"
echo "██                                                    ██"
echo "██            QUANTUM COMBO METHOD ENGINE             ██"
echo "██                VIP ELITE EDITION                   ██"
echo "██                                                    ██"
echo "████████████████████████████████████████████████████████"
echo -e "${Z}"

sleep 1

echo ""
echo -e "${G}[ DATE ]${Z} $DATE"
echo -e "${G}[ BRAND ]${Z} $BRAND"
echo -e "${G}[ MODEL ]${Z} $MODEL"
echo -e "${G}[ ANDROID ]${Z} $ANDROID"
echo -e "${G}[ SOC ]${Z} $SOC"

echo ""
echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

echo -e "${D}[ SYSTEM ] preparing gaming runtime...${Z}"
sleep 1
echo -e "${D}[ ENGINE ] checking performance environment...${Z}"
sleep 1
echo -e "${D}[ FPS ] preparing stabilization layer...${Z}"
sleep 1
echo -e "${D}[ TOUCH ] calibrating response engine...${Z}"
sleep 1
echo -e "${D}[ DISPLAY ] synchronizing refresh runtime...${Z}"
sleep 1
echo -e "${D}[ GAMING ] preparing combo optimization system...${Z}"
sleep 1

echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

echo ""
echo -e "${G}▓▒░ INSTALLATION COMPLETE ░▒▓${Z}"
echo ""
echo -e "${W}REBOOT DEVICE FOR FULL ACTIVATION${Z}"
echo ""