#!/system/bin/sh
# service.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
W="\033[1;37m"
D="\033[90m"
Z="\033[0m"

log() {
echo -e "${C}[ QUANTUM ENGINE ]${Z} $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 2
done

sleep 15

RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
ANDROID=$(getprop ro.build.version.release)
MODEL=$(getprop ro.product.model)

clear

echo -e "${C}"
echo "████████████████████████████████████████████"
echo "        QUANTUM SERVICE RUNTIME"
echo "████████████████████████████████████████████"
echo -e "${Z}"

echo ""

echo -e "${G}[ DEVICE ]${Z} $MODEL"
echo -e "${G}[ ANDROID ]${Z} $ANDROID"
echo -e "${G}[ RAM ]${Z} $RAM KB"

echo ""

if [ "$RAM" -ge 10000000 ]; then
PROFILE="ULTRA PERFORMANCE"
FPS="144"
DOWN="0.85"

elif [ "$RAM" -ge 8000000 ]; then
PROFILE="HIGH PERFORMANCE"
FPS="120"
DOWN="0.78"

elif [ "$RAM" -ge 6000000 ]; then
PROFILE="BALANCED PERFORMANCE"
FPS="90"
DOWN="0.72"

else
PROFILE="STABLE PERFORMANCE"
FPS="60"
DOWN="0.65"
fi

echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

echo -e "${G}[ PROFILE ]${Z} $PROFILE"
echo -e "${G}[ TARGET FPS ]${Z} $FPS"
echo -e "${G}[ DOWNSCALE ]${Z} $DOWN"

echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

settings put system peak_refresh_rate $FPS
settings put system min_refresh_rate 60

cmd activity memory-factor set 0 2>/dev/null
cmd deviceidle disable

setprop debug.hwui.renderer skiagl
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true

log "loading fps stabilization engine"
sleep 1

log "loading anti stutter runtime"
sleep 1

log "loading aggressive gaming layer"
sleep 1

log "loading rendering consistency engine"
sleep 1

log "loading refresh synchronization layer"
sleep 1

log "loading touch optimization runtime"
sleep 1

for game in \
com.garena.game.codm \
com.tencent.ig \
com.dts.freefireth \
com.mobile.legends \
com.netease.newspike
do

if pm list packages | grep -q "$game"; then

echo ""
echo -e "${R}◆ GAME DETECTED : $game${Z}"

cmd game mode performance "$game" 2>/dev/null

device_config put game_overlay \
"$game" \
mode=2,downscaleFactor=$DOWN,fps=$FPS

pid=$(pidof "$game")

if [ -n "$pid" ]; then
renice -n -5 -p "$pid"
fi

echo -e "${G}[ FPS ] synchronized${Z}"
echo -e "${G}[ DOWNSCALE ] active${Z}"
echo -e "${G}[ TOUCH ] optimized${Z}"
echo -e "${G}[ PERFORMANCE ] boosted${Z}"

echo ""

fi

done

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo ""
echo -e "${R}▓▒░ QUANTUM COMBO METHOD ACTIVE ░▒▓${Z}"
echo ""