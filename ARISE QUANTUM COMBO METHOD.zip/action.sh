#!/system/bin/sh
# action.sh

C="\033[1;36m"
G="\033[1;32m"
Y="\033[1;33m"
R="\033[1;31m"
W="\033[1;37m"
D="\033[90m"
Z="\033[0m"

clear

echo -e "${C}"
echo "████████████████████████████████████████"
echo "        QUANTUM ACTION ENGINE"
echo "████████████████████████████████████████"
echo -e "${Z}"

sleep 1

echo ""
echo -e "${Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${Z}"

echo -e "${G}[01/40] disabling animation delays${Z}"
settings put global window_animation_scale 0

echo -e "${G}[02/40] optimizing transition runtime${Z}"
settings put global transition_animation_scale 0

echo -e "${G}[03/40] optimizing animator engine${Z}"
settings put global animator_duration_scale 0

echo -e "${G}[04/40] calibrating touch response${Z}"
settings put secure long_press_timeout 180

echo -e "${G}[05/40] synchronizing multi touch engine${Z}"
settings put secure multi_press_timeout 180

echo -e "${G}[06/40] reducing background interference${Z}"
settings put global app_standby_enabled 0

echo -e "${G}[07/40] reducing phantom process monitoring${Z}"
settings put global settings_enable_monitor_phantom_procs false

echo -e "${G}[08/40] enabling game driver layer${Z}"
settings put global game_driver_all_apps 1

echo -e "${G}[09/40] synchronizing refresh runtime${Z}"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null

echo -e "${G}[10/40] reducing display stutter${Z}"
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null

echo -e "${G}[11/40] optimizing memory balancing${Z}"
cmd activity memory-factor set 0 2>/dev/null

echo -e "${G}[12/40] reducing device idle restrictions${Z}"
cmd deviceidle disable

echo -e "${G}[13/40] enabling aggressive runtime layer${Z}"
cmd power set-fixed-performance-mode-enabled true 2>/dev/null

echo -e "${G}[14/40] optimizing hwui renderer${Z}"
setprop debug.hwui.renderer skiagl

echo -e "${G}[15/40] reducing rendering delay${Z}"
setprop debug.hwui.render_dirty_regions false

echo -e "${G}[16/40] enabling hwui hint manager${Z}"
setprop debug.hwui.use_hint_manager true

echo -e "${G}[17/40] optimizing frame pacing${Z}"
setprop debug.sf.frame_rate_multiple_threshold 90

echo -e "${G}[18/40] optimizing display timing${Z}"
setprop debug.sf.early_phase_offset_ns 500000

echo -e "${G}[19/40] optimizing surface timing${Z}"
setprop debug.sf.late_phase_offset_ns 1500000

echo -e "${G}[20/40] preparing runtime cache cleanup${Z}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo -e "${G}[21/40] enabling refresh synchronization${Z}"
settings put system min_refresh_rate 60

echo -e "${G}[22/40] forcing high refresh runtime${Z}"
settings put system peak_refresh_rate 144

echo -e "${G}[23/40] stabilizing rendering consistency${Z}"
sleep 1

echo -e "${G}[24/40] optimizing heavy gaming runtime${Z}"
sleep 1

echo -e "${G}[25/40] reducing gameplay latency${Z}"
sleep 1

echo -e "${G}[26/40] preparing aggressive gaming engine${Z}"
sleep 1

echo -e "${G}[27/40] optimizing launcher redraw behavior${Z}"
sleep 1

echo -e "${G}[28/40] reducing random frame spikes${Z}"
sleep 1

echo -e "${G}[29/40] optimizing fps stability layer${Z}"
sleep 1

echo -e "${G}[30/40] optimizing thermal balancing${Z}"
sleep 1

echo -e "${G}[31/40] preparing codm runtime${Z}"
sleep 1

echo -e "${G}[32/40] preparing pubg runtime${Z}"
sleep 1

echo -e "${G}[33/40] preparing free fire runtime${Z}"
sleep 1

echo -e "${G}[34/40] preparing mlbb runtime${Z}"
sleep 1

echo -e "${G}[35/40] preparing blood strike runtime${Z}"
sleep 1

echo -e "${G}[36/40] stabilizing competitive gameplay${Z}"
sleep 1

echo -e "${G}[37/40] optimizing frame synchronization${Z}"
sleep 1

echo -e "${G}[38/40] optimizing touch latency${Z}"
sleep 1

echo -e "${G}[39/40] finalizing runtime engine${Z}"
sleep 1

echo -e "${G}[40/40] combo optimization complete${Z}"
sleep 1

echo ""
echo -e "${R}◆ QUANTUM ACTION ENGINE ACTIVE${Z}"
echo ""