#!/system/bin/sh

# ==================================================
# COLOR SYSTEM
# ==================================================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
NC="\033[0m"

LOG="[ARISE-ULTRA]"

echo -e "${BLUE}$LOG =========================================${NC}"
echo -e "${BLUE}$LOG ULTRA LOW LATENCY ENGINE STARTING${NC}"
echo -e "${BLUE}$LOG =========================================${NC}"

sleep 0.5

# ==================================================
# DEVICE CHECK
# ==================================================

MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
SDK=$(getprop ro.build.version.sdk)
BRAND=$(getprop ro.product.brand)

echo -e "${YELLOW}$LOG DEVICE SCAN...${NC}"
echo "$LOG BRAND : $BRAND"
echo "$LOG MODEL : $MODEL"
echo "$LOG DEVICE: $DEVICE"
echo "$LOG SDK   : $SDK"

sleep 0.5

if [ "$SDK" -lt 29 ]; then
    echo -e "${RED}$LOG UNSUPPORTED DEVICE - EXITING${NC}"
    exit 1
fi

echo -e "${GREEN}$LOG DEVICE COMPATIBLE${NC}"

sleep 0.5

# ==================================================
# TIME CHECK
# ==================================================

HOUR=$(date +"%H")

echo -e "${YELLOW}$LOG TIME VALIDATION...${NC}"

if [ "$HOUR" -lt 5 ] || [ "$HOUR" -gt 23 ]; then
    echo -e "${YELLOW}$LOG LOW ACTIVITY PERIOD${NC}"
else
    echo -e "${GREEN}$LOG ACTIVE GAMING HOURS${NC}"
fi

sleep 0.5

# ==================================================
# BASE SYSTEM OPTIMIZATION
# ==================================================

echo -e "${CYAN}$LOG APPLYING BASE OPTIMIZATION...${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

sleep 0.3

# ==================================================
# LOW LATENCY CORE ENGINE
# ==================================================

echo -e "${CYAN}$LOG ACTIVATING LOW LATENCY CORE...${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1
setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1

sleep 0.3

# ==================================================
# TOUCH RESPONSE LAYER
# ==================================================

echo -e "${CYAN}$LOG APPLYING TOUCH RESPONSE BOOST...${NC}"

setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1

sleep 0.3

# ==================================================
# BACKGROUND CLEANUP
# ==================================================

echo -e "${CYAN}$LOG CLEANING BACKGROUND PROCESSES...${NC}"

am kill-all > /dev/null 2>&1

sleep 0.3

# ==================================================
# FINAL STABILITY LOCK
# ==================================================

echo -e "${CYAN}$LOG FINALIZING ENGINE...${NC}"

sync

sleep 0.3

# ==================================================
# FINAL OUTPUT
# ==================================================

echo -e "${GREEN}$LOG =========================================${NC}"
echo -e "${GREEN}$LOG ULTRA ENGINE ACTIVE${NC}"
echo -e "${GREEN}$LOG LOW LATENCY ENABLED${NC}"
echo -e "${GREEN}$LOG TOUCH RESPONSE OPTIMIZED${NC}"
echo -e "${GREEN}$LOG SYSTEM STABLE & READY${NC}"
echo -e "${GREEN}$LOG =========================================${NC}"