#!/system/bin/sh

# ==================================================
# ARISE ZYROX ENGINE
# action.sh - Full Performance Runtime Engine
# Author: ARISE SYSTEM
# ==================================================

MODNAME="ARISE ZYROX ENGINE"

# ===============================
# LOG SYSTEM
# ===============================

log() {
  echo "[ARISE ZYROX] $1"
}

# ===============================
# WAIT FOR BOOT COMPLETION
# ===============================

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "System Boot Completed"
log "ARISE ZYROX ENGINE Starting..."

# ===============================
# DEVICE INFO (SAFE DISPLAY ONLY)
# ===============================

DEVICE=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

log "Device: $DEVICE"
log "Android: $ANDROID"

# ===============================
# PERFORMANCE MODE
# ===============================

log "Enabling Performance Core..."

cmd power set-fixed-performance-mode-enabled true 2>/dev/null

# CPU Governor (apply all cores safely)
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  echo performance > $cpu 2>/dev/null
done

log "CPU Performance Mode Applied"

# ===============================
# GPU / RENDER ENGINE
# ===============================

log "Optimizing Graphics Engine..."

setprop debug.hwui.renderer skiagl 2>/dev/null
setprop debug.egl.hw 1 2>/dev/null
setprop debug.sf.latch_unsignaled 1 2>/dev/null

log "GPU Optimization Applied"

# ===============================
# FPS / REFRESH RATE STABILITY
# ===============================

log "Applying Frame Stability Engine..."

settings put system peak_refresh_rate 120 2>/dev/null
settings put system min_refresh_rate 120 2>/dev/null

setprop debug.sf.enable_hwc_vds 1 2>/dev/null
setprop debug.sf.enable_gl_backpressure 1 2>/dev/null

log "FPS Stabilization Applied (120Hz Target)"

# ===============================
# TOUCH RESPONSE ENGINE
# ===============================

log "Boosting Touch Response..."

setprop debug.input.high_res_sampling 1 2>/dev/null
setprop debug.input.touch_boost 1 2>/dev/null
setprop persist.sys.touch_smooth 1 2>/dev/null

log "Touch Engine Optimized"

# ===============================
# SYSTEM UI OPTIMIZATION
# ===============================

log "Optimizing System UI..."

settings put global window_animation_scale 0 2>/dev/null
settings put global transition_animation_scale 0 2>/dev/null
settings put global animator_duration_scale 0 2>/dev/null

log "UI Animations Disabled"

# ===============================
# MEMORY OPTIMIZATION
# ===============================

log "Optimizing Memory..."

sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "Memory Cache Cleaned"

# ===============================
# NETWORK STABILITY
# ===============================

log "Stabilizing Network..."

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960 2>/dev/null
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960 2>/dev/null

log "Network Optimization Applied"

# ===============================
# SYSTEM STABILITY LAYER
# ===============================

log "Applying Stability Layer..."

setprop persist.sys.ui.hw 1 2>/dev/null
setprop windowsmgr.max_events_per_sec 240 2>/dev/null
setprop ro.min_pointer_dur 8 2>/dev/null

log "System Stability Enhanced"

# ===============================
# FINAL STATUS
# ===============================

log "===================================="
log "ARISE ZYROX ENGINE ACTIVE"
log "Performance Mode: ENABLED"
log "FPS Target: 120Hz"
log "Status: STABLE & OPTIMIZED"
log "===================================="

exit 0