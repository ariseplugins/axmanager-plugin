#!/system/bin/sh

# ==================================================
# ARISE ZYROX ENGINE
# Advanced Android Gaming Optimization Engine
# Mode : FPS BOOST / PERFORMANCE / ULTRA SMOOTH
# Author : ARISE SYSTEM
# ==================================================

# ==================================================
# COLORS
# ==================================================

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
RESET='\033[0m'

# ==================================================
# LOG FUNCTION
# ==================================================

log() {
  echo -e "${CYAN}[ARISE ZYROX]${RESET} $1"
}

# ==================================================
# WAIT FOR SYSTEM BOOT
# ==================================================

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "System Boot Completed"
log "Initializing ARISE ZYROX ENGINE..."

# ==================================================
# DEVICE CHECK
# ==================================================

DEVICE=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)
CHIPSET=$(getprop ro.board.platform)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')

log "═══════════════════════════════"
log "DEVICE CHECK"
log "═══════════════════════════════"
log "Device   : $DEVICE"
log "Brand    : $BRAND"
log "Android  : $ANDROID"
log "Chipset  : $CHIPSET"
log "RAM      : $RAM KB"
log "═══════════════════════════════"

# ==================================================
# FPS CHECK
# ==================================================

FPS=$(settings get system peak_refresh_rate)

log "FPS STATUS : ${FPS}Hz"
log "Target FPS : 120FPS"

# ==================================================
# CPU PERFORMANCE BOOST
# ==================================================

log " "
log "════════ CPU PERFORMANCE ════════"
log "• Performance Governor"
log "• CPU Boost Enabled"
log "• Stable Processing Speed"

cmd power set-fixed-performance-mode-enabled true

echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo performance > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null

log "CPU Optimization Applied"

# ==================================================
# GPU BOOST
# ==================================================

log " "
log "════════ GPU ENGINE ═════════════"
log "• Hardware Acceleration"
log "• Rendering Boost"
log "• Smooth Graphics Engine"

setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_dark false
setprop debug.egl.hw 1
setprop debug.sf.latch_unsignaled 1

log "GPU Optimization Applied"

# ==================================================
# FORCE 120FPS
# ==================================================

log " "
log "════════ FPS ENGINE ═════════════"
log "• Force 120Hz Refresh Rate"
log "• Unlock Max FPS"
log "• Stable Frame Engine"

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.showfps 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.target_fps 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120

log "120FPS Optimization Applied"

# ==================================================
# FRAME RATE OPTIMIZER
# ==================================================

log " "
log "════════ FRAME STABILITY ════════"
log "• FPS Stability"
log "• Frame Consistency"
log "• Performance Tuning"

setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop debug.sf.disable_backpressure 1

log "Frame Stability Applied"

# ==================================================
# REDUCE LAG & FREEZE
# ==================================================

log " "
log "════════ SYSTEM STABILITY ═══════"
log "• Reduce Lag"
log "• Fix Frame Drops"
log "• Faster UI Response"

setprop persist.sys.ui.hw 1
setprop persist.sys.use_dithering 1
setprop windowsmgr.max_events_per_sec 240
setprop ro.min_pointer_dur 8

log "System Stability Applied"

# ==================================================
# TOUCH BOOST
# ==================================================

log " "
log "════════ TOUCH ENGINE ═══════════"
log "• Faster Input Response"
log "• Touch Boost Enabled"
log "• Smooth Touch Sampling"

setprop debug.input.high_res_sampling 1
setprop debug.input.touch_boost 1
setprop persist.sys.touch_smooth 1

log "Touch Optimization Applied"

# ==================================================
# NO ANIMATION SYSTEM
# ==================================================

log " "
log "════════ UI OPTIMIZATION ════════"
log "• Disable Animations"
log "• Instant UI Response"
log "• Ultra Smooth Transition"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "Animation Optimization Applied"

# ==================================================
# RAM OPTIMIZATION
# ==================================================

log " "
log "════════ MEMORY ENGINE ══════════"
log "• RAM Cleaner"
log "• Background Cleanup"
log "• Memory Stabilizer"

echo 3 > /proc/sys/vm/drop_caches
am kill-all

log "RAM Optimization Applied"

# ==================================================
# NETWORK STABILIZER
# ==================================================

log " "
log "════════ NETWORK ENGINE ═════════"
log "• Stable Ping"
log "• Reduced Latency"
log "• Gaming Network Stability"

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960

log "Network Optimization Applied"

# ==================================================
# UNIVERSAL GAMING PROFILE
# ==================================================

log " "
log "════════ GAMING PROFILE ═════════"
log "• Universal Gaming Profile"
log "• Performance Identity"
log "• Gaming Configuration Active"

setprop ro.product.model "ARISE GAMING DEVICE"
setprop ro.product.brand "ARISE"
setprop ro.product.manufacturer "ARISE SYSTEM"

log "Gaming Profile Applied"

# ==================================================
# FINALIZATION
# ==================================================

log " "
log "═══════════════════════════════"
log "ARISE ZYROX ENGINE"
log "Optimization Completed"
log "System Status : ACTIVE"
log "═══════════════════════════════"

# ==================================================
# NOTIFICATION
# ==================================================

cmd notification post \
-S bigtext \
-t "ARISE ZYROX ENGINE" \
ax_manager \
"ARISE ZYROX ENGINE" \
"Advanced Optimization Successfully Applied 🚀"