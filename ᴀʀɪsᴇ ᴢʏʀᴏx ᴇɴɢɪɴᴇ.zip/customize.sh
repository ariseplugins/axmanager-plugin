#!/system/bin/sh

# ==========================================
# ARISE ZYROX ENGINE
# Advanced FPS & Performance Engine
# Author: ARISE SYSTEM
# ==========================================

MODNAME="ARISE ZYROX ENGINE"

# ==========================================
# COLORS
# ==========================================

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
RESET='\033[0m'

# ==========================================
# LOG FUNCTION
# ==========================================

log() {
  echo -e "${CYAN}[ARISE ZYROX]${RESET} $1"
}

# ==========================================
# WAIT FOR BOOT
# ==========================================

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

# ==========================================
# ARISE BANNER
# ==========================================

ui_print " "
ui_print "╔══════════════════════════════════════════════╗"
ui_print "║                                              ║"
ui_print "║            ARISE ZYROX ENGINE               ║"
ui_print "║        Advanced Gaming Performance          ║"
ui_print "║                                              ║"
ui_print "╚══════════════════════════════════════════════╝"
ui_print " "

log "Initializing Engine..."

# ==========================================
# DEVICE CHECK
# ==========================================

DEVICE=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)
CHIPSET=$(getprop ro.board.platform)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')

ui_print " "
ui_print "════════ DEVICE INFORMATION ════════"
ui_print "• Device   : $DEVICE"
ui_print "• Brand    : $BRAND"
ui_print "• Android  : $ANDROID"
ui_print "• Chipset  : $CHIPSET"
ui_print "• RAM      : $RAM KB"
ui_print "════════════════════════════════════"

log "Device Check Completed"

# ==========================================
# FPS CHECK
# ==========================================

CURRENT_REFRESH=$(settings get system peak_refresh_rate)

ui_print " "
ui_print "════════ FPS STATUS ════════"
ui_print "• Current Refresh Rate : ${CURRENT_REFRESH}Hz"
ui_print "• Target FPS           : 120FPS"
ui_print "• FPS Engine           : ACTIVE"
ui_print "═══════════════════════"

log "FPS Check Completed"

# ==========================================
# DISPLAY / FPS ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ DISPLAY ENGINE ════════╗"
ui_print "║ • Force 120Hz Refresh Rate     ║"
ui_print "║ • Unlock Max FPS               ║"
ui_print "║ • SurfaceFlinger Boost         ║"
ui_print "║ • Stable Frame Rendering       ║"
ui_print "╚════════════════════════════════╝"

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.showfps 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.target_fps 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120

cmd power set-fixed-performance-mode-enabled true

log "Display Optimization Applied"

# ==========================================
# CPU PERFORMANCE ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ CPU ENGINE ════════════╗"
ui_print "║ • Performance Governor         ║"
ui_print "║ • CPU Boost Enabled            ║"
ui_print "║ • Stable Processing Speed      ║"
ui_print "╚════════════════════════════════╝"

echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo performance > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null

log "CPU Performance Applied"

# ==========================================
# GPU ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ GPU ENGINE ════════════╗"
ui_print "║ • Hardware Acceleration        ║"
ui_print "║ • Rendering Boost              ║"
ui_print "║ • Smooth Graphics Engine       ║"
ui_print "╚════════════════════════════════╝"

setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_dark false
setprop debug.egl.hw 1
setprop debug.sf.latch_unsignaled 1

log "GPU Optimization Applied"

# ==========================================
# FRAME STABILITY ENGINE
# ==========================================

ui_print " "
ui_print "╔══════ FRAME STABILITY ENGINE ══╗"
ui_print "║ • FPS Stability                ║"
ui_print "║ • Performance Tuning           ║"
ui_print "║ • Frame Consistency            ║"
ui_print "╚════════════════════════════════╝"

setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop debug.sf.disable_backpressure 1

log "Frame Optimization Applied"

# ==========================================
# SYSTEM STABILITY
# ==========================================

ui_print " "
ui_print "╔════════ SYSTEM STABILITY ══════╗"
ui_print "║ • Reduce Lag                   ║"
ui_print "║ • Fix Frame Drops              ║"
ui_print "║ • Faster UI Response           ║"
ui_print "╚════════════════════════════════╝"

setprop persist.sys.ui.hw 1
setprop persist.sys.use_dithering 1
setprop windowsmgr.max_events_per_sec 240
setprop ro.min_pointer_dur 8

log "System Stability Applied"

# ==========================================
# TOUCH BOOST ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ TOUCH BOOST ═══════════╗"
ui_print "║ • Faster Input Response        ║"
ui_print "║ • Touch Smooth Engine          ║"
ui_print "║ • High Response Sampling       ║"
ui_print "╚════════════════════════════════╝"

setprop debug.input.high_res_sampling 1
setprop debug.input.touch_boost 1
setprop persist.sys.touch_smooth 1

log "Touch Optimization Applied"

# ==========================================
# ANIMATION CONTROL
# ==========================================

ui_print " "
ui_print "╔════════ UI ANIMATION ══════════╗"
ui_print "║ • Disable Animations           ║"
ui_print "║ • Instant UI Response          ║"
ui_print "║ • Zero Delay Transition        ║"
ui_print "╚════════════════════════════════╝"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "Animations Disabled"

# ==========================================
# RAM ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ MEMORY ENGINE ═════════╗"
ui_print "║ • RAM Cleaner                  ║"
ui_print "║ • Background Cleanup           ║"
ui_print "║ • Memory Optimization          ║"
ui_print "╚════════════════════════════════╝"

echo 3 > /proc/sys/vm/drop_caches
am kill-all

log "RAM Optimization Applied"

# ==========================================
# NETWORK ENGINE
# ==========================================

ui_print " "
ui_print "╔════════ NETWORK ENGINE ════════╗"
ui_print "║ • Stable Ping                  ║"
ui_print "║ • Reduced Latency              ║"
ui_print "║ • Gaming Network Stability     ║"
ui_print "╚════════════════════════════════╝"

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960

log "Network Optimization Applied"

# ==========================================
# DEVICE GAMING PROFILE
# ==========================================

ui_print " "
ui_print "╔══════ GAMING DEVICE PROFILE ═══╗"
ui_print "║ • POCO X8 Pro Max Profile      ║"
ui_print "║ • Gaming Device Spoof          ║"
ui_print "║ • High Performance Identity    ║"
ui_print "╚════════════════════════════════╝"

setprop ro.product.model "POCO X8 Pro Max"
setprop ro.product.brand "Xiaomi"
setprop ro.product.manufacturer "Xiaomi"
setprop ro.build.product "x8promax"

log "Gaming Profile Applied"

# ==========================================
# FINALIZATION
# ==========================================

ui_print " "
ui_print "╔════════════════════════════════╗"
ui_print "║      ARISE ZYROX ENGINE       ║"
ui_print "║    Optimization Completed     ║"
ui_print "║      System Status: ACTIVE    ║"
ui_print "╚════════════════════════════════╝"
ui_print " "

log "ARISE ZYROX ENGINE Successfully Applied"

# ==========================================
# NOTIFICATION
# ==========================================

cmd notification post \
-S bigtext \
-t "ARISE ZYROX ENGINE" \
ax_manager \
"ARISE ZYROX ENGINE" \
"Advanced Optimization Successfully Applied 🚀"