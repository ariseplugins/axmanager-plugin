#!/system/bin/sh

# ==================================================
# ARISE ZYROX ENGINE UNINSTALLER
# Restore Default System Configuration
# Author : ARISE SYSTEM
# ==================================================

# ==================================================
# COLORS
# ==================================================

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
RESET='\033[0m'

# ==================================================
# LOG FUNCTION
# ==================================================

log() {
  echo -e "${RED}[ARISE ZYROX UNINSTALL]${RESET} $1"
}

# ==================================================
# WAIT FOR SYSTEM BOOT
# ==================================================

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "System Boot Completed"
log "Initializing ARISE ZYROX ENGINE Uninstaller..."

# ==================================================
# DEVICE CHECK
# ==================================================

DEVICE=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)

log "═══════════════════════════════"
log "CURRENT DEVICE STATUS"
log "═══════════════════════════════"
log "Device   : $DEVICE"
log "Brand    : $BRAND"
log "Android  : $ANDROID"
log "═══════════════════════════════"

# ==================================================
# RESET CPU PERFORMANCE
# ==================================================

log " "
log "════════ CPU RESTORATION ═══════"
log "• Restoring CPU Governor"
log "• Disabling Performance Mode"
log "• Applying Default Settings"

cmd power set-fixed-performance-mode-enabled false

echo schedutil > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo schedutil > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null

log "CPU Settings Restored"

# ==================================================
# RESET GPU SETTINGS
# ==================================================

log " "
log "════════ GPU RESTORATION ═══════"
log "• Removing GPU Tweaks"
log "• Restoring Rendering Settings"
log "• Resetting Graphics Engine"

setprop debug.hwui.renderer ""
setprop debug.hwui.force_dark ""
setprop debug.egl.hw ""
setprop debug.sf.latch_unsignaled ""

log "GPU Settings Restored"

# ==================================================
# RESET FPS SETTINGS
# ==================================================

log " "
log "════════ FPS RESTORATION ═══════"
log "• Restoring Refresh Rate"
log "• Removing FPS Unlock"
log "• Resetting Frame Engine"

settings delete system peak_refresh_rate
settings delete system min_refresh_rate

setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.hwui.target_fps ""

log "FPS Settings Restored"

# ==================================================
# RESET FRAME OPTIMIZER
# ==================================================

log " "
log "════════ FRAME RESTORATION ═════"
log "• Removing Performance Tuning"
log "• Resetting Frame Stability"
log "• Restoring Default Behavior"

setprop debug.performance.tuning ""
setprop video.accelerate.hw ""
setprop debug.sf.disable_backpressure ""

log "Frame Optimization Restored"

# ==================================================
# RESET SYSTEM STABILITY
# ==================================================

log " "
log "════════ SYSTEM RESTORATION ════"
log "• Restoring UI Responsiveness"
log "• Removing Lag Tweaks"
log "• Resetting System Values"

setprop persist.sys.ui.hw ""
setprop persist.sys.use_dithering ""
setprop windowsmgr.max_events_per_sec ""
setprop ro.min_pointer_dur ""

log "System Settings Restored"

# ==================================================
# RESET TOUCH SETTINGS
# ==================================================

log " "
log "════════ TOUCH RESTORATION ═════"
log "• Removing Touch Boost"
log "• Restoring Input Settings"
log "• Resetting Sampling Rate"

setprop debug.input.high_res_sampling ""
setprop debug.input.touch_boost ""
setprop persist.sys.touch_smooth ""

log "Touch Settings Restored"

# ==================================================
# RESTORE ANIMATIONS
# ==================================================

log " "
log "════════ UI RESTORATION ════════"
log "• Restoring Animations"
log "• Enabling UI Effects"
log "• Resetting Transitions"

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

log "Animations Restored"

# ==================================================
# RESET NETWORK
# ==================================================

log " "
log "════════ NETWORK RESTORATION ═══"
log "• Restoring Network Buffers"
log "• Removing Gaming Tweaks"
log "• Resetting Connectivity"

setprop net.tcp.buffersize.default ""
setprop net.tcp.buffersize.wifi ""

log "Network Settings Restored"

# ==================================================
# REMOVE GAMING PROFILE
# ==================================================

log " "
log "════════ PROFILE RESTORATION ═══"
log "• Removing Gaming Identity"
log "• Resetting Device Profile"
log "• Restoring Original State"

setprop ro.product.model ""
setprop ro.product.brand ""
setprop ro.product.manufacturer ""
setprop ro.build.product ""

log "Gaming Profile Removed"

# ==================================================
# CLEANUP
# ==================================================

log " "
log "════════ SYSTEM CLEANUP ════════"
log "• Clearing Cache"
log "• Finalizing Restoration"
log "• Completing Cleanup"

echo 3 > /proc/sys/vm/drop_caches

log "Cleanup Completed"

# ==================================================
# FINALIZATION
# ==================================================

log " "
log "═══════════════════════════════"
log "ARISE ZYROX ENGINE REMOVED"
log "System Restored Successfully"
log "Status : DEFAULT RESTORED"
log "═══════════════════════════════"

# ==================================================
# NOTIFICATION
# ==================================================

cmd notification post \
-S bigtext \
-t "ARISE ZYROX ENGINE" \
ax_manager \
"ARISE ZYROX ENGINE Removed" \
"System Restored Successfully ✔"