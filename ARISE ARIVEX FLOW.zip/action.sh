#!/system/bin/sh

# =========================================================
#               ARIVEX FLOW ENGINE
#        Advanced Smoothness Optimization Layer
#              Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
RESET='\033[0m'

# ================= LOGGER =================
log() {
    echo -e "${CYAN}[@ariseplugin FLOW]${RESET} $1"
}

# ================= DEVICE CHECK =================
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)
RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)

log "Initializing ARIVEX FLOW engine..."
log "Android: $ANDROID_VER | RAM: ${RAM_KB}KB"

# ================= BOOT WAIT =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected. Activating FLOW layer..."

GAME="com.garena.game.codm"

# =========================================================
#                ORIGINAL OPTIMIZATION CORE
# =========================================================

log "Performing system cleanup & RAM stabilization..."

am kill-all

log "Memory cleanup completed (safe mode)"

# ================= SURFACEFLINGER FLOW =================
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

log "Frame timing optimized for smooth gameplay"

# ================= RENDER ENGINE =================
setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3

settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
settings put global angle_gl_driver_selection_values egl

log "Render pipeline stabilized"

# ================= MEMORY FLOW CONTROL =================
settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 4

log "Memory flow system optimized"

# ================= BACKGROUND CONTROL =================
settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000

settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "Background processes stabilized"

# ================= INPUT FLOW =================
settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "Touch input flow optimized"

# ================= GAME ENGINE =================
cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "Game process priority set"

# ================= ANDROID 13+ FLOW =================
if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    log "Advanced sustained performance layer enabled"
fi

# ================= FINAL STATUS =================
echo ""
echo -e "${PURPLE}============================================${RESET}"
echo -e "${GREEN}        ARIVEX FLOW ACTIVE                 ${RESET}"
echo -e "${PURPLE}============================================${RESET}"
echo ""

log "ARIVEX FLOW successfully applied"
log "Powered by @ariseplugin"