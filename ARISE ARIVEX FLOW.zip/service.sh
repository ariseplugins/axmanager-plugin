#!/system/bin/sh

# =========================================================
#               ARIVEX FLOW ENGINE
#        AGGRESSIVE PERFORMANCE LAYER v1
#              Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
RESET='\033[0m'

# ================= LOGGER =================
log() {
    echo -e "${CYAN}[@ariseplugin FLOW-AGG]${RESET} $1"
}

# ================= BOOT WAIT =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected. Initializing AGGRESSIVE FLOW ENGINE..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

# =========================================================
#                 AGGRESSIVE SYSTEM LAYER
# =========================================================

log "Activating aggressive performance pipeline..."

# ================= SURFACEFLINGER BOOST =================
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.disable_backpressure 1

log "SurfaceFlinger aggressive timing enabled"

# ================= RENDER ENGINE =================
setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3
setprop debug.renderengine.cache_size 64

settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
settings put global angle_gl_driver_selection_values egl

log "RenderEngine boosted to aggressive mode"

# ================= MEMORY AGGRESSIVE CONTROL =================
settings put global activity_manager_constants \
"max_cached_processes=30,service_restart_duration=5000,fgservice_min_shown_time=2000,content_provider_retain_time=10000"

settings put global background_process_limit 3
settings put global cached_apps_freezer 1
settings put global app_standby_enabled 0

log "Memory aggressively optimized"

# ================= BACKGROUND KILL LAYER =================
settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=3000,max_batched_delay=10000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000

settings put global background_throttling_enable 1
settings put global background_throttling_limit 25

log "Background system throttling reduced for gaming focus"

# ================= INPUT AGGRESSIVE BOOST =================
settings put system pointer_speed 7
settings put global tap_timeout 60
settings put global long_press_timeout 250
settings put global multi_press_timeout 150

log "Touch input latency reduced"

# ================= DEVICE IDLE OVERRIDE =================
cmd deviceidle disable 2>/dev/null

# ================= GAME ENGINE PRIORITY =================
cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$GAME" RUN_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "Game priority forced active"

# ================= AGGRESSIVE THERMAL BEHAVIOR =================
setprop debug.thermal.throttle.support no 2>/dev/null
setprop debug.performance.tuning 1

log "Thermal restrictions reduced (aggressive mode)"

# ================= ANDROID 13+ AGGRESSIVE LAYER =================
if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    cmd device_config override game android.os.adpf_hwui_gpu true
    log "Android 13+ aggressive performance layer enabled"
fi

# ================= FINAL AGGRESSIVE ENGINE =================
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sync

log "Cache flushed & system stabilized"

# ================= FINAL STATUS =================
echo ""
echo -e "${PURPLE}============================================${RESET}"
echo -e "${GREEN}   ARIVEX FLOW AGGRESSIVE ACTIVE           ${RESET}"
echo -e "${PURPLE}============================================${RESET}"
echo ""

log "ARIVEX FLOW AGGRESSIVE ENGINE COMPLETED"
log "Powered by @ariseplugin"