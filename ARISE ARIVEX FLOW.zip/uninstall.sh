#!/system/bin/sh

# =========================================================
#          ARIVEX FLOW AGGRESSIVE RESET ENGINE
#           System Full Restoration Layer
#                Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
PURPLE='\033[1;35m'
RESET='\033[0m'

# ================= LOGGER =================
log() {
    echo -e "${CYAN}[@ariseplugin FLOW-RESET]${RESET} $1"
}

# ================= BOOT WAIT =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected. Starting full ARIVEX restoration..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

# =========================================================
#                AGGRESSIVE RESTORE LAYER
# =========================================================

log "Reverting aggressive performance engine..."

# ================= SURFACEFLINGER RESET =================
setprop debug.sf.use_phase_offsets_as_durations 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.early_sf_phase_offset_ns 0
setprop debug.sf.late_app_phase_offset_ns 0
setprop debug.sf.late_sf_phase_offset_ns 0
setprop debug.sf.max_frame_buffer_acquired_buffers 0

setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.disable_backpressure 0

log "SurfaceFlinger restored to stock state"

# ================= RENDER ENGINE RESET =================
setprop debug.renderengine.backend default
setprop debug.renderengine.enable_async_cache 0
setprop debug.renderengine.frame_submission_limit 0
setprop debug.renderengine.cache_size 0

settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values

log "RenderEngine restored"

# ================= MEMORY RESET =================
settings delete global activity_manager_constants
settings delete global background_process_limit
settings delete global cached_apps_freezer
settings delete global app_standby_enabled

log "Memory subsystem reset"

# ================= BACKGROUND RESET =================
settings delete global alarm_manager_constants
settings delete global sync_max_retry_delay_in_seconds
settings delete global connectivity_metrics_buffer_size

settings delete global background_throttling_enable
settings delete global background_throttling_limit

log "Background throttling fully removed"

# ================= INPUT RESET =================
settings delete system pointer_speed
settings delete global tap_timeout
settings delete global long_press_timeout
settings delete global multi_press_timeout

log "Touch input restored"

# ================= GAME OPS RESET =================
cmd appops set "$GAME" WAKE_LOCK default
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND default
cmd appops set "$GAME" RUN_IN_BACKGROUND default
dumpsys deviceidle whitelist -"$GAME"

log "Game appops reset to default"

# ================= DEVICE IDLE RESET =================
cmd deviceidle enable 2>/dev/null

# ================= ANDROID 13+ RESET =================
if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config delete game android.os.adpf_predict_frame_time 2>/dev/null
    cmd device_config delete game android.os.adpf_sustained_performance_mode 2>/dev/null
    cmd device_config delete game android.os.adpf_hwui_gpu 2>/dev/null
    log "Android 13+ game flags removed"
fi

# ================= AGGRESSIVE CLEAN FINAL =================
log "Flushing system cache and stabilizing device..."

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sync

# ================= FINAL STATUS =================
echo ""
echo -e "${PURPLE}============================================${RESET}"
echo -e "${GREEN}   ARIVEX FLOW FULL RESET COMPLETED        ${RESET}"
echo -e "${PURPLE}============================================${RESET}"
echo ""

log "System fully restored to stock performance state"
log "Powered by @ariseplugin"