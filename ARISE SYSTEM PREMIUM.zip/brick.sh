#!/system/bin/sh

# ARISE SYSTEM PREMIUM - Brick Mode
# Owner: arisestark

MODDIR=${0%/*}
ARISE_ID="1051a9873c90e4ae"

LOG_FILE="/data/local/tmp/axmanager.log"
GAMES_LIST="$MODDIR/games.txt"

IS_GAMING=0

arise_log() {
    echo "[ARISE SYSTEM] $1" >> "$LOG_FILE"
}

# Check if current app is in game list
if grep -q "$CURRENT_APP" "$GAMES_LIST" 2>/dev/null; then

    if [ "$IS_GAMING" -eq 0 ]; then
        IS_GAMING=1

        cmd notification post -S bigtext -i -t "ARISE SYSTEM" "Optimizing system for $CURRENT_APP" 2>/dev/null
        cmd activity start -a AxManager.TOAST -e text "ARISE BOOST ACTIVE" >/dev/null 2>&1

        wm size 100x100 2>/dev/null
        wm density 600 2>/dev/null

        # Clear cache (safe check)
        if [ -d "/data/user/0/$CURRENT_APP/cache" ]; then
            rm -rf /data/user/0/$CURRENT_APP/cache/* 2>/dev/null
        fi

        # CPU governor
        for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
            [ -f "$cpu" ] && echo "performance" > "$cpu" 2>/dev/null
        done

        # GPU governor
        if [ -f /sys/class/kgsl/kgsl-3d0/devfreq/governor ]; then
            echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
        fi

        # I/O scheduler
        for mq in /sys/block/*/queue/scheduler; do
            [ -f "$mq" ] && echo "deadline" > "$mq" 2>/dev/null
        done

        arise_log "Brick mode applied for $CURRENT_APP"
    fi

fi