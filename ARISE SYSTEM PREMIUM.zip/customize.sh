#!/system/bin/sh

# ARISE SYSTEM PREMIUM - UI LOADER
# Owner: arisestark

G='\033[0;32m'
W='\033[1;37m'
NC='\033[0m'
C='\033[1;36m'
P='\033[1;35m'
B='\033[1;34m'

# ==========================================
# ARISE SYSTEM HEADER
# ==========================================
echo -e "${G}  _________________________________________ ${NC}"
echo -e "${G} |       ARISE SYSTEM PREMIUM ACTIVE       |${NC}"
echo -e "${G} |_________________________________________|${NC}"
echo -e "${B}  Owner: arisestark (${CURRENT_ID}) ${NC}"
echo -e "${P} [ INITIALIZING ARISE ENGINE... ] ${NC}"

echo ""
echo -e "${P} [ SUPPORTED GAMES ] ${NC}"
echo -e "${W}  CALL OF DUTY GARENA | CALL OF DUTY GLOBAL${NC}"
echo ""

# STATUS
echo -e "${G} [✓] LICENSE VERIFIED: VIP USER ${NC}"
echo -e "${G} [✓] ARISE ENGINE LOADED ${NC}"
echo -e "${W}  Stable FPS | Smooth Gameplay | Boosted Performance ${NC}"
echo -e "${G}  _________________________________________ ${NC}"

# Run background service
if [ -f "$MODDIR/service.sh" ]; then
    nohup sh "$MODDIR/service.sh" > /dev/null 2>&1 &
fi 

# ==========================================
# VISUAL LOADER
# ==========================================
echo -e "${G}=========================================="
echo -e "${W}      ___    ____  ____  _____ ______"
echo -e "${W}     /   |  / __ \/ __ \/ ___// ____/"
echo -e "${W}    / /| | / /_/ / /_/ /\__ \/ __/   "
echo -e "${W}   / ___ |/ _, _/ _, _/___/ / /___   "
echo -e "${W}  /_/  |_/_/ |_/_/ |_|/____/_____/   "
echo -e "${G}        PERFORMANCE ENGINE          "
echo -e "==========================================${NC}"

echo -e "${G}[+]${W} Mode: 120FPS PERFORMANCE ACTIVE"
echo -e "${G}[+]${W} Target Refresh: HIGH STABILITY"
echo -e "${W} Initializing modules..."

sleep 0.5
echo -e "${B}[■■□□□□□□□□] 20%${NC}"
sleep 0.5
echo -e "${C}[■■■■□□□□□□] 40%${NC}"
sleep 0.5
echo -e "${P}[■■■■■■□□□□] 60%${NC}"
sleep 0.5
echo -e "${G}[■■■■■■■■□□] 80%${NC}"
sleep 0.5
echo -e "${G}[■■■■■■■■■■] 100%${NC}"

sleep 2
echo -e "${G}System synchronization...${NC}"
sleep 2
echo -e "${G}ARISE ENGINE READY.${NC}"