#!/system/bin/sh

# ARISE SYSTEM DISPLAY TOGGLE
# Owner: arisestark

ARISE_MARK="/data/local/tmp/nakaset_na"

arise_log() {
    echo "[ARISE SYSTEM] $1"
}

# Check state flag
if [ -f "$ARISE_MARK" ]; then

    # SECOND STATE → RESET
    wm size reset 2>/dev/null
    wm density reset 2>/dev/null

    rm -f "$ARISE_MARK"

    arise_log "Display reset to default"

else

    # FIRST STATE → APPLY
    wm size 100x100 2>/dev/null
    wm density 600 2>/dev/null

    touch "$ARISE_MARK"

    arise_log "Resolution profile applied"

fi