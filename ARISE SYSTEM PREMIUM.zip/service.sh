#!/system/bin/sh

MODDIR=${0%/*}

# Start background brick service safely
if [ -f "$MODDIR/brick.sh" ]; then
    nohup sh "$MODDIR/brick.sh" > /dev/null 2>&1 &
fi

sleep 5

# Toast / UI trigger
cmd activity start -a AxManager.TOAST -e text "Open game now!" >/dev/null 2>&1

sleep 5