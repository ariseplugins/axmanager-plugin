#!/system/bin/sh

# =====================================================
# ARISE FREE (VIP) DYNAMIC ENGINE v2
# Developer: @arisestark | ARISE SYSTEM
# =====================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
RESET="\033[0m"

log() {
  echo -e "${CYAN}[ARISE FREE (VIP) DYNAMIC v2]${RESET} $1"
}

clear

log "Waiting for system boot..."

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "${GREEN}Boot completed. Starting AUTO GAME OPTIMIZATION ENGINE...${RESET}"

# =========================
# DEVICE INFO
# =========================
FPS=$(settings get system peak_refresh_rate 2>/dev/null || \
      settings get system user_refresh_rate 2>/dev/null || echo 120)

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 1500000)
ANDROID_VER=$(getprop ro.build.version.release)

log "Device Info -> RAM: ${RAM_KB} | CPU: ${CPU_MAX_FREQ} | Android: ${ANDROID_VER}"
log "Detected Refresh Rate: ${FPS}"

# =========================
# DEVICE CLASSIFICATION
# =========================
if [ "$RAM_KB" -ge 8000000 ] && [ "$CPU_MAX_FREQ" -ge 2600000 ]; then
  DOWNSCALE=0.53
  CLASS="HIGH-END"
elif [ "$RAM_KB" -ge 6000000 ]; then
  DOWNSCALE=0.50
  CLASS="UPPER-MID"
elif [ "$RAM_KB" -ge 4000000 ]; then
  DOWNSCALE=0.47
  CLASS="MID"
else
  DOWNSCALE=0.45
  CLASS="LOW-END"
fi

log "Device Class: ${CLASS}"
log "Downscale Factor: ${DOWNSCALE}"

# =========================
# SYSTEM OPTIMIZATION
# =========================
log "Disabling animations..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "Optimizing display pipeline..."
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
cmd display set-user-disabled-hdr-types 1 2 3 4 2>/dev/null

log "Optimizing memory system..."
cmd activity memory-factor set 0 2>/dev/null
settings put global app_standby_enabled 0
settings put global fstrim_mandatory_interval 1

log "Enabling touch boost..."
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 1 > /sys/power/pnpmgr/touch_boost 2>/dev/null

# =========================
# PERFORMANCE FLAGS
# =========================
setprop debug.stagefright.ccodec 4
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late_phase_offset_ns 1500000
setprop debug.sf.frame_rate_multiple_threshold 90
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.render_dirty_regions false

settings put global game_driver_all_apps 1

# =========================
# GAME OPTIMIZATION LOOP
# =========================
log "Applying optimization to installed games..."

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  device_config put game_overlay "$pkg" \
  mode=2,downscaleFactor=$DOWNSCALE,fps=144

  cmd game mode performance "$pkg"

  pid=$(pidof "$pkg")
  if [ -n "$pid" ]; then
      renice -n -1 -p "$pid" 2>/dev/null
  fi

  log "Optimized: $pkg | Scale: $DOWNSCALE"

done

# =========================
# GOOGLE OPTIMIZATION
# =========================
log "Optimizing Google services..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
    cmd appops set "$a" RUN_IN_BACKGROUND ignore
    cmd appops set "$a" RUN_ANY_IN_BACKGROUND ignore
    cmd appops set "$a" FOREGROUND_SERVICE_SPECIAL_USE ignore
done

cmd package grant com.google.android.gms android.permission.READ_CONTACTS 2>/dev/null
cmd package grant com.google.android.gms android.permission.WRITE_CONTACTS 2>/dev/null

# =========================
# ANDROID 14+
# =========================
if [ "$ANDROID_VER" -ge 14 ]; then
  log "Applying Android 14 game optimization flags..."
  cmd device_config override game android.os.adpf_hwui_gpu true 2>/dev/null
  cmd device_config override game android.os.adpf_prefer_power_efficiency false 2>/dev/null
fi

# =========================
# CLEAN MEMORY
# =========================
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "${GREEN}ARISE FREE (VIP) DYNAMIC v2 SUCCESSFULLY APPLIED${RESET}"