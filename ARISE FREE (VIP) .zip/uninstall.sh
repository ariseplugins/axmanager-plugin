#!/system/bin/sh

# =====================================================
# ARISE FREE (VIP) UNINSTALL ENGINE
# Developer: @ariseplugin | ARISE SYSTEM
# =====================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RESET="\033[0m"

log() {
  echo -e "${CYAN}[ARISE FREE (VIP) UNINSTALL]${RESET} $1"
}

clear

log "Initializing system restore process..."

# =========================
# ANIMATION RESET
# =========================
log "Restoring system animations..."
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

# =========================
# DISPLAY RESET
# =========================
log "Restoring display configuration..."
cmd display set-match-content-frame-rate-pref 0 2>/dev/null
cmd display set-user-disabled-hdr-types 0 2>/dev/null

# =========================
# MEMORY & SYSTEM RESTORE
# =========================
log "Restoring memory & system tuning..."
cmd activity memory-factor set 1 2>/dev/null
settings put global settings_enable_monitor_phantom_procs true
settings put global app_standby_enabled 1
settings put global fstrim_mandatory_interval 0

# =========================
# TOUCH BOOST RESET
# =========================
log "Resetting touch boost..."
[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 0 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

[ -e /sys/power/pnpmgr/touch_boost ] && \
echo 0 > /sys/power/pnpmgr/touch_boost 2>/dev/null

# =========================
# SYSTEM FLAGS RESET
# =========================
log "Restoring system performance flags..."
setprop debug.stagefright.ccodec 0
setprop debug.sf.early_phase_offset_ns 0
setprop debug.sf.late_phase_offset_ns 0
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.hwui.use_hint_manager false

settings put global game_driver_all_apps 0

# =========================
# GPU / RENDER RESET
# =========================
log "Restoring graphics engine defaults..."
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.overdraw true
setprop debug.sf.hw 0
setprop hw3d.force 0

# =========================
# GAME RESET
# =========================
log "Resetting game overlays..."
for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
    device_config put game_overlay "$pkg" mode=0,downscaleFactor=1,fps=0
    cmd game mode none "$pkg"
done

# =========================
# GOOGLE RESET
# =========================
log "Resetting Google services..."
for a in $(cmd package list packages google | cut -f2 -d: | grep -v ia.mo); do
    cmd appops reset "$a"
done

# =========================
# PERMISSION CLEANUP
# =========================
log "Cleaning Google Play Services permissions..."
cmd package revoke com.google.android.gms android.permission.READ_CONTACTS 2>/dev/null
cmd package revoke com.google.android.gms android.permission.WRITE_CONTACTS 2>/dev/null

# =========================
# ANDROID 14+ RESET
# =========================
log "Restoring Android game framework defaults..."
cmd device_config override game android.os.adpf_prefer_power_efficiency true 2>/dev/null
cmd device_config override game android.os.adpf_hwui_gpu false 2>/dev/null

# =========================
# CLEAN MEMORY
# =========================
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "SYSTEM RESTORE COMPLETE"
log "Device returned to default configuration state"