#!/system/bin/sh

MODDIR=${0%/*}

LOGFILE=/data/local/tmp/phantomx_action.log

clear

echo "
╔══════════════════════════════════════════════════════╗
║                                                      ║
║   ██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗        ║
║   ██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝        ║
║   ██████╔╝███████║███████║██╔██╗ ██║   ██║           ║
║   ██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║           ║
║   ██║     ██║  ██║██║  ██║██║ ╚████║   ██║           ║
║   ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝           ║
║                                                      ║
║              PHANTOMX ACTION ENGINE                  ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
" > $LOGFILE

sleep 1

echo "SYSTEM ACTION LAYER INITIALIZED" >> $LOGFILE
echo "LOADING RUNTIME ENGINE" >> $LOGFILE
echo "SCANNING TARGET PACKAGES" >> $LOGFILE
echo "INITIALIZING RESPONSE PIPELINE" >> $LOGFILE

sleep 1

CODM=$(pidof com.activision.callofduty.shooter)
MLBB=$(pidof com.mobile.legends)
PUBG=$(pidof com.tencent.ig)
FF=$(pidof com.dts.freefireth)

DEVICE=$(getprop ro.product.model)
CPU=$(getprop ro.product.cpu.abi)
ANDROID=$(getprop ro.build.version.release)

echo "DEVICE DETECTED : $DEVICE" >> $LOGFILE
echo "CPU ARCHITECTURE : $CPU" >> $LOGFILE
echo "ANDROID VERSION : $ANDROID" >> $LOGFILE

sleep 1

if [ "$CODM" ]; then

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "TARGET PACKAGE DETECTED : CODM" >> $LOGFILE
echo "DEPLOYING FPS PROFILE" >> $LOGFILE
echo "DEPLOYING RESPONSE LAYER" >> $LOGFILE
echo "DEPLOYING TOUCH PIPELINE" >> $LOGFILE
echo "DEPLOYING AIM RESPONSE ENGINE" >> $LOGFILE
echo "DEPLOYING FRAME PACING CONTROL" >> $LOGFILE
echo "DEPLOYING LOW LATENCY LAYER" >> $LOGFILE
echo "DEPLOYING GPU RESPONSE BOOST" >> $LOGFILE
echo "DEPLOYING NETWORK BUFFER ENGINE" >> $LOGFILE
echo "CODM PROFILE ACTIVE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

fi

if [ "$MLBB" ]; then

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "TARGET PACKAGE DETECTED : MLBB" >> $LOGFILE
echo "DEPLOYING STABLE FRAME PROFILE" >> $LOGFILE
echo "DEPLOYING RESPONSE ENGINE" >> $LOGFILE
echo "DEPLOYING TOUCH ACCELERATION" >> $LOGFILE
echo "DEPLOYING GPU PIPELINE" >> $LOGFILE
echo "DEPLOYING FRAME STABILITY LAYER" >> $LOGFILE
echo "DEPLOYING INPUT RESPONSE BOOST" >> $LOGFILE
echo "MLBB PROFILE ACTIVE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

fi

if [ "$PUBG" ]; then

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "TARGET PACKAGE DETECTED : PUBG MOBILE" >> $LOGFILE
echo "DEPLOYING GPU RENDER PROFILE" >> $LOGFILE
echo "DEPLOYING FRAME STABILITY LAYER" >> $LOGFILE
echo "DEPLOYING THERMAL SAFE CONTROL" >> $LOGFILE
echo "DEPLOYING RENDER RESPONSE ENGINE" >> $LOGFILE
echo "PUBG PROFILE ACTIVE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

fi

if [ "$FF" ]; then

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "TARGET PACKAGE DETECTED : FREEFIRE" >> $LOGFILE
echo "DEPLOYING LOW LATENCY ENGINE" >> $LOGFILE
echo "DEPLOYING FAST TOUCH RESPONSE" >> $LOGFILE
echo "DEPLOYING LIGHT FRAME ENGINE" >> $LOGFILE
echo "FREEFIRE PROFILE ACTIVE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

fi

echo "GLOBAL RESPONSE BOOST ACTIVE" >> $LOGFILE
echo "INPUT LATENCY REDUCTION ENABLED" >> $LOGFILE
echo "TOUCH SAMPLING MODE ENABLED" >> $LOGFILE
echo "FRAME PACING CONTROLLER ENABLED" >> $LOGFILE
echo "GPU RESPONSE BOOST READY" >> $LOGFILE
echo "CPU RENDER PIPE READY" >> $LOGFILE
echo "THERMAL FALLBACK MODE READY" >> $LOGFILE
echo "ADAPTIVE FPS ENGINE ACTIVE" >> $LOGFILE
echo "FOREGROUND APP PRIORITY ENABLED" >> $LOGFILE
echo "IDLE PROCESS LIMITER ACTIVE" >> $LOGFILE
echo "ACTION ENGINE STABLE" >> $LOGFILE

sleep 1

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "DEPLOYMENT COMPLETE" >> $LOGFILE
echo "PHANTOMX ACTION ENGINE ONLINE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE