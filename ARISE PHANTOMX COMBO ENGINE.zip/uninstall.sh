#!/system/bin/sh

LOGFILE=/data/local/tmp/phantomx_uninstall.log

echo "
██████╗ ██╗  ██╗ █████╗ ███╗   ██╗████████╗ ██████╗ ███╗   ███╗██╗  ██╗
██╔══██╗██║  ██║██╔══██╗████╗  ██║╚══██╔══╝██╔═══██╗████╗ ████║╚██╗██╔╝
██████╔╝███████║███████║██╔██╗ ██║   ██║   ██║   ██║██╔████╔██║ ╚███╔╝
██╔═══╝ ██╔══██║██╔══██║██║╚██╗██║   ██║   ██║   ██║██║╚██╔╝██║ ██╔██╗
██║     ██║  ██║██║  ██║██║ ╚████║   ██║   ╚██████╔╝██║ ╚═╝ ██║██╔╝ ██╗
╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝

                PHANTOMX UNINSTALL ENGINE
" > $LOGFILE

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE
echo "INITIALIZING UNINSTALL ENGINE" >> $LOGFILE
echo "VERIFYING ENGINE COMPONENTS" >> $LOGFILE
echo "CHECKING TEMPORARY RUNTIME FILES" >> $LOGFILE
echo "CHECKING GPU RESPONSE LAYER" >> $LOGFILE
echo "CHECKING TOUCH RESPONSE STATE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

sleep 1

rm -rf /data/local/tmp/phantomx_*
rm -rf /data/local/tmp/phantomx_cache
rm -rf /data/local/tmp/phantomx_runtime
rm -rf /data/local/tmp/phantomx_render
rm -rf /data/local/tmp/phantomx_logs

echo "CLEARING CACHE FILES" >> $LOGFILE
echo "REMOVING ENGINE LOGS" >> $LOGFILE
echo "REMOVING TEMPORARY RUNTIME DATA" >> $LOGFILE
echo "CLEARING FRAME BUFFER CACHE" >> $LOGFILE
echo "CLEARING RENDERER PROFILE CACHE" >> $LOGFILE
echo "CLEARING RESPONSE ENGINE CACHE" >> $LOGFILE
echo "CLEARING LATENCY TRACKER DATA" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

sleep 1

echo "RESETTING PERFORMANCE PROFILE" >> $LOGFILE
echo "RESETTING GPU RESPONSE STATE" >> $LOGFILE
echo "RESETTING TOUCH RESPONSE STATE" >> $LOGFILE
echo "RESETTING FRAME PACING ENGINE" >> $LOGFILE
echo "RESETTING THERMAL CONTROL STATE" >> $LOGFILE
echo "RESETTING NETWORK BUFFER STATE" >> $LOGFILE
echo "RESETTING ADAPTIVE FPS PROFILE" >> $LOGFILE
echo "RESETTING CPU LOAD BALANCER" >> $LOGFILE
echo "RESETTING MEMORY BALANCER" >> $LOGFILE
echo "RESETTING ZRAM BALANCER" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

sleep 1

echo "RESTORING DEFAULT SYSTEM PROFILE" >> $LOGFILE
echo "RESTORING DEFAULT GPU CONFIGURATION" >> $LOGFILE
echo "RESTORING DEFAULT RESPONSE ENGINE" >> $LOGFILE
echo "RESTORING DEFAULT FRAME LIMITER" >> $LOGFILE
echo "RESTORING DEFAULT TOUCH SAMPLING" >> $LOGFILE
echo "RESTORING DEFAULT POWER PROFILE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

sleep 1

echo "ENGINE STATE : REMOVED" >> $LOGFILE
echo "SERVICE STATE : TERMINATED" >> $LOGFILE
echo "RUNTIME STATE : OFFLINE" >> $LOGFILE
echo "PROFILE STATE : DEFAULT" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE

sleep 1

echo "PHANTOMX ENGINE SUCCESSFULLY REMOVED" >> $LOGFILE
echo "UNINSTALL COMPLETE" >> $LOGFILE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" >> $LOGFILE