#!/system/bin/sh

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

settings delete global background_process_limit
settings delete global cached_apps_freezer

echo 60 > /proc/sys/vm/swappiness 2>/dev/null

setprop debug.hwui.renderer ""

echo "ARISE V4 PRO MAX removed"