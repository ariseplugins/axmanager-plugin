#!/system/bin/sh

LOG="/data/local/tmp/arise_vulkan_v4.log"

log() {
  echo "[ARISE V4 PRO MAX] $1" >> $LOG
}

# ================= BOOT CHECK =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 3
done

log "System boot completed. Initializing PRO MAX ENGINE..."

# ================= DEVICE INFO =================
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
DEVICE=$(getprop ro.product.device)
ANDROID=$(getprop ro.build.version.release)

RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU_MAX=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)

log "Device: $BRAND $MODEL ($DEVICE)"
log "Android: $ANDROID"
log "RAM: $RAM_KB KB"
log "CPU MAX: $CPU_MAX"

# ================= DEVICE CLASS =================
if [ "$RAM_KB" -ge 8000000 ]; then
  CLASS="FLAGSHIP"
  SWAP=0
  FPS_MODE="ULTRA"
elif [ "$RAM_KB" -ge 5000000 ]; then
  CLASS="MID RANGE"
  SWAP=5
  FPS_MODE="HIGH"
else
  CLASS="LOW END"
  SWAP=10
  FPS_MODE="BALANCED"
fi

log "Class: $CLASS | Mode: $FPS_MODE"

# ================= MEMORY ENGINE =================
echo $SWAP > /proc/sys/vm/swappiness 2>/dev/null
echo 10 > /proc/sys/vm/dirty_ratio 2>/dev/null
echo 5 > /proc/sys/vm/dirty_background_ratio 2>/dev/null

# ================= UI STABILITY =================
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# ================= INPUT LATENCY =================
settings put secure long_press_timeout 160
settings put secure multi_press_timeout 150
settings put system pointer_speed 7

# ================= BACKGROUND CONTROL =================
settings put global background_process_limit 3
settings put global cached_apps_freezer 1

# ================= IO BOOST =================
for q in /sys/block/*/queue/read_ahead_kb; do
  echo 256 > $q 2>/dev/null
done

# ================= FRAME ENGINE =================
setprop debug.hwui.renderer skiavk 2>/dev/null
setprop debug.renderengine.backend skiavk 2>/dev/null

# ================= COMPETITIVE MODE =================
if [ "$FPS_MODE" = "ULTRA" ]; then
  settings put global game_driver_all_apps 1
  settings put system peak_refresh_rate 120 2>/dev/null
fi

log "PRO MAX ENGINE ACTIVE"