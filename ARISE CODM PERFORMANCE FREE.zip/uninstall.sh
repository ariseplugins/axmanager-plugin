#!/system/bin/sh
# ARISE SYSTEM UNINSTALL

arise_log() {
  echo "[ARISE SYSTEM RESET] $1"
}

arise_log "Resetting ARISE SYSTEM tweaks..."

GAME_PACKAGE="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

resetprop -p debug.hwui.use_fence_wait
resetprop -p debug.hwui.force_gpu_overdraw
resetprop -p debug.hwui.accelerated_linear
resetprop -p debug.hwui.defer_rendering
resetprop -p debug.sf.disable_hwc_vsync
resetprop -p debug.sf.present_time_offset_us

arise_log "Graphics props reset"

settings delete global background_process_limit
settings delete global low_ram_mode
settings delete global activity_manager_constants

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1
settings put system pointer_speed 0

arise_log "System settings restored"

cmd appops reset $GAME_PACKAGE
dumpsys deviceidle whitelist -$GAME_PACKAGE

arise_log "AppOps & whitelist reset"

if [ "$ANDROID_VER" -ge 12 ]; then
    cmd game reset $GAME_PACKAGE 2>/dev/null
fi

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render false
    cmd device_config override game android.os.adpf_hwui_gpu false
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync false 
fi

arise_log "Game mode flags restored"

arise_log "ARISE SYSTEM successfully reset."