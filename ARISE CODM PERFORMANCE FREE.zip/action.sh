#!/system/bin/sh
# ARISE CODM PERFORMANCE FREE
# ARISE SYSTEM

arise_log() {
    echo "[ARISE SYSTEM] $1"
}

# ===============================
# WAIT FOR FULL SYSTEM BOOT
# ===============================
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

arise_log "System ready → deploying ARISE..."

# ===============================
# DEVICE INFO SCAN
# ===============================
TARGET_FPS=$(settings get system peak_refresh_rate 2>/dev/null || echo 120)
TOTAL_RAM=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
CPU_THREADS=$(nproc)
ANDROID_API=$(getprop ro.build.version.release | cut -d. -f1)

arise_log "Device Scan → RAM:${TOTAL_RAM}KB | CPU:${CPU_THREADS} | ANDROID:${ANDROID_API} | FPS:${TARGET_FPS}"

# ===============================
# GRAPHICS PIPELINE TUNING
# ===============================
setprop debug.hwui.use_fence_wait false
setprop debug.hwui.force_gpu_overdraw false
setprop debug.hwui.accelerated_linear false
setprop debug.hwui.defer_rendering true
setprop debug.sf.disable_hwc_vsync 1
setprop debug.sf.present_time_offset_us 1500

arise_log "Graphics optimized"

# ===============================
# MEMORY CONTROL SYSTEM
# ===============================
settings put global background_process_limit 3
settings put global low_ram_mode 1
settings put global activity_manager_constants "max_cached_processes=3,max_phantom_processes=5,background_settle_time=20000,force_bg_check_on_restricted=false"

arise_log "Memory optimized"

# ===============================
# SYSTEM RESPONSE BOOST
# ===============================
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system pointer_speed 7

arise_log "System response boosted"

# ===============================
# TARGET GAME CONFIG
# ===============================
GAME_PACKAGE="com.garena.game.codm"

cmd appops set "$GAME_PACKAGE" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" RUN_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" WAKE_LOCK allow
cmd appops set "$GAME_PACKAGE" SYSTEM_ALERT_WINDOW allow
dumpsys deviceidle whitelist +"$GAME_PACKAGE"

# ===============================
# PERFORMANCE PROFILE
# ===============================
render_scale=0.5
fps_cap=120

if [ "$ANDROID_API" -ge 12 ]; then
    cmd game set --mode 2 --downscale "$render_scale" --fps "$fps_cap" "$GAME_PACKAGE"
fi

# ===============================
# ADVANCED FLAGS (A13+)
# ===============================
if [ "$ANDROID_API" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render true
    cmd device_config override game android.os.adpf_hwui_gpu true
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync true
    arise_log "Advanced rendering enabled"
fi

# ===============================
# FINAL STATE
# ===============================
arise_log "ARISE SYSTEM ACTIVE ✔"