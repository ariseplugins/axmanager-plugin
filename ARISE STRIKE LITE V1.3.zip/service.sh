#!/system/bin/sh

log_tag="ARISE"

while true; do

    # run only if screen is on
    if dumpsys power | grep -q "state=ON"; then

        # light cleanup
        am kill-all > /dev/null 2>&1

    fi

    sleep 150

done