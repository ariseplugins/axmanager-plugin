#!/system/bin/sh

log_tag="ARISE"

echo "$log_tag: init"

# detect android version
sdk=$(getprop ro.build.version.sdk)

# safe background cleanup
am kill-all > /dev/null 2>&1

# apply only if settings command exists
if command -v settings >/dev/null 2>&1; then
    settings put global window_animation_scale 0.5
    settings put global transition_animation_scale 0.5
    settings put global animator_duration_scale 0.5
fi

# gpu/render hint (safe attempt)
setprop debug.hwui.renderer skiagl > /dev/null 2>&1

# performance hint (safe)
setprop debug.performance.tuning 1 > /dev/null 2>&1

# version-based tweak (light)
if [ "$sdk" -ge 30 ]; then
    setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
fi

sleep 1

echo "$log_tag: done (sdk=$sdk)"