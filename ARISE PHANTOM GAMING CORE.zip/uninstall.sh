#!/system/bin/sh
# uninstall.sh

# ==================================================
# PHANTOM RESET ENGINE
# ==================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}"
echo "===================================================="
echo "               PHANTOM RESET ENGINE"
echo "===================================================="
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[RESET] restoring animations${RESET}"

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

sleep 1

echo -e "${GREEN}[RESET] restoring standby behavior${RESET}"

settings put global app_standby_enabled 1
settings put global settings_enable_monitor_phantom_procs true

cmd activity memory-factor set 1 2>/dev/null

sleep 1

echo -e "${GREEN}[RESET] restoring display sync${RESET}"

cmd display set-match-content-frame-rate-pref 0 2>/dev/null

sleep 1

echo -e "${GREEN}[RESET] disabling game driver${RESET}"

settings put global game_driver_all_apps 0

sleep 1

echo -e "${GREEN}[RESET] restoring HWUI values${RESET}"

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_hint_manager false

sleep 1

echo -e "${GREEN}[RESET] re-enabling idle restrictions${RESET}"

cmd deviceidle enable

sleep 1

echo -e "${GREEN}[RESET] restoring game modes${RESET}"

cmd game mode standard com.garena.game.codm 2>/dev/null
cmd game mode standard com.tencent.ig 2>/dev/null
cmd game mode standard com.netease.newspike 2>/dev/null

device_config delete game_overlay com.garena.game.codm
device_config delete game_overlay com.tencent.ig
device_config delete game_overlay com.netease.newspike

sleep 1

echo -e "${GREEN}[RESET] cleaning runtime cache${RESET}"

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sleep 1

echo ""
echo -e "${RED}[DONE] system restored successfully${RESET}"
echo ""