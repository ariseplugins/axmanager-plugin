#!/system/bin/sh
# service.sh

# ==================================================
# PHANTOM GAMING SERVICE
# ==================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
GREY="\033[90m"
RESET="\033[0m"

log() {
  echo -e "${CYAN}[PHANTOM SERVICE]${RESET} $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 2
done

sleep 10

DATE=$(date)
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)

clear

echo -e "${CYAN}"
echo "========================================================"
echo "              PHANTOM GAMING SERVICE"
echo "========================================================"
echo -e "${RESET}"

echo -e "${GREEN}[DATE]${RESET} ${WHITE}$DATE${RESET}"
echo -e "${GREEN}[BRAND]${RESET} ${WHITE}$BRAND${RESET}"
echo -e "${GREEN}[MODEL]${RESET} ${WHITE}$MODEL${RESET}"
echo -e "${GREEN}[ANDROID]${RESET} ${WHITE}$ANDROID${RESET}"
echo -e "${GREEN}[RAM]${RESET} ${WHITE}$RAM KB${RESET}"
echo ""

sleep 1

# ==================================================
# DEVICE CLASS DETECTION
# ==================================================

if [ "$RAM" -ge 8000000 ]; then
CLASS="HIGH PERFORMANCE"
SCALE="0.75"
elif [ "$RAM" -ge 6000000 ]; then
CLASS="MID PERFORMANCE"
SCALE="0.70"
else
CLASS="BALANCED PERFORMANCE"
SCALE="0.65"
fi

echo -e "${YELLOW}[DEVICE CLASS]${RESET} ${WHITE}$CLASS${RESET}"
echo ""

sleep 1

# ==================================================
# SYSTEM OPTIMIZATION
# ==================================================

log "optimizing runtime environment"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

settings put global app_standby_enabled 0
settings put global settings_enable_monitor_phantom_procs false

cmd activity memory-factor set 0 2>/dev/null

cmd display set-match-content-frame-rate-pref 1 2>/dev/null

settings put global game_driver_all_apps 1

cmd deviceidle disable

setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
setprop debug.stagefright.ccodec 4
setprop debug.sf.frame_rate_multiple_threshold 90

# ==================================================
# CODM DETECTION
# ==================================================

if pm list packages | grep -q "com.garena.game.codm"; then

echo -e "${GREEN}[CODM DETECTED] applying profile${RESET}"

cmd game mode performance com.garena.game.codm 2>/dev/null

device_config put game_overlay \
com.garena.game.codm \
mode=2,downscaleFactor=$SCALE,fps=120

cmd package compile -m speed \
--check-prof true \
com.garena.game.codm

fi

# ==================================================
# PUBG DETECTION
# ==================================================

if pm list packages | grep -q "com.tencent.ig"; then

echo -e "${GREEN}[PUBG DETECTED] applying profile${RESET}"

cmd game mode performance com.tencent.ig 2>/dev/null

device_config put game_overlay \
com.tencent.ig \
mode=2,downscaleFactor=$SCALE,fps=120

fi

# ==================================================
# BLOOD STRIKE DETECTION
# ==================================================

if pm list packages | grep -q "com.netease.newspike"; then

echo -e "${GREEN}[BLOOD STRIKE DETECTED] applying profile${RESET}"

cmd game mode performance com.netease.newspike 2>/dev/null

device_config put game_overlay \
com.netease.newspike \
mode=2,downscaleFactor=$SCALE,fps=120

fi

# ==================================================
# FINALIZATION
# ==================================================

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo ""
echo -e "${RED}[SERVICE COMPLETE] PHANTOM ENGINE ACTIVE${RESET}"
echo ""