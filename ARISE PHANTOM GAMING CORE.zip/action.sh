#!/system/bin/sh
# action.sh

# ==================================================
# PHANTOM ACTION ENGINE
# ==================================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}"
echo "===================================================="
echo "             PHANTOM ACTION ENGINE"
echo "===================================================="
echo -e "${RESET}"

sleep 1

echo -e "${GREEN}[1/15] disabling animation delays${RESET}"
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
sleep 1

echo -e "${GREEN}[2/15] optimizing touch engine${RESET}"
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200
sleep 1

echo -e "${GREEN}[3/15] optimizing standby behavior${RESET}"
settings put global app_standby_enabled 0
sleep 1

echo -e "${GREEN}[4/15] enabling game driver support${RESET}"
settings put global game_driver_all_apps 1
sleep 1

echo -e "${GREEN}[5/15] reducing phantom processes${RESET}"
settings put global settings_enable_monitor_phantom_procs false
sleep 1

echo -e "${GREEN}[6/15] optimizing display synchronization${RESET}"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null
sleep 1

echo -e "${GREEN}[7/15] tuning HWUI rendering${RESET}"
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
sleep 1

echo -e "${GREEN}[8/15] reducing idle restrictions${RESET}"
cmd deviceidle disable
sleep 1

echo -e "${GREEN}[9/15] applying memory tuning${RESET}"
cmd activity memory-factor set 0 2>/dev/null
sleep 1

echo -e "${GREEN}[10/15] optimizing SurfaceFlinger${RESET}"
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.late_phase_offset_ns 1500000
sleep 1

echo -e "${GREEN}[11/15] optimizing frame pacing${RESET}"
setprop debug.sf.frame_rate_multiple_threshold 90
sleep 1

echo -e "${GREEN}[12/15] optimizing graphics layer${RESET}"
setprop debug.stagefright.ccodec 4
sleep 1

echo -e "${GREEN}[13/15] optimizing rendering pipeline${RESET}"
setprop debug.hwui.renderer skiagl
sleep 1

echo -e "${GREEN}[14/15] cleaning runtime cache${RESET}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sleep 1

echo -e "${GREEN}[15/15] finalizing action engine${RESET}"
sleep 1

echo ""
echo -e "${RED}[DONE] optimization successfully applied${RESET}"
echo ""