#!/system/bin/sh

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

echo "[ARISE-CODM-V4] Module removed and system restored"