#!/system/bin/sh

# =========================
# COLOR ENGINE (LOG STYLE ONLY)
# =========================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
NC="\033[0m"

LOG="[ARISE-CODM-V4]"

echo -e "${BLUE}$LOG ==============================${NC}"
echo -e "${BLUE}$LOG INITIALIZING VIP ENGINE${NC}"
echo -e "${BLUE}$LOG ==============================${NC}"

# =========================
# DEVICE CHECK
# =========================

MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
SDK=$(getprop ro.build.version.sdk)

echo -e "${YELLOW}$LOG DEVICE SCAN STARTED...${NC}"
echo "$LOG MODEL: $MODEL"
echo "$LOG DEVICE: $DEVICE"
echo "$LOG SDK: $SDK"

if [ "$SDK" -lt 30 ]; then
    echo -e "${RED}$LOG DEVICE NOT SUPPORTED - EXITING ENGINE${NC}"
    exit 1
fi

echo -e "${GREEN}$LOG DEVICE VERIFIED SUCCESSFULLY${NC}"

# =========================
# TIME CHECK
# =========================

HOUR=$(date +"%H")

echo -e "${YELLOW}$LOG TIME VALIDATION PROCESS...${NC}"

if [ "$HOUR" -lt 6 ] || [ "$HOUR" -gt 23 ]; then
    echo -e "${YELLOW}$LOG OFF-PEAK MODE DETECTED${NC}"
else
    echo -e "${GREEN}$LOG ACTIVE GAMING TIME DETECTED${NC}"
fi

# =========================
# OPTIMIZATION PHASE 1
# =========================

echo -e "${YELLOW}$LOG PHASE 1: SYSTEM CLEANUP${NC}"

am kill-all > /dev/null 2>&1

sleep 0.3

# =========================
# OPTIMIZATION PHASE 2
# =========================

echo -e "${YELLOW}$LOG PHASE 2: UI SMOOTHING LAYER${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

sleep 0.3

# =========================
# OPTIMIZATION PHASE 3
# =========================

echo -e "${YELLOW}$LOG PHASE 3: RENDER ENGINE TUNING${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1

setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

sleep 0.3

# =========================
# FINAL STAGE
# =========================

sync

echo -e "${GREEN}$LOG ==============================${NC}"
echo -e "${GREEN}$LOG ENGINE ACTIVE - STABLE MODE ON${NC}"
echo -e "${GREEN}$LOG SMOOTH + STABLE PERFORMANCE ENABLED${NC}"
echo -e "${GREEN}$LOG ==============================${NC}"