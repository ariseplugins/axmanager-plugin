#!/system/bin/sh

LOG="[ARISE-CODM-V4]"

while true; do

    echo "$LOG Running background stability cycle..."

    am kill-all > /dev/null 2>&1

    echo "$LOG System cleaned (light cycle)"

    sleep 180

done