#!/system/bin/sh

# =========================================================
#                ARISE GYRO ENGINE
#         Advanced Touch & Sensor Optimizer
#               Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
G='\033[1;32m'
B='\033[1;34m'
C='\033[1;36m'
R='\033[1;31m'
Y='\033[1;33m'
P='\033[1;35m'
W='\033[1;37m'
N='\033[0m'

clear

echo -e "${C}====================================================${N}"
echo -e "${P}              █████╗ ██████╗ ██╗███████╗███████╗${N}"
echo -e "${P}             ██╔══██╗██╔══██╗██║██╔════╝██╔════╝${N}"
echo -e "${P}             ███████║██████╔╝██║███████╗█████╗  ${N}"
echo -e "${P}             ██╔══██║██╔══██╗██║╚════██║██╔══╝  ${N}"
echo -e "${P}             ██║  ██║██║  ██║██║███████║███████╗${N}"
echo -e "${P}             ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝${N}"
echo -e "${Y}              ADVANCED GYRO OPTIMIZATION${N}"
echo -e "${C}====================================================${N}"

echo -e "${G}[+]${W} Developer:${C} @ariseplugin${N}"
echo -e "${G}[+]${W} Status:${C} Initializing ARISE Sensor Engine...${N}"

# ================= DEVICE CHECK =================
RAM=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
CPU=$(getprop ro.product.board)
ANDROID=$(getprop ro.build.version.release)

echo -e "${G}[+]${W} RAM:${C} ${RAM}KB${N}"
echo -e "${G}[+]${W} CPU:${C} ${CPU}${N}"
echo -e "${G}[+]${W} Android:${C} ${ANDROID}${N}"

# ================= EXTRA AGGRESSIVE LAYER =================
echo -e "${G}[+]${W} Status:${C} Applying aggressive gaming response layer...${N}"

setprop debug.performance.tuning 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_wakeup 1
setprop debug.sf.enable_gl_backpressure 0

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

settings put system pointer_speed 7

cmd deviceidle disable 2>/dev/null

echo -e "${G}[+]${W} Status:${C} Aggressive response layer enabled${N}"

# ================= ORIGINAL ENGINE =================
B64_DATA="c2V0dGluZ3MgcHV0IHN5c3RlbSBodyNkLmZvcmNlIDEKc2V0dGluZ3MgcHV0IHN5c3RlbSBody1pLmRpc2FibGVfdnN5bmMgdHJ1ZQpzZXR0aW5ncyBwdXQgc3lzdGVtIGh3dWkucmVuZGVyX2RpcnR5X3JlZ2lvbnMgZmFsc2UKc2V0dGluZ3MgcHV0IHN5c3RlbSBwZXJzaXN0LnN5cy51aS5odyAxCnNldHRpbmdzIHB1dCBzeXN0ZW0gcm8uY29uZmlnLmVuYWJsZS5ody1hY2NlbCB0cnVlCnNldHRpbmdzIHB1dCBzeXN0ZW0gdmlkZW8uYWNjZWxlcmF0ZS5odyAxCnNldHRpbmdzIHB1dCBzeXN0ZW0gZ2FtZS5hY2NlbGVyYXRlLmh3IDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX25vX2ludGVycnVwdGlvbiAxCnNldHRpbmdzIHB1dCBzZWN1cmUgZ2FtZV9hdXRvYnJpZ2h0bmVzc19sb2NrIDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2Rpc3BsYXlfaHpfMTIwIDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2ltbWVyc2l2ZV9tb2RlIDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2RyaXZlciB2dWxrYW4Kc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2dmeF9mcHMgOTAKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2dmeF9tc2FhIDAKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2dmeF9xdWFsaXR5IDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBnYW1lX2dmeF9vcHRfbGV2ZWwgIDEKc2V0dGluZ3MgcHV0IHNlY3VyZSBtdWx0aWNvcmVfcGFja2V0X3NjaGVkdWxlciAx"

echo "$B64_DATA" | base64 -d | sh

# ================= EXTRA FLOW BOOST =================
echo -e "${G}[+]${W} Status:${C} Applying ARISE Flow stabilization...${N}"

setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
setprop debug.renderengine.backend skiaglthreaded

settings put global cached_apps_freezer 1
settings put global app_standby_enabled 0
settings put global background_process_limit 3

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

# ================= FINAL STATUS =================
echo ""
echo -e "${C}====================================================${N}"
echo -e "${G}              ARISE ENGINE ACTIVATED${N}"
echo -e "${W}      Advanced Gyro & Gaming Response Ready${N}"
echo -e "${C}====================================================${N}"
echo ""

echo -e "${G}[✓]${W} Success:${C} ARISE Tweaks Successfully Applied!${N}"
echo -e "${G}[✓]${W} Developer:${C} @ariseplugin${N}"