#!/system/bin/sh

RED='\033[1;31m'
CYAN='\033[1;36m'
BLUE='\033[1;34m'
WHITE='\033[1;37m'
GREEN='\033[1;32m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
RESET='\033[0m'

clear

echo -e "${CYAN}╔══════════════════════════════════════════════╗${RESET}"
echo -e "${CYAN}║              ${WHITE}ARISE SYSTEM${CYAN}                 ║${RESET}"
echo -e "${CYAN}║        ${PURPLE}ARISE CODM GYRO ENGINE CORE${CYAN}       ║${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════════════╝${RESET}"
echo ""

echo -e "${GREEN}[✓] ${WHITE}Module:${RESET} ${YELLOW}ARISE GYRO CUSTOM CORE${RESET}"
echo -e "${GREEN}[✓] ${WHITE}Developer:${RESET} ${CYAN}@ariseplugin${RESET}"
echo -e "${GREEN}[✓] ${WHITE}Status:${RESET} ${BLUE}INITIALIZING ACTION + CUSTOM ENGINE...${RESET}"
echo ""

sleep 1

ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(nproc)

echo -e "${PURPLE}━━━━━━━━ SYSTEM SCAN ━━━━━━━━${RESET}"
echo -e "${GREEN} • Android Version : ${WHITE}$ANDROID${RESET}"
echo -e "${GREEN} • Total RAM       : ${WHITE}$RAM KB${RESET}"
echo -e "${GREEN} • CPU Cores       : ${WHITE}$CPU${RESET}"
echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

sleep 1

echo -e "${CYAN}╔════════════ ACTION SERVICE ═════════════╗${RESET}"

echo -e "${PURPLE}[01] ${WHITE}DEVICE COMPATIBILITY CHECK LOADED${RESET}"
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 1; done
echo -e "${GREEN}     ✓ SYSTEM READY${RESET}"

echo -e "${PURPLE}[02] ${WHITE}INJECTING ARISE GYRO RESPONSE CORE${RESET}"
sleep 1

echo -e "${PURPLE}[03] ${WHITE}APPLYING AGGRESSIVE TOUCH ACCELERATION${RESET}"
sleep 1

echo -e "${PURPLE}[04] ${WHITE}REDUCING SENSOR LATENCY + INPUT DELAY${RESET}"
sleep 1

echo -e "${PURPLE}[05] ${WHITE}FPS STABILITY ENGINE ACTIVATED${RESET}"
sleep 1

echo -e "${PURPLE}[06] ${WHITE}SURFACEFLINGER RENDER OPTIMIZATION${RESET}"
sleep 1

echo -e "${PURPLE}[07] ${WHITE}CODM COMPETITIVE MODE ENABLED${RESET}"
sleep 1

echo -e "${PURPLE}[08] ${WHITE}FLOW STABILIZATION ENGINE ACTIVE${RESET}"
sleep 1

echo -e "${CYAN}╚════════════════════════════════════════╝${RESET}"
echo ""

echo -e "${CYAN}╔════════════ AGGRESSIVE LAYER ═══════════╗${RESET}"

setprop debug.performance.tuning 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_wakeup 1
setprop debug.sf.enable_gl_backpressure 0

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system pointer_speed 7

cmd deviceidle disable 2>/dev/null

setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_hint_manager true
setprop debug.renderengine.backend skiaglthreaded

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

echo -e "${GREEN}     ✓ AGGRESSIVE GAMING LAYER ACTIVE${RESET}"

echo -e "${CYAN}╚════════════════════════════════════════╝${RESET}"
echo ""

echo -e "${CYAN}╔════════════ ARISE ENGINE CORE ═══════════╗${RESET}"

B64_DATA="c2V0dGluZ3MgcHV0IHN5c3RlbSBodyNkLmZvcmNlIDEKc2V0dGluZ3MgcHV0IHN5c3RlbSBody1pLmRpc2FibGVfdnN5bmMgdHJ1ZQpzZXR0aW5ncyBwdXQgc3lzdGVtIGh3dWkucmVuZGVyX2RpcnR5X3JlZ2lvbnMgZmFsc2UKc2V0dGluZ3MgcHV0IHN5c3RlbSBwZXJzaXN0LnN5cy51aS5odyAxCnNldHRpbmdzIHB1dCBzeXN0ZW0gcm8uY29uZmlnLmVuYWJsZS5ody1hY2NlbCB0cnVl"

echo "$B64_DATA" | base64 -d | sh

echo -e "${GREEN}     ✓ CORE ENGINE APPLIED${RESET}"

echo -e "${CYAN}╚════════════════════════════════════════╝${RESET}"
echo ""

echo -e "${CYAN}╔════════════ FINAL STATUS ═══════════╗${RESET}"
echo -e "${GREEN} ARISE ENGINE ACTIVE${RESET}"
echo -e "${WHITE} CODM GYRO + TOUCH RESPONSE READY${RESET}"
echo -e "${CYAN} COMPETITIVE MODE STABILIZED${RESET}"
echo -e "${CYAN}╚══════════════════════════════════════╝${RESET}"
echo ""

echo -e "${YELLOW}[!] ${WHITE}Recommended:${RESET} ${CYAN}RESTART DEVICE FOR FULL EFFECT${RESET}"
echo ""