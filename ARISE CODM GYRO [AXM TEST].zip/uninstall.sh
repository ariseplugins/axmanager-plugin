#!/system/bin/sh

# =========================================================
#                ARISE RESTORE ENGINE
#          Advanced System Cleanup & Recovery
#               Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
R='\033[1;31m'
G='\033[1;32m'
B='\033[1;34m'
C='\033[1;36m'
P='\033[1;35m'
W='\033[1;37m'
Y='\033[1;33m'
N='\033[0m'

clear

echo -e "${C}====================================================${N}"
echo -e "${R}              █████╗ ██████╗ ██╗███████╗███████╗${N}"
echo -e "${R}             ██╔══██╗██╔══██╗██║██╔════╝██╔════╝${N}"
echo -e "${R}             ███████║██████╔╝██║███████╗█████╗  ${N}"
echo -e "${R}             ██╔══██║██╔══██╗██║╚════██║██╔══╝  ${N}"
echo -e "${R}             ██║  ██║██║  ██║██║███████║███████╗${N}"
echo -e "${R}             ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝╚══════╝${N}"
echo -e "${Y}              SYSTEM RESTORE ENGINE${N}"
echo -e "${C}====================================================${N}"

echo -e "${R}[!]${W} Status:${C} Removing tweaks & restoring defaults...${N}"

# ================= DEVICE INFO =================
RAM=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
ANDROID=$(getprop ro.build.version.release)

echo -e "${G}[+]${W} RAM:${C} ${RAM}KB${N}"
echo -e "${G}[+]${W} Android:${C} ${ANDROID}${N}"

# ================= AGGRESSIVE CLEANUP =================
echo -e "${R}[!]${W} Status:${C} Starting aggressive cleanup layer...${N}"

cmd deviceidle enable 2>/dev/null

settings delete global cached_apps_freezer
settings delete global app_standby_enabled
settings delete global background_process_limit

setprop debug.performance.tuning 0
setprop debug.sf.disable_backpressure 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.latch_unsignaled 0

echo -e "${G}[+]${W} Status:${C} Cleanup layer completed${N}"

# ================= ORIGINAL RESTORE =================
B64_REMOVE="c2V0dGluZ3MgcHV0IGdsb2JhbCB3aW5kb3dfYW5pbWF0aW9uX3NjYWxlIDEuMApzZXR0aW5ncyBwdXQgZ2xvYmFsIHRyYW5zaXRpb25fYW5pbWF0aW9uX3NjYWxlIDEuMApzZXR0aW5ncyBwdXQgZ2xvYmFsIGFuaW1hdG9yX2R1cmF0aW9uX3NjYWxlIDEuMApzZXR0aW5ncyBkZWxldGUgc3lzdGVtIGh3M2QuZm9yY2UKc2V0dGluZ3MgZGVsZXRlIHN5c3RlbSBod3VpLmRpc2FibGVfdnN5bmMKc2V0dGluZ3MgZGVsZXRlIHN5c3RlbSBod3VpLnJlbmRlcl9kaXJ0eV9yZWdpb25zCnNldHRpbmdzIGRlbGV0ZSBzZWN1cmUgZ2FtZV9kcml2ZXIKc2V0dGluZ3MgZGVsZXRlIHNlY3VyZSBnYW1lX2dmeF9mcHMKc2V0dGluZ3MgZGVsZXRlIHNlY3VyZSBzeXN1aV9jb25maWdfZW5hYmxlX2h3LWFjY2VsZXJhdGVkX2dwdQpzZXR0aW5ncyBwdXQgc3lzdGVtIHBvaW50ZXJfc3BlZWQgMgpzZXR0aW5ncyBwdXQgc3lzdGVtIHRvdWNoX3NlbnNpdGl2aXR5IDEKc2V0cHJvcCBkZWJ1Zy5jb21wb3NpdGlvbi50eXBlIGF1dG8Kc2V0cHJvcCBkZWJ1Zy5zZi5odyAxCnNldHByb3AgZGVidWcuZWdsLmh3IDEKc2V0cHJvcCBkZWJ1Zy5zZi5zZW5zb3JfcmF0ZSAxCnNldHByb3Agcm8uc3VyZmFjZV9mbGluZ2VyLnVzZV9jb250ZW50X2RpbW1lciAx"

echo "$B64_REMOVE" | base64 -d | sh

# ================= EXTRA RESET =================
echo -e "${R}[!]${W} Status:${C} Resetting render & touch layers...${N}"

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_hint_manager false
setprop debug.renderengine.backend default

settings put system pointer_speed 0

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sync

# ================= FINAL STATUS =================
echo ""
echo -e "${C}====================================================${N}"
echo -e "${G}             ARISE RESTORE COMPLETED${N}"
echo -e "${W}         System Restored To Default State${N}"
echo -e "${C}====================================================${N}"
echo ""

echo -e "${G}[✓]${W} Success:${C} System Successfully Restored!${N}"
echo -e "${G}[✓]${W} Developer:${C} @ariseplugin${N}"
echo -e "${Y}[!]${W} Recommendation:${C} Reboot device to fully apply changes${N}"