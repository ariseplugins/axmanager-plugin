#!/system/bin/sh
# =====================================================
#        ARISE HYPER FPS MODULE v7.1 (ENHANCED CORE)
# =====================================================
# Developer : ariseplugin
# Engine    : ARISE SYSTEM FRAMEWORK
# Type      : Performance Optimization Layer
# Build     : Stable Gaming Runtime
# =====================================================

ARISE_MODULE="HYPER FPS"
ARISE_STATE="ENHANCED"
ARISE_DEV="ariseplugin"

log() {
    echo "[ARISE HYPER FPS v7.1] $1"
}

log "Initializing ARISE system framework..."

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "Boot complete. Launching performance runtime..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)




# ================= GRAPHICS PIPELINE =================
log ">> GRAPHICS ENGINE: SurfaceFlinger optimization active"

setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

log "SurfaceFlinger timing tuned"





# ================= RENDER ENGINE =================
log ">> GPU ENGINE: Render pipeline boost enabled"

setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3
settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
settings put global angle_gl_driver_selection_values egl

log "RenderEngine enhanced"





# ================= SYSTEM CORE =================
log ">> SYSTEM CORE: Memory & process optimization"

settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 4

log "Memory & service stability applied"





# ================= BACKGROUND CONTROL =================
log ">> BACKGROUND CONTROL: System throttling active"

settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000

settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "Background system optimized"





# ================= INPUT RESPONSE =================
log ">> INPUT LAYER: Touch optimization enabled"

settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "Input & touch stability applied"





# ================= GAME PERFORMANCE =================
log ">> GAME LAYER: Performance hooks active"

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    log "Android 13+ sustained performance layer enabled"
fi





cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "ARISE HYPER FPS v7.1 ENHANCED ACTIVE ✔"