#!/system/bin/sh
# =====================================================
#        ARISE HYPER FPS MODULE v7.1 (CORE BUILD)
# =====================================================
# Developer : ariseplugin
# Framework : ARISE SYSTEM ENGINE
# Module Type : Gaming Performance Layer
# Target : Android Optimization / CODM
# Status : ACTIVE BUILD
# =====================================================

# ===================== ARISE BOOTSTRAP =====================
ARISE_MODULE_NAME="HYPER FPS"
ARISE_MODULE_VERSION="v7.1"
ARISE_DEV="ariseplugin"
ARISE_STATE="INITIALIZING"

log() {
    echo "[ARISE HYPER FPS v7.1] $1"
}

log "ARISE SYSTEM ENGINE loading module metadata..."
log "Module: $ARISE_MODULE_NAME | Version: $ARISE_MODULE_VERSION | Dev: $ARISE_DEV"


while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done


log "Boot sequence detected. Switching to performance runtime mode..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)




# ===================== MEMORY OPTIMIZATION =====================
log ">> MEMORY LAYER: Optimization phase started"

am kill-all

log "Memory cleanup completed successfully (safe mode)"




# ===================== GRAPHICS PIPELINE =====================
log ">> GRAPHICS LAYER: SurfaceFlinger tuning activated"

setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 600000
setprop debug.sf.early_sf_phase_offset_ns 600000
setprop debug.sf.late_app_phase_offset_ns 900000
setprop debug.sf.late_sf_phase_offset_ns 900000
setprop debug.sf.max_frame_buffer_acquired_buffers 3

log "Surface rendering pipeline optimized"





# ===================== RENDER ENGINE =====================
log ">> RENDER ENGINE: GPU pipeline boost enabled"

setprop debug.renderengine.backend skiaglthreaded
setprop debug.renderengine.enable_async_cache 1
setprop debug.renderengine.frame_submission_limit 3

settings put global angle_gl_driver_selection_pkgs com.garena.game.codm
settings put global angle_gl_driver_selection_values egl

log "RenderEngine acceleration applied"





# ===================== SYSTEM STABILITY =====================
log ">> SYSTEM CORE: Memory & process tuning"

settings put global activity_manager_constants \
"max_cached_processes=28,service_restart_duration=7000,fgservice_min_shown_time=2500,content_provider_retain_time=15000"

settings put global background_process_limit 4

log "System memory policy stabilized"





# ===================== LATENCY CONTROL =====================
log ">> LATENCY CONTROL: Background system tuning"

settings put global alarm_manager_constants \
"min_interval=60000,allow_while_idle_short_time=5000,max_batched_delay=15000"

settings put global sync_max_retry_delay_in_seconds 3600
settings put global connectivity_metrics_buffer_size 2000

settings put global background_throttling_enable 1
settings put global background_throttling_limit 50

log "System background throttling optimized"





# ===================== INPUT RESPONSE =====================
log ">> INPUT LAYER: Touch & response optimization"

settings put system pointer_speed 6
settings put global tap_timeout 80
settings put global long_press_timeout 300
settings put global multi_press_timeout 200

log "Input latency reduced"





# ===================== GAME PERFORMANCE HOOK =====================
log ">> GAME LAYER: Performance hooks initializing"

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_predict_frame_time true
    cmd device_config override game android.os.adpf_sustained_performance_mode true
    log "Android 13+ adaptive performance layer enabled"
fi





cmd appops set "$GAME" WAKE_LOCK allow
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND allow
dumpsys deviceidle whitelist +"$GAME"

log "Game permissions optimized for sustained performance"




# ===================== MODULE FINALIZATION =====================
log "Finalizing ARISE HYPER FPS runtime engine..."
log "ARISE HYPER FPS v7.1 MODULE ACTIVE ✔"