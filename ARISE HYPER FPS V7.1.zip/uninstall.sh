#!/system/bin/sh
# =====================================================
#        ARISE HYPER FPS MODULE v7.1 (UNINSTALL)
# =====================================================
# Developer : ariseplugin
# Engine    : ARISE SYSTEM FRAMEWORK
# Type      : Performance Revert Layer
# Status    : CLEANUP MODE
# =====================================================

log() {
    echo "[ARISE HYPER FPS v7.1 UNINSTALL] $1"
}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "Boot complete. Reverting ARISE performance layer..."

GAME="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)




# ================= GRAPHICS RESET =================
log ">> GRAPHICS LAYER: Restoring defaults"

setprop debug.sf.use_phase_offsets_as_durations 0
setprop debug.sf.early_app_phase_offset_ns 0
setprop debug.sf.early_sf_phase_offset_ns 0
setprop debug.sf.late_app_phase_offset_ns 0
setprop debug.sf.late_sf_phase_offset_ns 0
setprop debug.sf.max_frame_buffer_acquired_buffers 0

setprop debug.renderengine.backend default
setprop debug.renderengine.enable_async_cache 0
setprop debug.renderengine.frame_submission_limit 0

settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values

log "Graphics pipeline reset"





# ================= SYSTEM CORE RESET =================
log ">> SYSTEM CORE: Memory settings rollback"

settings delete global activity_manager_constants
settings delete global background_process_limit

log "Memory & service settings reset"





# ================= BACKGROUND RESET =================
log ">> BACKGROUND CONTROL: Clearing throttling configs"

settings delete global alarm_manager_constants
settings delete global sync_max_retry_delay_in_seconds
settings delete global connectivity_metrics_buffer_size

settings delete global background_throttling_enable
settings delete global background_throttling_limit

log "Background system restored"





# ================= INPUT RESET =================
log ">> INPUT LAYER: Restoring default touch settings"

settings delete system pointer_speed
settings delete global tap_timeout
settings delete global long_press_timeout
settings delete global multi_press_timeout

log "Input & touch settings reset"





# ================= GAME RESET =================
log ">> GAME LAYER: Clearing game performance hooks"

cmd appops set "$GAME" WAKE_LOCK default
cmd appops set "$GAME" RUN_ANY_IN_BACKGROUND default
dumpsys deviceidle whitelist -"$GAME"





# ================= ANDROID 13+ RESET =================
if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config clear game android.os.adpf_predict_frame_time
    cmd device_config clear game android.os.adpf_sustained_performance_mode
    log "Android 13+ performance hints cleared"
fi





log "ARISE HYPER FPS v7.1 UNINSTALL COMPLETE ✔"