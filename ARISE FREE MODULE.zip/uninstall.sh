#!/system/bin/sh

# =========================================
# ARISE FREE MODULE - UNINSTALL ENGINE
# =========================================

R="\033[1;31m"
G="\033[1;32m"
C="\033[1;36m"
W="\033[1;37m"
RESET="\033[0m"

echo -e "${C}[ARISE UNINSTALL] restoring system state...${RESET}"
sleep 1

echo -e "${G}[RESET] animations${RESET}"
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

echo -e "${G}[RESET] game layer${RESET}"
settings put global game_driver_all_apps 0

echo -e "${G}[RESET] standby mode${RESET}"
settings put global app_standby_enabled 1

echo -e "${G}[RESET] memory system${RESET}"
cmd activity memory-factor set 1 2>/dev/null

echo -e "${R}[RESET] re-enabling idle system${RESET}"
cmd deviceidle enable

echo -e "${C}[RESET] cleaning temporary cache${RESET}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sleep 1

echo -e "${W}[DONE] module successfully removed${RESET}"