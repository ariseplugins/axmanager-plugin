#!/system/bin/sh

# =========================================
# ARISE FREE MODULE - INSTALLER CORE
# =========================================

GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
WHITE="\033[1;37m"
RESET="\033[0m"

clear

echo -e "${CYAN}========================================${RESET}"
echo -e "${WHITE}        ARISE FREE MODULE INSTALLER${RESET}"
echo -e "${CYAN}========================================${RESET}"
echo ""

echo -e "${YELLOW}[STEP 1] Device detection running...${RESET}"
MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
ANDROID=$(getprop ro.build.version.release)

echo -e "${GREEN}Model   : $MODEL${RESET}"
echo -e "${GREEN}Device  : $DEVICE${RESET}"
echo -e "${GREEN}Android : $ANDROID${RESET}"

echo ""
echo -e "${YELLOW}[STEP 2] Preparing system environment...${RESET}"
sleep 1

echo -e "${YELLOW}[STEP 3] Setting permissions...${RESET}"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

echo ""
echo -e "${CYAN}========================================${RESET}"
echo -e "${GREEN}INSTALLATION COMPLETE${RESET}"
echo -e "${WHITE}REBOOT RECOMMENDED FOR FULL EFFECT${RESET}"
echo -e "${CYAN}========================================${RESET}"