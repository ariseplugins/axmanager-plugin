#!/system/bin/sh

# =========================================
# ARISE FREE MODULE - SERVICE ENGINE
# =========================================

CYAN="\033[1;36m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
RESET="\033[0m"

log() {
  echo -e "${CYAN}[ARISE SERVICE]${RESET} $1"
}

log "waiting system boot..."

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

sleep 5

log "boot detected successfully"
log "starting background optimization engine..."

MODEL=$(getprop ro.product.model)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(cat /proc/cpuinfo | grep "BogoMIPS" | head -n 1)

log "device model : $MODEL"
log "memory       : $RAM KB"
log "cpu info     : $CPU"

echo -e "${GREEN}[MODULE] memory tuning started${RESET}"
cmd activity memory-factor set 0 2>/dev/null
settings put global app_standby_enabled 0

echo -e "${GREEN}[MODULE] background restriction applied${RESET}"
settings put global settings_enable_monitor_phantom_procs false

echo -e "${GREEN}[MODULE] game service enabled${RESET}"
settings put global game_driver_all_apps 1

echo -e "${GREEN}[MODULE] idle system disabled${RESET}"
cmd deviceidle disable

echo -e "${YELLOW}[MODULE] cache cleanup running${RESET}"
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "service engine fully active"