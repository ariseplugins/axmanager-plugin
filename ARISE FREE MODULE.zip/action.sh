#!/system/bin/sh

# =========================================
# ARISE FREE MODULE - ACTION ENGINE
# =========================================

R="\033[1;31m"
G="\033[1;32m"
Y="\033[1;33m"
C="\033[1;36m"
W="\033[1;37m"
RESET="\033[0m"

echo -e "${C}[ARISE ACTION] initializing system tweaks...${RESET}"
sleep 1

echo -e "${G}[1/8] disabling animations layer${RESET}"
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

echo -e "${G}[2/8] touch response tuning${RESET}"
settings put secure long_press_timeout 180
settings put secure multi_press_timeout 200

echo -e "${G}[3/8] display synchronization${RESET}"
cmd display set-match-content-frame-rate-pref 1 2>/dev/null

echo -e "${G}[4/8] game driver activation${RESET}"
settings put global game_driver_all_apps 1

echo -e "${G}[5/8] background process limit${RESET}"
settings put global settings_enable_monitor_phantom_procs false

echo -e "${G}[6/8] standby optimization${RESET}"
settings put global app_standby_enabled 0

echo -e "${G}[7/8] system responsiveness tweak${RESET}"
cmd activity memory-factor set 0 2>/dev/null

echo -e "${G}[8/8] finalizing optimization layer${RESET}"
sleep 1

echo -e "${Y}[INFO] applying runtime changes...${RESET}"
sleep 1

echo -e "${R}[DONE] action engine completed${RESET}"