#!/system/bin/sh
# ===================================================
#           ARISE FORCE ENGINE v1.0
#        120FPS GAMING OPTIMIZATION CORE
# ===================================================

LOG="[ARISE FORCE ENGINE]"

log() {
  echo "$LOG $1"
}

# ---------------- BOOT SYNC ----------------
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed"
log "Initializing engine core..."

# ===================================================
# SYSTEM PERFORMANCE LAYER
# ===================================================

log "Applying Performance Layer"

cmd power set-fixed-performance-mode-enabled true

for cpu in /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor \
           /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor; do
  echo performance > "$cpu" 2>/dev/null
done

# ===================================================
# GPU / RENDER ENGINE
# ===================================================

log "Activating GPU Engine"

setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_dark false
setprop debug.egl.hw 1
setprop debug.sf.latch_unsignaled 1

# ===================================================
# 120FPS FORCE MODULE
# ===================================================

log "Forcing 120FPS Profile"

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.showfps 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.target_fps 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120

# ===================================================
# FRAME ENGINE STABILIZER
# ===================================================

log "Stabilizing Frame Engine"

setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop debug.sf.disable_backpressure 1

# ===================================================
# INPUT / TOUCH ENGINE
# ===================================================

log "Optimizing Touch System"

setprop debug.input.high_res_sampling 1
setprop debug.input.touch_boost 1
setprop persist.sys.touch_smooth 1

setprop persist.sys.ui.hw 1
setprop windowsmgr.max_events_per_sec 240
setprop ro.min_pointer_dur 8

# ===================================================
# ANIMATION CONTROL
# ===================================================

log "Disabling UI Animations"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# ===================================================
# MEMORY CLEAN ENGINE
# ===================================================

log "Cleaning Memory"

echo 3 > /proc/sys/vm/drop_caches
am kill-all

# ===================================================
# NETWORK STABILITY
# ===================================================

log "Optimizing Network Stack"

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960

# ===================================================
# DEVICE PROFILE SPOOF
# ===================================================

log "Applying Gaming Device Profile"

setprop ro.product.model "POCO X8 Pro Max"
setprop ro.product.brand "Xiaomi"
setprop ro.product.manufacturer "Xiaomi"
setprop ro.build.product "x8promax"

# ===================================================
# FINAL STATUS
# ===================================================

log "Engine fully optimized"
log "ARISE FORCE ENGINE ACTIVE ✔"

# ===================================================
# NOTIFICATION
# ===================================================

cmd notification post \
-S bigtext \
-t "ARISE FORCE ENGINE" \
ax_manager \
"ARISE FORCE ENGINE ACTIVE" \
"120FPS Optimization Successfully Applied 🚀"