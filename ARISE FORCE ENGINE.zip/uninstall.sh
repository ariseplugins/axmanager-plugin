#!/system/bin/sh
# ===================================================
#     ARISE FORCE ENGINE - RESTORE MODULE
#          SYSTEM DEFAULT RECOVERY
# ===================================================

LOG="[ARISE FORCE ENGINE RESTORE]"

log() {
  echo "$LOG $1"
}

# ---------------- BOOT SYNC ----------------
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "Boot completed"
log "Starting system restore..."

# ===================================================
# CPU RESTORE
# ===================================================

log "Restoring CPU Governor"

cmd power set-fixed-performance-mode-enabled false

echo schedutil > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo schedutil > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null

# ===================================================
# GPU RESET
# ===================================================

log "Resetting GPU Settings"

setprop debug.hwui.renderer ""
setprop debug.hwui.force_dark ""
setprop debug.egl.hw ""
setprop debug.sf.latch_unsignaled ""

# ===================================================
# DISPLAY / FPS RESET
# ===================================================

log "Restoring Display Settings"

settings delete system peak_refresh_rate 2>/dev/null
settings delete system min_refresh_rate 2>/dev/null

setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.hwui.target_fps ""

# ===================================================
# FRAME ENGINE RESET
# ===================================================

log "Resetting Frame Optimizations"

setprop debug.performance.tuning ""
setprop video.accelerate.hw ""
setprop debug.sf.disable_backpressure ""

# ===================================================
# SYSTEM RESPONSIVENESS RESET
# ===================================================

log "Restoring System Responsiveness"

setprop persist.sys.ui.hw ""
setprop persist.sys.use_dithering ""
setprop windowsmgr.max_events_per_sec ""
setprop ro.min_pointer_dur ""

# ===================================================
# TOUCH RESET
# ===================================================

log "Restoring Touch Settings"

setprop debug.input.high_res_sampling ""
setprop debug.input.touch_boost ""
setprop persist.sys.touch_smooth ""

# ===================================================
# ANIMATION RESTORE
# ===================================================

log "Restoring UI Animations"

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

# ===================================================
# NETWORK RESET
# ===================================================

log "Restoring Network Stack"

setprop net.tcp.buffersize.default ""
setprop net.tcp.buffersize.wifi ""

# ===================================================
# DEVICE SPOOF REMOVAL
# ===================================================

log "Removing Device Spoof"

setprop ro.product.model ""
setprop ro.product.brand ""
setprop ro.product.manufacturer ""
setprop ro.build.product ""

# ===================================================
# CLEANUP ENGINE
# ===================================================

log "Cleaning System Cache"

echo 3 > /proc/sys/vm/drop_caches

# ===================================================
# FINAL STATUS
# ===================================================

log "System successfully restored"
log "ARISE FORCE ENGINE removed ✔"

# ===================================================
# NOTIFICATION
# ===================================================

cmd notification post \
-S bigtext \
-t "ARISE FORCE ENGINE" \
ax_manager \
"Engine Removed" \
"System Restored to Default ✔"