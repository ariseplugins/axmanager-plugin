#!/system/bin/sh
# ===================================================
#             ARISE FORCE ENGINE
#          GAMING OPTIMIZATION SYSTEM
# ===================================================

LOG="[ARISE FORCE ENGINE]"

log() {
  echo "$LOG $1"
}

clear

# ---------------- BOOT CHECK ----------------
log "Waiting for system boot..."

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

log "System boot completed"
log "Initializing ARISE FORCE ENGINE..."

# ===================================================
# SYSTEM INFO
# ===================================================

DEVICE=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

log "Device: $DEVICE"
log "Android: $ANDROID"

# ===================================================
# PERFORMANCE MODE
# ===================================================

log "Enabling Performance Mode"

cmd power set-fixed-performance-mode-enabled true

# CPU BOOST
log "Applying CPU Performance"

for cpu in /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor \
           /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor; do
  echo performance > "$cpu" 2>/dev/null
done

# ===================================================
# GPU ENGINE
# ===================================================

log "Optimizing GPU Engine"

setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_dark false
setprop debug.egl.hw 1
setprop debug.sf.latch_unsignaled 1

# ===================================================
# DISPLAY / FPS ENGINE
# ===================================================

log "Applying FPS Optimization"

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.target_fps 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120

# ===================================================
# FRAME STABILITY
# ===================================================

log "Stabilizing Frame System"

setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop debug.sf.disable_backpressure 1

# ===================================================
# TOUCH ENGINE
# ===================================================

log "Optimizing Touch Response"

setprop debug.input.high_res_sampling 1
setprop debug.input.touch_boost 1
setprop persist.sys.touch_smooth 1

# ===================================================
# UI OPTIMIZATION
# ===================================================

log "Disabling Animations"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# ===================================================
# MEMORY CLEANER
# ===================================================

log "Cleaning Memory"

echo 3 > /proc/sys/vm/drop_caches
am kill-all

# ===================================================
# NETWORK STABILIZER
# ===================================================

log "Optimizing Network"

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960

# ===================================================
# FINAL STATUS
# ===================================================

log "ARISE FORCE ENGINE ACTIVE ✔"
log "Optimization Successfully Applied 🚀"

# ===================================================
# NOTIFICATION
# ===================================================

cmd notification post \
-S bigtext \
-t "ARISE FORCE ENGINE" \
ax_manager \
"ARISE FORCE ENGINE ACTIVE" \
"Optimization Enabled 🚀"