#!/system/bin/sh

# ARISE FORCE ENGINE - 120FPS MODULE
# Apply all tweaks for ARISE FORCE ENGINE

log() {
  echo "[ARISE FORCE ENGINE] $1"
}

# ---------------------------
# WAIT FOR BOOT
# ---------------------------
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

ui_print " "
ui_print "╔════════════════════════════════╗"
ui_print "║     ARISE FORCE ENGINE        ║"
ui_print "║          120FPS MODE          ║"
ui_print "╚════════════════════════════════╝"
ui_print " "

############################################
# DISPLAY / FPS ENGINE
############################################

ui_print "Display Optimization:"
ui_print " - Force 120Hz Refresh Rate"
ui_print " - Unlock Max FPS"
ui_print " - Stable Frame Engine"
ui_print " - SurfaceFlinger Boost"

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.showfps 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.target_fps 120
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
cmd power set-fixed-performance-mode-enabled true

log "Display Optimized"

############################################
# CPU PERFORMANCE
############################################

ui_print " "
ui_print "CPU Optimization:"
ui_print " - Performance Governor"
ui_print " - CPU Boost Mode"
ui_print " - Stable Processing Speed"

echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo performance > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null

log "CPU Boost Applied"

############################################
# GPU ENGINE
############################################

ui_print " "
ui_print "GPU Optimization:"
ui_print " - Hardware Acceleration"
ui_print " - Rendering Boost"
ui_print " - Smooth Graphics Engine"

setprop debug.hwui.renderer skiagl
setprop debug.hwui.force_dark false
setprop debug.egl.hw 1
setprop debug.sf.latch_unsignaled 1

log "GPU Boost Applied"

############################################
# FRAME RATE OPTIMIZER
############################################

ui_print " "
ui_print "Frame Optimization:"
ui_print " - Frame Rate Stability"
ui_print " - Performance Tuning"
ui_print " - FPS Consistency Engine"

setprop debug.performance.tuning 1
setprop video.accelerate.hw 1
setprop debug.sf.disable_backpressure 1

log "Frame Optimized"

############################################
# LAG & FREEZE FIX
############################################

ui_print " "
ui_print "System Stability:"
ui_print " - Reduce Lag"
ui_print " - Fix Frame Drops"
ui_print " - Input Stability"

setprop persist.sys.ui.hw 1
setprop persist.sys.use_dithering 1
setprop windowsmgr.max_events_per_sec 240
setprop ro.min_pointer_dur 8

log "Lag Reduction Applied"

############################################
# TOUCH BOOST
############################################

ui_print " "
ui_print "Touch Optimization:"
ui_print " - Smooth Touch Engine"
ui_print " - Faster Input Response"
ui_print " - Touch Boost Enabled"

setprop debug.input.high_res_sampling 1
setprop debug.input.touch_boost 1
setprop persist.sys.touch_smooth 1

log "Touch Boost Applied"

############################################
# NO ANIMATION SYSTEM
############################################

ui_print " "
ui_print "Animation Control:"
ui_print " - Disable All Animations"
ui_print " - Instant UI Response"
ui_print " - Zero Delay Transitions"

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

log "Animations Disabled"

############################################
# RAM OPTIMIZATION
############################################

ui_print " "
ui_print "Memory Optimization:"
ui_print " - RAM Cleaner"
ui_print " - Background Cleanup"

echo 3 > /proc/sys/vm/drop_caches
am kill-all

log "RAM Optimized"

############################################
# NETWORK STABILIZER
############################################

ui_print " "
ui_print "Network Optimization:"
ui_print " - Stable Ping"
ui_print " - Reduced Latency"

setprop net.tcp.buffersize.default 4096,87380,256960,4096,16384,256960
setprop net.tcp.buffersize.wifi 4096,87380,256960,4096,16384,256960

log "Network Stabilized"

############################################
# DEVICE SPOOF
############################################

ui_print " "
ui_print "Device Spoof:"
ui_print " - POCO X8 Pro Max"
ui_print " - Gaming Device Profile"

setprop ro.product.model "POCO X8 Pro Max"
setprop ro.product.brand "Xiaomi"
setprop ro.product.manufacturer "Xiaomi"
setprop ro.build.product "x8promax"

log "Device Spoof Applied"

############################################
# COMPLETE
############################################

ui_print " "
ui_print "ARISE FORCE ENGINE 120FPS APPLIED SUCCESSFULLY!"
log "Optimization Completed Successfully!"

############################################
# NOTIFICATION
############################################

cmd notification post \
-S bigtext \
-t "ARISE FORCE ENGINE" \
ax_manager \
"ARISE FORCE ENGINE" \
"120FPS Optimization Applied Successfully 🚀"