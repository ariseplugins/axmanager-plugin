#!/system/bin/sh

MODDIR=${0%/*}

sleep 15

echo "[ARISE] Starting Stability Service..."

sleep 5

# CODM detection loop (simple auto check)
while true; do

if dumpsys window | grep -q "com.activision.callofduty.shooter"; then

    echo "[ARISE] CODM running - applying stability profile"

    # UI stability tuning
    settings put global window_animation_scale 0.4
    settings put global transition_animation_scale 0.4
    settings put global animator_duration_scale 0.4

    # touch responsiveness
    settings put system pointer_speed 7

    # rendering hints
    setprop debug.hwui.renderer skiagl
    setprop debug.performance.tuning 1
    setprop debug.egl.hw 1

    # reduce background load slightly
    cmd activity set-process-limit 3

else
    echo "[ARISE] CODM not active - idle stable mode"
fi

sleep 10

done