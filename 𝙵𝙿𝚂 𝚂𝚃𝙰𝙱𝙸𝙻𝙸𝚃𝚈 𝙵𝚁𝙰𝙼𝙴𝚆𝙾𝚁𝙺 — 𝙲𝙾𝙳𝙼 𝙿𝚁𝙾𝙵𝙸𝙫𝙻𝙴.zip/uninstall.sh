#!/system/bin/sh

echo "[ARISE] Removing Stability Framework..."

settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

settings put system pointer_speed 5

resetprop debug.hwui.renderer
resetprop debug.performance.tuning
resetprop debug.egl.hw

echo "[ARISE] Cleanup completed"