#!/system/bin/sh

ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print " ARISE FPS STABILITY FRAMEWORK"
ui_print " CODM AUTO DETECT ENABLED"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print ""

ui_print "Detecting device..."
sleep 1

DEVICE=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
CPU=$(getprop ro.hardware)

ui_print "Device: $DEVICE"
ui_print "Android: $ANDROID"
ui_print "Chipset: $CPU"
ui_print "RAM: $RAM KB"
ui_print ""

ui_print "CODM Auto Detect: ENABLED"
ui_print "Stability tuning activates when game is running"
ui_print ""

ui_print "No FPS unlocking or hardware modification applied."
ui_print ""

ui_print "— ARISE SYSTEM"
ui_print ""

sleep 1