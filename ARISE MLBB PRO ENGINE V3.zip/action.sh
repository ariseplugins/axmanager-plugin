#!/system/bin/sh

# =========================================
# ARISE MLBB PRO ENGINE V3
# =========================================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
CYAN="\033[1;36m"
MAGENTA="\033[1;35m"
NC="\033[0m"

LOG="[ARISE-MLBB-V3]"

echo -e "${MAGENTA}$LOG =================================${NC}"
echo -e "${MAGENTA}$LOG MLBB PRO ENGINE V3 STARTING${NC}"
echo -e "${MAGENTA}$LOG =================================${NC}"

sleep 0.5

# =========================
# DEVICE CHECK
# =========================

MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

echo -e "${YELLOW}$LOG DEVICE: $MODEL${NC}"
echo -e "${YELLOW}$LOG ANDROID: $ANDROID${NC}"

sleep 0.5

# =========================
# UI SMOOTHNESS
# =========================

echo -e "${CYAN}$LOG UI SMOOTHNESS...${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# =========================
# PERFORMANCE CORE
# =========================

echo -e "${CYAN}$LOG PERFORMANCE CORE...${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

# =========================
# FRAME PACING ENGINE
# =========================

echo -e "${CYAN}$LOG FRAME PACING...${NC}"

setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 1 > /dev/null 2>&1
setprop debug.sf.frame_rate_multiple_threshold 120 > /dev/null 2>&1

# =========================
# INPUT RESPONSE ENGINE
# =========================

echo -e "${CYAN}$LOG INPUT RESPONSE...${NC}"

setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1
setprop debug.input.velocitytracker.strategy impulse > /dev/null 2>&1

# =========================
# CPU STABILITY
# =========================

echo -e "${CYAN}$LOG CPU STABILITY...${NC}"

setprop debug.cpuprio 1 > /dev/null 2>&1

# =========================
# RENDER OPTIMIZATION
# =========================

echo -e "${CYAN}$LOG RENDER ENGINE...${NC}"

setprop debug.hwui.use_buffer_age false > /dev/null 2>&1
setprop debug.hwui.render_dirty_regions false > /dev/null 2>&1

# =========================
# UI PERFORMANCE
# =========================

echo -e "${CYAN}$LOG UI PERFORMANCE...${NC}"

setprop persist.sys.ui.hw 1 > /dev/null 2>&1

# =========================
# BACKGROUND CONTROL
# =========================

echo -e "${CYAN}$LOG BACKGROUND CONTROL...${NC}"

am kill-all > /dev/null 2>&1

# =========================
# STABILITY LOOP
# =========================

echo -e "${CYAN}$LOG STABILITY CONTROL...${NC}"

COUNT=0
while [ $COUNT -lt 4 ]; do
    setprop debug.performance.tuning 1 > /dev/null 2>&1
    sync
    COUNT=$((COUNT+1))
    sleep 0.5
done

sync

echo -e "${GREEN}$LOG =================================${NC}"
echo -e "${GREEN}$LOG MLBB ENGINE ACTIVE${NC}"
echo -e "${GREEN}$LOG STABLE FPS + SMOOTH GAMEPLAY READY${NC}"
echo -e "${GREEN}$LOG =================================${NC}"