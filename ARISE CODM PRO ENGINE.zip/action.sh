#!/system/bin/sh

# =========================================
# ARISE CODM PRO ENGINE
# NEW STRUCTURE (FUNCTION BASED)
# =========================================

LOG="[ARISE-CODM]"

print_line() {
    echo "$LOG ---------------------------------"
}

info() {
    echo "$LOG $1"
}

apply_prop() {
    setprop "$1" "$2" > /dev/null 2>&1
}

# =========================
# INIT
# =========================

print_line
info "INITIALIZING CODM ENGINE"
print_line

sleep 0.5

# =========================
# DEVICE INFO
# =========================

MODEL=$(getprop ro.product.model)
ANDROID=$(getprop ro.build.version.release)

info "DEVICE : $MODEL"
info "ANDROID: $ANDROID"

# =========================
# UI TUNING
# =========================

ui_tuning() {
    info "Applying UI tuning"
    settings put global window_animation_scale 0.5
    settings put global transition_animation_scale 0.5
    settings put global animator_duration_scale 0.5
}

# =========================
# PERFORMANCE CORE
# =========================

performance_core() {
    info "Applying performance core"
    apply_prop debug.performance.tuning 1
    apply_prop debug.hwui.renderer skiagl
    apply_prop debug.choreographer.skipwarning 1
}

# =========================
# FRAME STABILITY
# =========================

frame_stability() {
    info "Stabilizing frame behavior"
    apply_prop debug.sf.latch_unsignaled 1
    apply_prop debug.sf.enable_gl_backpressure 1
    apply_prop debug.sf.frame_rate_multiple_threshold 120
}

# =========================
# INPUT RESPONSE
# =========================

input_boost() {
    info "Optimizing input response"
    apply_prop windowsmgr.max_events_per_sec 90
    apply_prop ro.min_pointer_dur 8
    apply_prop debug.input.velocitytracker.strategy impulse
}

# =========================
# RENDER TUNING
# =========================

render_tuning() {
    info "Optimizing render pipeline"
    apply_prop debug.hwui.use_buffer_age false
    apply_prop debug.hwui.render_dirty_regions false
}

# =========================
# BACKGROUND CONTROL
# =========================

background_clean() {
    info "Cleaning background processes"
    am kill-all > /dev/null 2>&1
}

# =========================
# EXECUTION
# =========================

ui_tuning
performance_core
frame_stability
input_boost
render_tuning
background_clean

sync

print_line
info "CODM ENGINE ACTIVE"
info "STABLE + RESPONSIVE GAMEPLAY READY"
print_line