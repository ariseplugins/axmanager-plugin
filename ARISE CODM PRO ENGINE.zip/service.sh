#!/system/bin/sh

LOG="[ARISE-CODM]"

log() {
    echo "$LOG $1"
}

PKG="com.activision.callofduty.shooter"

log "SERVICE STARTED"

while true; do

    CURRENT=$(dumpsys window | grep mCurrentFocus | awk -F'/' '{print $1}' | awk '{print $NF}')

    if echo "$CURRENT" | grep -q "$PKG"; then
        log "CODM DETECTED"

        setprop debug.performance.tuning 1 > /dev/null 2>&1
        sync > /dev/null 2>&1
    fi

    sleep 60

done