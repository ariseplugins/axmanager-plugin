#!/system/bin/sh

LOG="[ARISE-HUB-V2]"

CODM="com.activision.callofduty.shooter"
PUBG="com.tencent.ig"
BLOOD="com.netease.newspike"
FF="com.dts.freefireth"
ML="com.mobile.legends"
ROBLOX="com.roblox.client"
MC="com.mojang.minecraftpe"

MODE="idle"
CYCLE=0

echo "$LOG SERVICE ENGINE STARTED"

while true; do

    CYCLE=$((CYCLE+1))

    APP=$(dumpsys window | grep mCurrentFocus | cut -d "/" -f1 | awk '{print $NF}')

    echo "$LOG DETECTED: $APP"

    if echo "$APP" | grep -qE "$CODM|$PUBG|$BLOOD|$FF"; then

        if [ "$MODE" != "shooter" ]; then
            echo "$LOG MODE → SHOOTER"
            am kill-all > /dev/null 2>&1
            MODE="shooter"
        fi

    elif echo "$APP" | grep -q "$ML"; then

        if [ "$MODE" != "moba" ]; then
            echo "$LOG MODE → MOBA"
            am kill-all > /dev/null 2>&1
            MODE="moba"
        fi

    elif echo "$APP" | grep -qE "$ROBLOX|$MC"; then

        if [ "$MODE" != "sandbox" ]; then
            echo "$LOG MODE → SANDBOX"
            am kill-all > /dev/null 2>&1
            MODE="sandbox"
        fi

    else
        MODE="idle"
    fi

    if [ $((CYCLE % 3)) -eq 0 ]; then
        sync > /dev/null 2>&1
        echo "$LOG SYSTEM SYNC"
    fi

    sleep 15

done