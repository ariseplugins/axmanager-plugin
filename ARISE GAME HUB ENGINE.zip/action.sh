#!/system/bin/sh

# =========================================
# ARISE GAME HUB ENGINE V2 - EXTENDED CORE
# =========================================

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
MAGENTA="\033[1;35m"
NC="\033[0m"

LOG="[ARISE-HUB-V2]"

echo -e "${BLUE}$LOG =========================================${NC}"
echo -e "${BLUE}$LOG INITIALIZING GAME HUB ENGINE${NC}"
echo -e "${BLUE}$LOG =========================================${NC}"

sleep 0.5

# DEVICE INFO
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
DEVICE=$(getprop ro.product.device)
ANDROID=$(getprop ro.build.version.release)
SDK=$(getprop ro.build.version.sdk)

echo -e "${YELLOW}$LOG DEVICE ANALYSIS${NC}"
echo "$LOG BRAND   : $BRAND"
echo "$LOG MODEL   : $MODEL"
echo "$LOG DEVICE  : $DEVICE"
echo "$LOG ANDROID : $ANDROID"
echo "$LOG SDK     : $SDK"

sleep 0.5

if [ "$SDK" -lt 29 ]; then
    echo -e "${RED}$LOG UNSUPPORTED DEVICE${NC}"
    exit 1
fi

echo -e "${GREEN}$LOG DEVICE COMPATIBLE${NC}"

# TIME CHECK
HOUR=$(date +"%H")

echo -e "${YELLOW}$LOG TIME CHECK${NC}"

if [ "$HOUR" -lt 6 ]; then
    echo "$LOG NIGHT MODE"
elif [ "$HOUR" -lt 18 ]; then
    echo "$LOG DAY MODE"
else
    echo "$LOG EVENING MODE"
fi

sleep 0.5

# UI SMOOTH
echo -e "${CYAN}$LOG APPLYING UI SMOOTHING...${NC}"
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# PERFORMANCE CORE
echo -e "${CYAN}$LOG APPLYING PERFORMANCE CORE...${NC}"
setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.choreographer.skipwarning 1 > /dev/null 2>&1

# FPS STABILITY
echo -e "${CYAN}$LOG APPLYING STABLE FPS ENGINE...${NC}"
setprop debug.sf.latch_unsignaled 1 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 1 > /dev/null 2>&1

# TOUCH RESPONSE
echo -e "${CYAN}$LOG BOOSTING TOUCH RESPONSE...${NC}"
setprop windowsmgr.max_events_per_sec 90 > /dev/null 2>&1
setprop ro.min_pointer_dur 8 > /dev/null 2>&1

# CLEAN BACKGROUND
echo -e "${CYAN}$LOG CLEANING BACKGROUND...${NC}"
am kill-all > /dev/null 2>&1

# STABILITY LOOP
echo -e "${MAGENTA}$LOG STABILITY CONTROL INIT...${NC}"
COUNT=0
while [ $COUNT -lt 3 ]; do
    setprop debug.performance.tuning 1 > /dev/null 2>&1
    COUNT=$((COUNT+1))
    sleep 0.5
done

sync

echo -e "${GREEN}$LOG =========================================${NC}"
echo -e "${GREEN}$LOG GAME HUB ENGINE ACTIVE${NC}"
echo -e "${GREEN}$LOG STABLE FPS + PERFORMANCE READY${NC}"
echo -e "${GREEN}$LOG =========================================${NC}"