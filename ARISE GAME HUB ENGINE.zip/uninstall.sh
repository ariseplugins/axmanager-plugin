#!/system/bin/sh

LOG="[ARISE-HUB-V2]"

echo "$LOG UNINSTALL STARTED"

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

setprop debug.performance.tuning 0 > /dev/null 2>&1
setprop debug.hwui.renderer "" > /dev/null 2>&1
setprop debug.sf.latch_unsignaled 0 > /dev/null 2>&1
setprop debug.sf.enable_gl_backpressure 0 > /dev/null 2>&1

am kill-all > /dev/null 2>&1

sync

echo "$LOG SYSTEM RESTORED"