#!/system/bin/sh
# ARISE SYSTEM CODM VIP SERVICE v3.1

MODDIR=${0%/*}

# ==========================
# TARGET APPS
# ==========================

cmd package trim-caches 999999999999 com.garena.game.codm

cmd game set --mode 2 --downscale 0.5 com.garena.game.codm
cmd game set --mode 2 --downscale 0.5 com.dualspace.multispace.android
cmd game set --mode 2 --downscale 0.5 com.ludashi.superboost

pm trim-caches 999999999999

# ==========================
# UI / PERFORMANCE FLAGS
# ==========================

setprop debug.hwui.use_hint_manager true
settings put system background_power_saving_enable 0
settings put global low_power 0

setprop debug.hwui.max_texture_allocation 33554432
setprop debug.hwui.render_thread true
setprop debug.hwui.skip_empty_damage true

settings put global debug.hwui.renderer skiagl

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

setprop debug.hwui.disable_vsync true 2>/dev/null
setprop debug.hwui.force_dark false 2>/dev/null

settings put system purgeable_assets 1 >/dev/null 2>&1
settings put system use_16bpp_alpha 1 >/dev/null 2>&1

# ==========================
# TOUCH OPTIMIZATION
# ==========================

setprop debug.touch.orientationAware 0 >/dev/null 2>&1
setprop debug.touch.size.scale 1 >/dev/null 2>&1
setprop debug.touch.size.isSummed 0 >/dev/null 2>&1
setprop debug.touch.pressure.scale 0 >/dev/null 2>&1

setprop debug.SurfaceOrientation 0 >/dev/null 2>&1
setprop debug.TapDragInterval 0.1ms >/dev/null 2>&1
setprop debug.QuietInterval 0.1ms >/dev/null 2>&1
setprop debug.MovementSpeedRatio 0.8 >/dev/null 2>&1

settings put system ui.hw 1 >/dev/null 2>&1

# ==========================
# MULTITOUCH / INPUT
# ==========================

setprop debug.MultitouchMinDistance 1px >/dev/null 2>&1
setprop debug.MultitouchSettleInterval 0.1ms >/dev/null 2>&1
setprop debug.TapInterval 0.1ms >/dev/null 2>&1
setprop debug.TapSlop 1px >/dev/null 2>&1

settings put system dev.pm.dyn_samplingrate 1 >/dev/null 2>&1
setprop debug.windowsmgr.max_events_per_sec 60 >/dev/null 2>&1
setprop debug.view.scroll_friction 0 >/dev/null 2>&1

# ==========================
# GAME MODE
# ==========================

settings put global game_mode_enabled 1
settings put global game_mode_com.mobile.legends 2
settings put global game_mode_com.pubg.imobile 2
settings put global game_mode_com.tencent.tmgp.sgame 2
settings put global game_mode_com.garena.game.codm 2
settings put global game_mode_com.dts.freefireth 2
settings put global game_mode_com.miHoYo.GenshinImpact 2

# ==========================
# NOTIFICATION (SAFE FIX)
# ==========================

cmd notification post -S bigtext -t "ARISE SYSTEM CODM VIP" "OWNER: ARISE" "STATUS: ACTIVE 🟢" >/dev/null 2>&1

# ==========================
# FPS / REFRESH LOCK
# ==========================

setprop debug.codm.fps 120
setprop debug.codm.fps_target 120
setprop debug.codm.fps_max 120
setprop debug.codm.refresh_rate 120

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120

# ==========================
# GAME DRIVER
# ==========================

settings put global game_driver_all_apps 1
cmd power set-fixed-performance-mode-enabled true
cmd game set --mode performance com.garena.game.codm

# ==========================
# CLEAN END
# ==========================

echo "ARISE SYSTEM VIP SERVICE LOADED"