#!/system/bin/sh
# ARISE SYSTEM CODM VIP - UNINSTALL v3.1

echo -e "\033[1;31m"
cat << "EOF"

  ██████╗ ██████╗ ██████╗ ███╗   ███╗
 ██╔════╝██╔═══██╗██╔═══██╗████╗ ████║
 ██║     ██║   ██║██║   ██║██╔████╔██║
 ██║     ██║   ██║██║   ██║██║╚██╔╝██║
 ╚██████╗╚██████╔╝╚██████╔╝██║ ╚═╝ ██║
  ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝     ╚═╝

        C O D M   V I P   S Y S T E M

EOF
echo -e "\033[0m"

echo -e "\033[1;35mOWNER: ARISE\033[0m"
echo -e "\033[1;36mSTATUS: VIP SERVICES ACTIVE v3.1\033[0m"
echo ""

# ==========================================
# RESET PERFORMANCE MODE
# ==========================================
cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1

# RESET GAME MODE
cmd game reset com.garena.game.codm >/dev/null 2>&1

# RESET GAME DRIVER
settings delete global game_driver_all_apps >/dev/null 2>&1

# RESET ANIMATIONS (DEFAULT)
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

# RESET REFRESH RATE
settings delete system peak_refresh_rate >/dev/null 2>&1
settings delete system min_refresh_rate >/dev/null 2>&1

# RESET POWER SAVING
settings delete system background_power_saving_enable >/dev/null 2>&1
settings delete global low_power >/dev/null 2>&1

# RESET HWUI / RENDER
setprop debug.hwui.renderer ""
setprop debug.renderengine.backend ""

# RESET TOUCH (SAFE)
setprop debug.touch.orientationAware ""
setprop debug.touch.size.scale ""
setprop debug.touch.pressure.scale ""

# RESET FPS / CODM PROPS
setprop debug.codm.fps ""
setprop debug.codm.fps_target ""
setprop debug.codm.performance_mode ""

# CLEAR GAME OVERLAY
device_config delete namespace game_overlay >/dev/null 2>&1
device_config delete game_overlay com.garena.game.codm >/dev/null 2>&1

# REMOVE CONTENT VALUES
content delete --uri content://settings/global --where "name LIKE 'com.garena.game.codm%'" >/dev/null 2>&1

# RESET VULKAN / GPU
setprop debug.vulkan.render ""
setprop debug.performance.mode ""

# RESET THERMAL
settings delete global thermal_control >/dev/null 2>&1
settings delete global thermal_throttle >/dev/null 2>&1

# REMOVE WHITELIST (FIXED - correct syntax)
cmd deviceidle whitelist -com.tencent.tmgp.sgame >/dev/null 2>&1
cmd deviceidle whitelist -com.dts.freefireth >/dev/null 2>&1
cmd deviceidle whitelist -com.mobile.legends >/dev/null 2>&1
cmd deviceidle whitelist -com.pubg.imobile >/dev/null 2>&1
cmd deviceidle whitelist -com.garena.game.codm >/dev/null 2>&1

# RESET GAME MODE SETTINGS
settings delete global game_mode_enabled >/dev/null 2>&1

# NOTIFICATION
cmd notification post -S bigpicture -t "CODM VIP SYSTEM" "ARISE" "UNINSTALL CLEAN RESET DONE 🔴" >/dev/null 2>&1