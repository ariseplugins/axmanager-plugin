#!/system/bin/sh
# ARISE SYSTEM CODM VIP - CUSTOMIZE SCRIPT
# OWNER: ARISE

echo -e "\033[1;31m"
cat << "EOF"

  ██████╗ ██████╗ ██████╗ ███╗   ███╗
 ██╔════╝██╔═══██╗██╔═══██╗████╗ ████║
 ██║     ██║   ██║██║   ██║██╔████╔██║
 ██║     ██║   ██║██║   ██║██║╚██╔╝██║
 ╚██████╗╚██████╔╝╚██████╔╝██║ ╚═╝ ██║
  ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝     ╚═╝

        C O D M   V I P

EOF
echo -e "\033[0m"

echo -e "\033[1;35mOWNER: ARISE\033[0m"
echo ""

# ==========================================
# IF REGISTERED: SHOW OPTIMIZATION DETAILS
# ==========================================
echo -e "\033[1;32m  _________________________________________ \033[0m"
echo -e "\033[1;32m |        ARISE SYSTEM ACTIVE              |\033[0m"
echo -e "\033[1;32m |_________________________________________|\033[0m"
echo -e "\033[1;34m  Owner: ARISE SYSTEM \033[0m"
echo -e "\033[1;35m [ INITIATING SYSTEM OVERDRIVE... ] \033[0m"

echo ""

echo -e "\033[1;35m [ GAME SUPPORT LIST ] \033[0m"
echo -e "\033[1;37m  CALL OF DUTY GARENA | CALL OF DUTY GLOBAL\033[0m"
echo ""

# FINAL STATUS
echo -e "\033[1;32m [✓] LICENSE VERIFIED: ARISE ACTIVE \033[0m"
echo -e "\033[1;32m [✓] ALL SYSTEM TWEAKS APPLIED \033[0m"
echo -e "\033[1;37m  ENJOY SMOOTH PERFORMANCE GAMING \033[0m"
echo -e "\033[1;32m  _________________________________________ \033[0m"

# BACKGROUND SERVICE (SAFE CHECK)
if [ -f "$MODDIR/service.sh" ]; then
    nohup sh "$MODDIR/service.sh" >/dev/null 2>&1 &
fi

G='\033[0;32m'
W='\033[1;37m'
NC='\033[0m'

echo -e "${G}=========================================="
echo -e "${W}    ARISE PERFORMANCE ENGINE             "
echo -e "${G}==========================================${NC}"

echo -e "${G}[+]${W} 120FPS MODE ENGAGED"
echo -e "${G}[+]${W} TARGET 120HZ"

sleep 1
echo -e "\033[1;32mLOADING SYSTEM...\033[0m"

echo -e "\033[1;34m[■■□□□□□□□□] 20%\033[0m"
sleep 0.5
echo -e "\033[1;36m[■■■■□□□□□□] 40%\033[0m"
sleep 0.5
echo -e "\033[1;33m[■■■■■■□□□□] 60%\033[0m"
sleep 0.5
echo -e "\033[1;32m[■■■■■■■■□□] 80%\033[0m"
sleep 0.5
echo -e "\033[1;32m[■■■■■■■■■■] 100%\033[0m"

sleep 2
echo -e "\033[1;32mSYSTEM READY\033[0m"

pkg_codm="com.garena.game.codm"

cmd game set --mode 2 --downscale 0.6 com.garena.game.codm

cmd package trim-caches 999999999999 com.garena.game.codm
pm trim-caches 999999999999

dumpsys deviceidle whitelist +com.tencent.tmgp.sgame
dumpsys deviceidle whitelist +com.dts.freefireth
dumpsys deviceidle whitelist +com.mobile.legends
dumpsys deviceidle whitelist +com.pubg.imobile
dumpsys deviceidle whitelist +com.garena.game.codm

setprop debug.hwui.use_hint_manager true
settings put system background_power_saving_enable 0
settings put global low_power 0

settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

echo -e "\033[1;32mDONE\033[0m"

cmd notification post -S bigpicture -t "ARISE CODM VIP ACTIVE" "ARISE SYSTEM" "STATUS: ONLINE 🟢" >/dev/null 2>&1