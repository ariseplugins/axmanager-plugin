#!/system/bin/sh

# =========================================================
#               ARISE GAMING CORE ENGINE
#          Advanced System Optimization Layer
#                Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
RESET='\033[0m'

# ================= LOGGER =================
log() {
    echo -e "${CYAN}[@ariseplugin CORE]${RESET} $1"
}

# ================= BOOT CHECK =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected. Initializing ARISE CORE engine..."

# ================= DEVICE INFO =================
FPS=$(settings get system peak_refresh_rate 2>/dev/null || echo 120)
RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
CPU_CORES=$(nproc)
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

log "Device Scan Complete"
log "RAM=${RAM_KB}KB | CORES=${CPU_CORES} | Android=${ANDROID_VER} | FPS=${FPS}"

# ================= GRAPHICS ENGINE =================
setprop debug.hwui.use_fence_wait false
setprop debug.hwui.force_gpu_overdraw false
setprop debug.hwui.accelerated_linear false
setprop debug.hwui.defer_rendering true
setprop debug.sf.disable_hwc_vsync 1
setprop debug.sf.present_time_offset_us 1500

log "Rendering pipeline optimized"

# ================= MEMORY ENGINE =================
settings put global background_process_limit 3
settings put global low_ram_mode 1
settings put global activity_manager_constants "max_cached_processes=3,max_phantom_processes=5,background_settle_time=20000,force_bg_check_on_restricted=false"

log "Memory optimization applied"

# ================= SYSTEM PERFORMANCE =================
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system pointer_speed 7

log "System performance tuned"

# ================= GAME ENGINE =================
GAME_PACKAGE="com.garena.game.codm"

cmd appops set "$GAME_PACKAGE" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" RUN_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" WAKE_LOCK allow
cmd appops set "$GAME_PACKAGE" SYSTEM_ALERT_WINDOW allow
dumpsys deviceidle whitelist +"$GAME_PACKAGE"

downscale=0.5
fps_override=144

# ================= GAME MODE =================
if [ "$ANDROID_VER" -ge 12 ]; then
    cmd game set --mode 2 --downscale "$downscale" --fps "$fps_override" "$GAME_PACKAGE"
fi

# ================= ANDROID 13+ ENGINE =================
if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render true
    cmd device_config override game android.os.adpf_hwui_gpu true
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync true
    log "Advanced gaming flags activated"
fi

# ================= FINAL STATUS =================
log "Performance layer fully deployed"
log "ARISE GAMING CORE ACTIVE"
log "Powered by @ariseplugin"