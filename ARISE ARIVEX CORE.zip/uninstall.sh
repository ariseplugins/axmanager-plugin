#!/system/bin/sh

# =========================================================
#              ARISE CORE RESET ENGINE
#        AGGRESSIVE RESTORE + CLEAN STATE MODULE
#                Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
PURPLE='\033[1;35m'
RESET='\033[0m'

# ================= LOGGER =================
log() {
  echo -e "${CYAN}[@ariseplugin RESET]${RESET} $1"
}

echo -e "${PURPLE}============================================${RESET}"
echo -e "${RED}      ARISE AGGRESSIVE RESTORE ENGINE      ${RESET}"
echo -e "${PURPLE}============================================${RESET}"

log "Starting aggressive system restoration sequence..."

GAME_PACKAGE="com.garena.game.codm"
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)

# ================= FORCE STOP GAME =================
log "Force stopping active game processes..."
am force-stop $GAME_PACKAGE 2>/dev/null

# ================= AGGRESSIVE CLEAN LAYER =================
log "Purging performance overlays and cached tuning layers..."

resetprop -p debug.hwui.use_fence_wait
resetprop -p debug.hwui.force_gpu_overdraw
resetprop -p debug.hwui.accelerated_linear
resetprop -p debug.hwui.defer_rendering
resetprop -p debug.sf.disable_hwc_vsync
resetprop -p debug.sf.present_time_offset_us

# ================= MEMORY RESTORE =================
log "Restoring memory system to default aggressive-safe state..."

settings delete global background_process_limit
settings delete global low_ram_mode
settings delete global activity_manager_constants

settings put global cached_apps_freezer 0
settings put global app_standby_enabled 1

# ================= ANIMATION RESTORE =================
settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1
settings put system pointer_speed 0

log "UI animation pipeline normalized"

# ================= AGGRESSIVE GAME RESET =================
log "Resetting game performance injection layer..."

cmd appops reset $GAME_PACKAGE
dumpsys deviceidle whitelist -$GAME_PACKAGE

if [ "$ANDROID_VER" -ge 12 ]; then
    cmd game reset $GAME_PACKAGE 2>/dev/null
fi

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render false
    cmd device_config override game android.os.adpf_hwui_gpu false
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync false
fi

# ================= AGGRESSIVE CLEAN BOOST CLEAR =================
log "Flushing system performance cache layers..."

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
sync

# ================= THERMAL & POWER NORMALIZE =================
log "Resetting thermal and power behavior..."

setprop debug.thermal.throttle.support yes 2>/dev/null
cmd deviceidle enable

# ================= FINAL ENGINE RESET =================
log "Finalizing aggressive restore sequence..."

setprop debug.sf.use_phase_offsets_as_durations 0
setprop debug.hwui.render_dirty_regions true
setprop debug.performance.tuning 0

# ================= STATUS =================
echo ""
echo -e "${GREEN}============================================${RESET}"
echo -e "${GREEN}   ARISE AGGRESSIVE RESET COMPLETED        ${RESET}"
echo -e "${GREEN}   SYSTEM RESTORED TO SAFE DEFAULT STATE   ${RESET}"
echo -e "${GREEN}============================================${RESET}"
echo ""

log "ARISE RESET ENGINE finished successfully"
log "Powered by @ariseplugin"