#!/system/bin/sh

# =========================================================
#                 ARIVEX CORE ENGINE
#         Advanced Gaming Optimization Framework
#              Powered by @ariseplugin
# =========================================================

# ================= COLOR SYSTEM =================
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[1;36m'
BLUE='\033[1;34m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
RESET='\033[0m'

# ================= HEADER =================
echo -e "${PURPLE}╔══════════════════════════════════════════════╗${RESET}"
echo -e "${PURPLE}║                ARIVEX CORE                  ║${RESET}"
echo -e "${PURPLE}║       Advanced Gaming Optimization          ║${RESET}"
echo -e "${PURPLE}║         Powered by @ariseplugin             ║${RESET}"
echo -e "${PURPLE}╚══════════════════════════════════════════════╝${RESET}"
echo ""

# ================= LOGGER =================
log() {
    echo -e "${CYAN}[@ariseplugin ARIVEX CORE]${RESET} $1"
}

# ================= DEVICE INFO =================
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_BRAND=$(getprop ro.product.brand)
ANDROID_VER=$(getprop ro.build.version.release | cut -d. -f1)
CPU_CORES=$(nproc)
RAM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
FPS=$(settings get system peak_refresh_rate 2>/dev/null || echo 120)

log "Checking device environment..."
log "Brand: $DEVICE_BRAND"
log "Model: $DEVICE_MODEL"
log "Android: $ANDROID_VER"
log "CPU Cores: $CPU_CORES"
log "RAM: ${RAM_KB}KB"
log "FPS Capability: $FPS"

# ================= DEVICE CLASS =================
if [ "$RAM_KB" -ge 8000000 ]; then
    DEVICE_CLASS="FLAGSHIP"
elif [ "$RAM_KB" -ge 6000000 ]; then
    DEVICE_CLASS="MID-HIGH"
elif [ "$RAM_KB" -ge 4000000 ]; then
    DEVICE_CLASS="MID-RANGE"
else
    DEVICE_CLASS="LOW-END"
fi

log "Device Tier: $DEVICE_CLASS"

# ================= BOOT CHECK =================
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

log "System boot detected. Initializing ARIVEX CORE..."

# ================= GRAPHICS ENGINE =================
setprop debug.hwui.use_fence_wait false
setprop debug.hwui.force_gpu_overdraw false
setprop debug.hwui.accelerated_linear false
setprop debug.hwui.defer_rendering true
setprop debug.sf.disable_hwc_vsync 1
setprop debug.sf.present_time_offset_us 1500
log "Graphics engine optimized"

# ================= MEMORY ENGINE =================
settings put global background_process_limit 3
settings put global low_ram_mode 1
settings put global activity_manager_constants "max_cached_processes=3,max_phantom_processes=5,background_settle_time=20000,force_bg_check_on_restricted=false"
log "Memory system optimized"

# ================= SYSTEM PERFORMANCE =================
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0
settings put system pointer_speed 7
log "System performance tuned"

# ================= GAME ENGINE =================
GAME_PACKAGE="com.garena.game.codm"

cmd appops set "$GAME_PACKAGE" RUN_ANY_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" RUN_IN_BACKGROUND allow
cmd appops set "$GAME_PACKAGE" WAKE_LOCK allow
cmd appops set "$GAME_PACKAGE" SYSTEM_ALERT_WINDOW allow
dumpsys deviceidle whitelist +"$GAME_PACKAGE"

downscale=0.5
fps_override=120

if [ "$ANDROID_VER" -ge 12 ]; then
    cmd game set --mode 2 --downscale "$downscale" --fps "$fps_override" "$GAME_PACKAGE"
fi

if [ "$ANDROID_VER" -ge 13 ]; then
    cmd device_config override game android.os.adpf_use_async_render true
    cmd device_config override game android.os.adpf_hwui_gpu true
    cmd device_config override game android.os.adpf_skip_surface_flinger_sync true
    log "Advanced game flags enabled"
fi

# ================= FINAL ENGINE =================
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.renderengine.backend skiagl
setprop debug.hwui.render_dirty_regions false
setprop debug.performance.tuning 1

settings put global cached_apps_freezer 1
settings put global app_standby_enabled 0

log "Base optimization layer applied"

# ================= ADVANCED ARISE MODULES =================
log "Initializing ARISE advanced modules..."

# Stability Monitor
STABILITY_STATUS="STABLE"
[ "$RAM_KB" -lt 3000000 ] && STABILITY_STATUS="LOW MEMORY WARNING"
log "Stability: $STABILITY_STATUS"

# FPS Profile
if [ "$FPS" -ge 120 ]; then
    FPS_MODE="ULTRA SMOOTH"
elif [ "$FPS" -ge 90 ]; then
    FPS_MODE="BALANCED"
else
    FPS_MODE="PERFORMANCE BOOST"
fi
log "FPS Mode: $FPS_MODE"

# Input System
INPUT_MODE="LOW LATENCY ACTIVE"
log "Input: $INPUT_MODE"

# Thermal (simulation)
TEMP_PROFILE="NORMAL"
log "Thermal: $TEMP_PROFILE"

# Game Priority
GAME_PRIORITY="ACTIVE"
log "Game Priority: ENABLED"

# Engine Health
ENGINE_HEALTH="OPTIMAL"
log "Engine Health: $ENGINE_HEALTH"

# Performance Mode
if [ "$DEVICE_CLASS" = "FLAGSHIP" ]; then
    PERF_MODE="MAXIMUM PERFORMANCE"
else
    PERF_MODE="BALANCED OPTIMIZED"
fi

log "Performance Mode: $PERF_MODE"

# ================= FINAL STATUS =================
echo ""
echo -e "${PURPLE}══════════════════════════════════════════════${RESET}"
echo -e "${GREEN}         ARIVEX CORE ACTIVE                 ${RESET}"
echo -e "${PURPLE}══════════════════════════════════════════════${RESET}"
echo ""

log "ARIVEX CORE fully optimized by @ariseplugin"