#!/system/bin/sh

while true; do

  # light stability refresh (not aggressive)
  am kill-all > /dev/null 2>&1

  # keep animation smooth
  settings put global window_animation_scale 0.5
  settings put global transition_animation_scale 0.5
  settings put global animator_duration_scale 0.5

  sleep 60

done