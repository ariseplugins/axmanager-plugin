#!/system/bin/sh

echo "ARISE BOOST START"

am kill-all > /dev/null 2>&1

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

setprop debug.hwui.renderer skiagl > /dev/null 2>&1
setprop debug.performance.tuning 1 > /dev/null 2>&1

sleep 1

echo "BOOST DONE"