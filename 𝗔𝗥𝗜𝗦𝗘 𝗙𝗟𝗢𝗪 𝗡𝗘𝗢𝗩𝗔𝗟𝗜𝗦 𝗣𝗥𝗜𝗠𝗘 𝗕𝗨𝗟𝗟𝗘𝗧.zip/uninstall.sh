#!/system/bin/sh
#─────────────────────────────────────────────────────────────
#ARISE SYSTEM RESTORE ENGINE
#─────────────────────────────────────────────────────────────
#ORIGINAL CONCEPT BY:
#@ariseplugin
#─────────────────────────────────────────────────────────────
#This module safely restores Android performance-related flags
#and resets game optimization layers applied by ARISE ENGINE.
#─────────────────────────────────────────────────────────────

apply_dc() {
    ns="$1"; key="$2"; val="$3"
    cmd device_config put "$ns" "$key" "$val" 2>/dev/null
}

echo "────────────────────────────"
echo "     ARISE RESTORE ENGINE"
echo "────────────────────────────"
echo ""

#────────────────────────────────────────────
# RESET ADPF & GAME HINT SYSTEM
#────────────────────────────────────────────

apply_dc game com.android.server.power.hint.adpf_session_tag false
apply_dc game android.os.adpf_measure_during_input_event_boost false
apply_dc game android.os.adpf_obtainview_boost false
apply_dc game android.os.adpf_hwui_gpu false

apply_dc core_graphics android.view.flags.set_frame_rate_callback false
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.use_known_refresh_rate_for_fps_consistency false
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.frame_rate_category_mrr false

apply_dc toolkit android.view.flags.toolkit_set_frame_rate false
apply_dc toolkit android.view.flags.toolkit_metrics_for_frame_rate_decision false

apply_dc interaction_jank_monitor trace_threshold_frame_time_millis 64
apply_dc interaction_jank_monitor trace_threshold_missed_frames 3

apply_dc window_surfaces com.android.window.flags.explicit_refresh_rate_hints false
apply_dc window_surfaces com.android.window.flags.enable_buffer_transform_hint_from_display false

apply_dc display_manager com.android.server.display.feature.flags.ignore_app_preferred_refresh_rate_request true
apply_dc display_manager com.android.server.display.feature.flags.enable_user_preferred_mode_vote false
apply_dc display_manager com.android.server.display.feature.flags.enable_displays_refresh_rates_synchronization false

#────────────────────────────────────────────
# SYSTEM SETTINGS RESTORE
#────────────────────────────────────────────

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

settings delete global app_standby_enabled 2>/dev/null
settings delete global cached_apps_freezer 2>/dev/null
settings put global background_data 1

settings delete global force_hw_ui 2>/dev/null

#────────────────────────────────────────────
# GRAPHICS RESET LAYER
#────────────────────────────────────────────

setprop debug.hwui.renderer ""
setprop debug.sf.hw 0
setprop debug.gpud.gl.renderer ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.hwui.shadow.renderer ""
setprop debug.renderengine.backend ""

setprop debug.composition.type ""
setprop debug.hwui.render_dirty_regions true
setprop debug.dumpstate 1

#────────────────────────────────────────────
# GAME COMPAT RESET
#────────────────────────────────────────────

for p in \
com.garena.game.codm \
com.mobile.legends \
com.netease.newspike \
com.tencent.ig \
com.miHoYo.GenshinImpact \
com.roblox.client
do
  am compat reset-all "$p" >/dev/null 2>&1
  cmd game reset "$p" >/dev/null 2>&1
done

#────────────────────────────────────────────
# FINAL STABILIZATION LAYER
#────────────────────────────────────────────

sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

cmd notification post -S bigtext -t "[ARISE SYSTEM]" "RESTORE" "STATUS: SYSTEM RETURNED TO DEFAULT STATE" >/dev/null 2>&1

echo ""
echo "✔ ARISE RESET COMPLETE"
echo "✔ ALL OPTIMIZATION LAYERS REMOVED"
echo "✔ SYSTEM STABLE MODE ACTIVE"