#!/system/bin/sh
#─────────────────────────────────────────────────────────────
#AUTHOR / CREDITS
#─────────────────────────────────────────────────────────────
#This module is built upon an original performance concept,
#optimization flow, and scripting structure developed by ARISE SYSTEM.
#
#ORIGINAL CONCEPT BY:
#@ariseplugin
#─────────────────────────────────────────────────────────────
#Core implementation includes:
#• ADPF session tuning for performance optimization
#• Frame pacing and refresh rate consistency controls
#• Game Mode FPS enforcement mechanisms
#• Compat change optimizations for supported games
#• Non-root Android performance hint integration
#• Aggressive latency reduction layer (ARISE FLOW ENGINE)
#─────────────────────────────────────────────────────────────

run() {
"$@" >/dev/null 2>&1
}

FPS=$(settings get system peak_refresh_rate 2>/dev/null)

[ -z "$FPS" ] || [ "$FPS" = "null" ] && \
FPS=$(settings get system user_refresh_rate 2>/dev/null)

[ -z "$FPS" ] || [ "$FPS" = "null" ] && FPS=120

FPS=${FPS%.*}

[ "$FPS" -lt 60 ] && FPS=60
[ "$FPS" -gt 144 ] && FPS=144


apply_dc() {
    ns="$1"; key="$2"; val="$3"
    cmd device_config put "$ns" "$key" "$val" 2>/dev/null  
}

#────────────────────────────────────────────
# ARISE AGGRESSIVE FLOW LAYER
#────────────────────────────────────────────

apply_dc game android.os.adpf_predict_frame_time true
apply_dc game android.os.adpf_sustained_performance_mode true
apply_dc game android.os.adpf_hwui_gpu true
apply_dc game android.os.adpf_skip_surface_flinger_sync true

apply_dc core_graphics android.view.flags.set_frame_rate_callback true
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.use_known_refresh_rate_for_fps_consistency true
apply_dc core_graphics com.android.graphics.surfaceflinger.flags.frame_rate_category_mrr true

apply_dc window_surfaces com.android.window.flags.explicit_refresh_rate_hints true
apply_dc window_surfaces com.android.window.flags.enable_buffer_transform_hint_from_display true

apply_dc display_manager com.android.server.display.feature.flags.enable_user_preferred_mode_vote true
apply_dc display_manager com.android.server.display.feature.flags.enable_displays_refresh_rates_synchronization true

#────────────────────────────────────────────
# AGGRESSIVE SYSTEM BOOST (ARISE CORE)
#────────────────────────────────────────────

run settings put global app_standby_enabled 0
run settings put global cached_apps_freezer 0
run settings put global background_process_limit 3

run cmd activity memory-factor set 1

run settings put global window_animation_scale 0
run settings put global transition_animation_scale 0
run settings put global animator_duration_scale 0

setprop debug.hwui.renderer skiaglthreaded
setprop debug.sf.hw 1
setprop debug.composition.type gpu
setprop debug.renderengine.backend skiaglthreaded
setprop debug.hwui.render_dirty_regions false

setprop debug.performance.tuning 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1

# memory flush (aggressive but safe)
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

#────────────────────────────────────────────
# COMPAT + GAME ENGINE LAYER
#────────────────────────────────────────────

run am compat enable 168419799 com.garena.game.codm
run am compat enable 189970036 com.garena.game.codm
run am compat enable 174042980 com.garena.game.codm

run am compat enable 168419799 com.mobile.legends
run am compat enable 174042980 com.mobile.legends

run am compat enable 168419799 com.tencent.ig
run am compat enable 174042980 com.tencent.ig

run am compat enable 168419799 com.roblox.client
run am compat enable 174042980 com.roblox.client

#────────────────────────────────────────────
# GAME MODE FORCE
#────────────────────────────────────────────

run cmd game set --mode 2 --fps "$FPS" com.garena.game.codm
run cmd game mode performance com.garena.game.codm

run cmd game set --mode 2 --fps "$FPS" com.mobile.legends
run cmd game mode performance com.mobile.legends

run cmd game set --mode 2 --fps "$FPS" com.tencent.ig
run cmd game mode performance com.tencent.ig

run cmd game set --mode 2 --fps "$FPS" com.roblox.client
run cmd game mode performance com.roblox.client

#────────────────────────────────────────────
# FINAL ARISE STATUS
#────────────────────────────────────────────

cmd notification post -S bigtext -t "[ARISE FLOW ENGINE]" "ARISE" "STATUS: AGGRESSIVE PERFORMANCE ACTIVE | FPS LOCK: $FPS" > /dev/null 2>&1