#!/system/bin/sh
#─────────────────────────────────────────────────────────────
#                𝗔𝗥𝗜𝗦𝗘 𝗦𝗬𝗦𝗧𝗘𝗠 𝗖𝗢𝗥𝗘
#            𝗣𝗘𝗥𝗙𝗢𝗥𝗠𝗔𝗡𝗖𝗘 𝗢𝗣𝗧𝗜𝗠𝗜𝗭𝗘𝗥
#─────────────────────────────────────────────────────────────
#AUTHOR / CREDITS
#─────────────────────────────────────────────────────────────
#This module is built upon an original performance concept,
#optimization flow, and scripting structure developed by the author.
#
#ORIGINAL CONCEPT BY:
#@ariseplugin
#─────────────────────────────────────────────────────────────
#CORE SYSTEM LAYERS:
#• ADPF session tuning for performance optimization
#• Frame pacing and refresh rate consistency controls
#• Game Mode FPS enforcement mechanisms
#• Compat change optimizations for supported games
#• Non-root Android performance hint integration
#• ARISE FLOW rendering stability engine
#─────────────────────────────────────────────────────────────
#
#DISCLAIMER / USAGE TERMS
#─────────────────────────────────────────────────────────────
#Educational and system-level optimization only.
#No game modification, no asset modification, no bypass.
#Use at your own risk.
#─────────────────────────────────────────────────────────────

#================ COLOR ENGINE =================
RED='\033[1;31m'
CYAN='\033[1;36m'
BLUE='\033[1;34m'
WHITE='\033[1;37m'
GREEN='\033[1;32m'
PURPLE='\033[1;35m'
YELLOW='\033[1;33m'
RESET='\033[0m'

clear

echo -e "${CYAN}────────────────────────────────────${RESET}"
echo -e "${WHITE}        𝗔𝗥𝗜𝗦𝗘 𝗣𝗘𝗥𝗙𝗢𝗥𝗠𝗔𝗡𝗖𝗘 𝗖𝗢𝗥𝗘${RESET}"
echo -e "${PURPLE}         SYSTEM INITIALIZATION${RESET}"
echo -e "${CYAN}────────────────────────────────────${RESET}"
echo ""

echo -e "${GREEN}[✓] ${WHITE}Developer:${RESET} @ariseplugin"
echo -e "${GREEN}[✓] ${WHITE}Status:${RESET} Initializing ARISE FLOW Engine"
echo ""

sleep 0.8

#================ PROGRESS ENGINE =================
i=0
while [ $i -le 100 ]
do
    bar=$(printf "%0.s█" $(seq 1 $((i/10))))
    space=$(printf "%0.s░" $(seq 1 $((10-i/10))))
    echo -e "${CYAN}[${GREEN}${bar}${WHITE}${space}${CYAN}] ${YELLOW}${i}%${RESET}"
    i=$((i+10))
    sleep 0.25
done

echo ""
echo -e "${PURPLE}──────────────────────────────────${RESET}"
echo -e "${WHITE}         APPLYING ARISE TWEAKS${RESET}"
echo -e "${PURPLE}──────────────────────────────────${RESET}"

BASE="$(dirname "$0")"

am kill-all >/dev/null 2>&1

settings put global hidden_api_policy_pre_p_apps 1
settings put global window_animation_scale 0.6
settings put global transition_animation_scale 0.75
settings put global animator_duration_scale 0.6

setprop debug.hwui.renderer skiagl
setprop debug.sf.hw 1
setprop debug.gpud.gl.renderer skiagl
setprop debug.stagefright.renderengine.backend skiagl
setprop debug.hwui.shadow.renderer skiagl
setprop debug.renderengine.backend skiagl

settings put global force_hw_ui 1
setprop debug.composition.type gpu
setprop debug.hwui.render_dirty_regions false

settings put global background_data 0
setprop debug.dumpstate 0

#================ ARISE FLOW BOOST EXTENSION =================
echo -e "${GREEN}[+] ${WHITE}Applying ARISE FLOW Extended Aggressive Layer...${RESET}"

setprop debug.performance.tuning 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1

setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_sf_phase_offset_ns 500000
setprop debug.sf.late_app_phase_offset_ns 1000000
setprop debug.sf.late_sf_phase_offset_ns 1000000

setprop debug.renderengine.backend skiaglthreaded
setprop debug.hwui.use_hint_manager true

settings put system pointer_speed 7
settings put system tap_timeout 80
settings put system long_press_timeout 250

settings put global background_process_limit 3
settings put global app_standby_enabled 0
settings put global cached_apps_freezer 1

sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

sh "$BASE/service.sh"

#================ DEVICE INFO =================
echo ""
echo -e "${CYAN}──────── 𝗗𝗘𝗩𝗜𝗖𝗘 𝗜𝗡𝗙𝗢 ────────${RESET}"
echo -e "${WHITE}MODEL   : $(getprop ro.product.model)${RESET}"
echo -e "${WHITE}BRAND   : $(getprop ro.product.system.brand)${RESET}"
echo -e "${WHITE}DEVICE  : $(getprop ro.build.product)${RESET}"
echo -e "${WHITE}KERNEL  : $(uname -r)${RESET}"
echo -e "${WHITE}GPU     : $(getprop ro.hardware.egl)${RESET}"
echo -e "${WHITE}CPU     : $(getprop ro.hardware)${RESET}"
echo -e "${WHITE}ANDROID : $(getprop ro.build.version.release)${RESET}"
echo -e "${WHITE}RAM     : $(awk '/MemAvailable/ {printf "%.2f", $2/1024/1024}' /proc/meminfo) GB${RESET}"
echo -e "${CYAN}──────────────────────────${RESET}"

sleep 1

#================ FINAL STATUS =================
echo ""
echo -e "${GREEN}────────────────────────────────────${RESET}"
echo -e "${WHITE}        𝗔𝗥𝗜𝗦𝗘 𝗘𝗡𝗚𝗜𝗡𝗘 𝗔𝗖𝗧𝗜𝗩𝗘${RESET}"
echo -e "${GREEN}     SYSTEM OPTIMIZED SUCCESSFULLY${RESET}"
echo -e "${GREEN}────────────────────────────────────${RESET}"