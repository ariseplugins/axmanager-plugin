#!/system/bin/sh

# =========================
# COLOR ENGINE
# =========================
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
NC="\033[0m"

LOG="[ARISE-V2]"

# =========================
# GAME PACKAGE LIST
# =========================
CODM="com.activision.callofduty.shooter"
BLOOD="com.netease.newspike"
PUBG="com.tencent.ig"

LAST_MODE="none"

echo -e "${BLUE}$LOG AUTO DETECT ENGINE RUNNING...${NC}"

while true; do

    CURRENT=$(dumpsys window | grep -E 'mCurrentFocus' | cut -d "/" -f1 | awk '{print $NF}')

    # =========================
    # CODM MODE
    # =========================
    if echo "$CURRENT" | grep -q "$CODM"; then

        if [ "$LAST_MODE" != "codm" ]; then
            echo -e "${GREEN}$LOG CODM DETECTED → STABLE MODE${NC}"

            am kill-all > /dev/null 2>&1
            setprop debug.hwui.renderer skiagl > /dev/null 2>&1

            LAST_MODE="codm"
        fi

    # =========================
    # BLOOD STRIKE MODE
    # =========================
    elif echo "$CURRENT" | grep -q "$BLOOD"; then

        if [ "$LAST_MODE" != "blood" ]; then
            echo -e "${GREEN}$LOG BLOOD STRIKE DETECTED → SMOOTH MODE${NC}"

            am kill-all > /dev/null 2>&1

            LAST_MODE="blood"
        fi

    # =========================
    # PUBG MODE
    # =========================
    elif echo "$CURRENT" | grep -q "$PUBG"; then

        if [ "$LAST_MODE" != "pubg" ]; then
            echo -e "${GREEN}$LOG PUBG DETECTED → BALANCED MODE${NC}"

            am kill-all > /dev/null 2>&1

            LAST_MODE="pubg"
        fi

    else
        if [ "$LAST_MODE" != "idle" ]; then
            echo -e "${YELLOW}$LOG WAITING FOR SUPPORTED GAME...${NC}"
            LAST_MODE="idle"
        fi
    fi

    sleep 15

done