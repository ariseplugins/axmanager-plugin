#!/system/bin/sh

echo "[ARISE-V2] RESTORING DEFAULTS..."

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

sync

echo "[ARISE-V2] MODULE REMOVED"