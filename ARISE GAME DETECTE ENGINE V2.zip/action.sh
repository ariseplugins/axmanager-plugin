#!/system/bin/sh

# =========================
# COLOR ENGINE
# =========================
RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
BLUE="\033[1;34m"
CYAN="\033[1;36m"
NC="\033[0m"

LOG="[ARISE-V2]"

echo -e "${BLUE}$LOG ==================================${NC}"
echo -e "${BLUE}$LOG INITIALIZING GAME DETECT ENGINE${NC}"
echo -e "${BLUE}$LOG ==================================${NC}"

sleep 0.5

# =========================
# DEVICE CHECK
# =========================
echo -e "${YELLOW}$LOG SCANNING DEVICE...${NC}"

MODEL=$(getprop ro.product.model)
DEVICE=$(getprop ro.product.device)
SDK=$(getprop ro.build.version.sdk)

echo "$LOG MODEL: $MODEL"
echo "$LOG DEVICE: $DEVICE"
echo "$LOG SDK: $SDK"

sleep 0.5

if [ "$SDK" -lt 30 ]; then
    echo -e "${RED}$LOG UNSUPPORTED ANDROID VERSION${NC}"
    exit 1
fi

echo -e "${GREEN}$LOG DEVICE VERIFIED${NC}"

# =========================
# DATE CHECK
# =========================
echo -e "${YELLOW}$LOG VALIDATING DATE...${NC}"

DATE_NOW=$(date +"%Y-%m-%d")
HOUR=$(date +"%H")

echo "$LOG DATE: $DATE_NOW"
echo "$LOG HOUR: $HOUR"

# optional active hours logic
if [ "$HOUR" -lt 5 ] || [ "$HOUR" -gt 23 ]; then
    echo -e "${YELLOW}$LOG LOW ACTIVITY PERIOD DETECTED${NC}"
else
    echo -e "${GREEN}$LOG ACTIVE PERIOD CONFIRMED${NC}"
fi

sleep 0.5

# =========================
# BASE ENGINE SETUP
# =========================
echo -e "${CYAN}$LOG APPLYING BASE SYSTEM LAYERS...${NC}"

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

sleep 0.3

echo -e "${CYAN}$LOG APPLYING PERFORMANCE FLAGS...${NC}"

setprop debug.performance.tuning 1 > /dev/null 2>&1
setprop debug.hwui.renderer skiagl > /dev/null 2>&1

sleep 0.3

echo -e "${CYAN}$LOG FINALIZING ENGINE...${NC}"

sync

sleep 0.5

echo -e "${GREEN}$LOG ==================================${NC}"
echo -e "${GREEN}$LOG ENGINE READY - AUTO DETECT ENABLED${NC}"
echo -e "${GREEN}$LOG ==================================${NC}"