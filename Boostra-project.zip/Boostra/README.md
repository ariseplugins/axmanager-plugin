# Boostra
1. Gumawa ng GitHub repo, i-upload ang laman ng folder na ito.
2. Actions tab -> Build APK -> Run workflow.
3. I-download ang artifact Boostra-apk, i-install ang APK.
4. Install + start Shizuku, tapos buksan ang Boostra.
