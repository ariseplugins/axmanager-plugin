package com.boostra.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

val Cy = Color(0xFF22D3EE); val Vi = Color(0xFF8B5CF6); val Bg = Color(0xFF0B0D1A); val Cd = Color(0xFF161A33)
val FPSL = listOf("60", "90", "120", "144"); val GFXL = listOf("Low", "Mid", "High", "Very High", "Max", "Ultra")
val SCL = listOf("0.5", "0.55", "0.6", "0.65", "0.7", "0.75", "0.8", "1.0")

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); P.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Cy, secondary = Vi, background = Bg, surface = Cd, onBackground = Color.White, onSurface = Color.White)) {
            Surface(Modifier.fillMaxSize(), color = Bg) { App(this) } } } }
}

@Composable fun App(a: Activity) {
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { ready = withContext(Dispatchers.IO) { Sh.ok() }; delay(1000) } }
    if (!ready) Gate(a) else Main(a)
}

@Composable fun Gate(a: Activity) {
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("BOOSTRA", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Cy)
        Spacer(Modifier.height(8.dp))
        Text("I-connect muna sa Shizuku. Buksan ang Shizuku, i-start, tapos i-grant ang permission.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (!Sh.alive()) { a.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { a.startActivity(it) } }
            else Shizuku.requestPermission(1)
        }) { Text("Connect Shizuku") }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable fun Chips(items: List<String>, cur: String, on: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items.forEach { FilterChip(selected = it == cur, onClick = { on(it) }, label = { Text(it) }) } }
}

fun launchable(c: Context): List<Pair<String, String>> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }.distinctBy { it.second }.sortedBy { it.first }
}

fun startOverlay(c: Context): Boolean {
    if (!Settings.canDrawOverlays(c)) { c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))); return false }
    c.startForegroundService(Intent(c, OverlayService::class.java)); return true
}

fun launchGame(c: Context, pkg: String) {
    val mode = when (P.gfx) { "Low" -> 3; "Mid", "High" -> 1; else -> 2 }
    Thread { Sh.run("cmd game set --mode $mode --downscale ${P.scale} --fps ${P.fps} $pkg") }.start()
    startOverlay(c)
    c.packageManager.getLaunchIntentForPackage(pkg)?.let { c.startActivity(it) }
}

@Composable fun Main(a: Activity) {
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Mod.startServices(a) } }
    Scaffold(containerColor = Bg, bottomBar = { NavigationBar(containerColor = Cd) {
        listOf("Games", "Booster", "Modules", "Panel").forEachIndexed { i, t -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("🎮", "⚡", "🧩", "🖥")[i]) }, label = { Text(t) }) } } }) { pad ->
        Column(Modifier.padding(pad).padding(14.dp)) { when (tab) { 0 -> Games(a); 1 -> Booster(); 2 -> Modules(a); else -> Panel(a) } }
    }
}

@Composable fun Games(a: Activity) {
    var games by remember { mutableStateOf(P.games.toList()) }; var pick by remember { mutableStateOf(false) }
    val pm = a.packageManager
    Text("Games", fontSize = 28.sp, fontWeight = FontWeight.Bold)
    Text("${P.fps} FPS · ${P.gfx} · ${P.scale}x", color = Cy)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { pick = true }) { Text("+ Add app") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
        items(games) { pkg ->
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            Card(colors = CardDefaults.cardColors(containerColor = Cd)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(label, fontWeight = FontWeight.Bold); Text(pkg, fontSize = 11.sp, color = Color.Gray) }
                Button(onClick = { launchGame(a, pkg) }) { Text("Launch") }
                TextButton(onClick = { P.games = P.games - pkg; games = P.games.toList() }) { Text("✕") } } }
        }
    }
    if (pick) AlertDialog(onDismissRequest = { pick = false }, confirmButton = { TextButton(onClick = { pick = false }) { Text("Close") } },
        title = { Text("Add app") }, text = { LazyColumn { items(launchable(a)) { (n, p) ->
            TextButton(onClick = { P.games = P.games + p; games = P.games.toList(); pick = false }) { Text(n) } } } })
}

@Composable fun Booster() {
    var fps by remember { mutableStateOf(P.fps.toString()) }; var gfx by remember { mutableStateOf(P.gfx) }; var sc by remember { mutableStateOf(P.scale) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Booster", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("FPS", color = Cy); Chips(FPSL, fps) { fps = it; P.fps = it.toInt() }
        Text("Graphics", color = Cy); Chips(GFXL, gfx) { gfx = it; P.gfx = it }
        Text("Downscale", color = Cy); Chips(SCL, sc) { sc = it; P.scale = it }
        Text("Ire-run sa Shizuku:\ncmd game set --mode <mode> --downscale $sc --fps $fps <package>", fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable fun Modules(a: Activity) {
    var tick by remember { mutableStateOf(0) }; var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { msg = withContext(Dispatchers.IO) { try { Mod.install(a, uri) } catch (e: Exception) { "Error: ${e.message}" } }; tick++ } }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Modules", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Button(onClick = { pickZip.launch(arrayOf("application/zip", "application/octet-stream")) }) { Text("Install zip") } }
    val mods = remember(tick) { Mod.list(a) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp)) { items(mods) { m ->
        Card(colors = CardDefaults.cardColors(containerColor = Cd)) { Column(Modifier.padding(12.dp)) {
            val bf = listOf("banner.png", "vanner.png").map { File(m.dir, it) }.firstOrNull { it.exists() }
            val bmp = remember(m.id, tick) { bf?.let { BitmapFactory.decodeFile(it.path) } }
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().height(100.dp).background(Bg, RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
            Text(m.name, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("${m.ver} · ${m.author}", fontSize = 12.sp, color = Color.Gray); Text(m.desc, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(onClick = { scope.launch { msg = withContext(Dispatchers.IO) { Mod.action(m) } } }) { Text("Action") }
                Button(colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4D6D)), onClick = { scope.launch { msg = withContext(Dispatchers.IO) { Mod.uninstall(m) }; tick++ } }) { Text("Uninstall") } } } } } }
    msg?.let { AlertDialog(onDismissRequest = { msg = null }, confirmButton = { TextButton(onClick = { msg = null }) { Text("OK") } }, text = { Text(it, modifier = Modifier.verticalScroll(rememberScrollState())) }) }
}

@Composable fun Panel(a: Activity) {
    var xon by remember { mutableStateOf(P.xon) }; var st by remember { mutableStateOf(P.cross.toString()) }; var col by remember { mutableStateOf(P.ccolor) }; var sz by remember { mutableStateOf(P.csize.toFloat()) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Gaming panel", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Lulutang sa ibabaw ng game. Pindutin ang ⚡ para buksan, i-drag para ilipat.", color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { startOverlay(a) }) { Text("Start overlay") }
            Button(colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4D6D)), onClick = { a.stopService(Intent(a, OverlayService::class.java)) }) { Text("Stop") } }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Crosshair", Modifier.weight(1f)); Switch(checked = xon, onCheckedChange = { xon = it; P.xon = it }) }
        Chips((0..7).map { it.toString() }, st) { st = it; P.cross = it.toInt() }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf(0xFF34E0A1, 0xFFFF4D6D, 0xFFFFD400, 0xFF22D3EE, 0xFFFFFFFF).forEach { c ->
            Box(Modifier.size(36.dp).background(Color(c), RoundedCornerShape(18.dp)).let { it }.then(Modifier)) {
                TextButton(onClick = { col = c.toInt(); P.ccolor = c.toInt() }, modifier = Modifier.fillMaxSize()) { Text(if (col == c.toInt()) "✓" else "", color = Color.Black) } } } }
        Text("Size ${sz.toInt()}"); Slider(value = sz, onValueChange = { sz = it; P.csize = it.toInt() }, valueRange = 16f..80f)
        Text("I-restart ang overlay para ma-apply ang bagong crosshair.", fontSize = 12.sp, color = Color.Gray)
    }
}
