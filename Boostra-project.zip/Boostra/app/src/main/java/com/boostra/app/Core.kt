package com.boostra.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import rikka.shizuku.Shizuku
import java.io.File
import java.util.zip.ZipInputStream

object P {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("boostra", 0) }
    var fps: Int get() = sp.getInt("fps", 120); set(v) = sp.edit().putInt("fps", v).apply()
    var gfx: String get() = sp.getString("gfx", "Ultra")!!; set(v) = sp.edit().putString("gfx", v).apply()
    var scale: String get() = sp.getString("scale", "0.65")!!; set(v) = sp.edit().putString("scale", v).apply()
    var cross: Int get() = sp.getInt("cross", 2); set(v) = sp.edit().putInt("cross", v).apply()
    var ccolor: Int get() = sp.getInt("ccolor", 0xFF34E0A1.toInt()); set(v) = sp.edit().putInt("ccolor", v).apply()
    var csize: Int get() = sp.getInt("csize", 34); set(v) = sp.edit().putInt("csize", v).apply()
    var xon: Boolean get() = sp.getBoolean("xon", true); set(v) = sp.edit().putBoolean("xon", v).apply()
    var games: Set<String> get() = sp.getStringSet("games", emptySet())!!; set(v) = sp.edit().putStringSet("games", v).apply()
}

object Sh {
    fun alive() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun ok() = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 } catch (e: Throwable) { false }
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); out
    } catch (e: Throwable) { "ERR: " + (e.cause?.message ?: e.message) }
}

data class St(val fps: Int, val cpu: Int, val gpu: Int, val ram: Int, val temp: Int)

object Stats {
    private var pt = 0L; private var pi = 0L
    private var pkg = ""; private var layer = ""
    fun read(refreshLayer: Boolean): St {
        val o = Sh.run("head -1 /proc/stat;grep -E 'MemTotal|MemAvailable' /proc/meminfo;echo G;cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null;echo T;cat /sys/class/power_supply/battery/temp 2>/dev/null").lines()
        var cpu = -1
        o.firstOrNull { it.startsWith("cpu") }?.let { l ->
            val n = l.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (n.size >= 5) { val t = n.take(8).sum(); val i = n[3] + n[4]
                if (pt > 0 && t > pt) cpu = (100 * (1 - (i - pi).toDouble() / (t - pt))).toInt().coerceIn(0, 100)
                pt = t; pi = i }
        }
        fun mem(k: String) = o.firstOrNull { it.startsWith(k) }?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
        val tot = mem("MemTotal"); val av = mem("MemAvailable")
        val ram = if (tot > 0) (100 * (tot - av) / tot).toInt() else -1
        val gi = o.indexOf("G"); val ti = o.indexOf("T")
        var gpu = -1
        if (gi >= 0 && ti > gi + 1) { val n = o[gi + 1].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (n.size >= 2 && n[1] > 0) gpu = (100 * n[0] / n[1]).toInt().coerceIn(0, 100) }
        val temp = if (ti >= 0 && ti + 1 < o.size) (o[ti + 1].trim().toIntOrNull() ?: 0) / 10 else -1
        return St(fps(refreshLayer), cpu, gpu, ram, temp)
    }
    private fun fps(refresh: Boolean): Int {
        if (refresh || layer.isEmpty()) {
            val f = Sh.run("dumpsys window | grep -m1 mCurrentFocus")
            pkg = Regex("u0 ([\\w.]+)/").find(f)?.groupValues?.get(1) ?: return -1
            layer = Sh.run("dumpsys SurfaceFlinger --list | grep '$pkg' | tail -1").trim()
        }
        if (layer.isEmpty()) return -1
        val ts = Sh.run("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).mapNotNull {
            it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE }
        if (ts.size < 2 || ts.last() <= ts.first()) return -1
        return ((ts.size - 1) * 1e9 / (ts.last() - ts.first())).toInt()
    }
}

data class M(val dir: File, val id: String, val name: String, val ver: String, val author: String, val desc: String)

object Mod {
    fun root(c: Context) = File(c.getExternalFilesDir(null), "modules").apply { mkdirs() }
    private fun prop(d: File): M? {
        val f = File(d, "module.prop"); if (!f.exists()) return null
        val m = f.readLines().filter { "=" in it }.associate { it.substringBefore("=").trim() to it.substringAfter("=").trim() }
        return M(d, m["id"] ?: d.name, m["name"] ?: d.name, m["version"] ?: "", m["author"] ?: "", m["description"] ?: "")
    }
    fun list(c: Context) = root(c).listFiles()?.filter { it.isDirectory }?.mapNotNull { prop(it) } ?: emptyList()
    private fun sh(d: File, s: String, bg: Boolean = false) =
        Sh.run("cd '${d.path}' && [ -f $s ] && MODPATH='${d.path}' sh ./$s ${if (bg) ">/dev/null 2>&1 &" else "2>&1"}")
    fun install(c: Context, uri: Uri): String {
        val tmp = File(root(c), ".tmp"); tmp.deleteRecursively(); tmp.mkdirs()
        c.contentResolver.openInputStream(uri)!!.use { ins -> ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val out = File(tmp, e.name)
                if (!out.canonicalPath.startsWith(tmp.canonicalPath)) return "Invalid zip"
                if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                e = z.nextEntry
            } } }
        val m = prop(tmp) ?: return "module.prop not found"
        val dest = File(root(c), m.id); dest.deleteRecursively(); tmp.renameTo(dest)
        return "Installed ${m.name}\n" + sh(dest, "customize.sh") + sh(dest, "service.sh", true)
    }
    fun action(m: M) = sh(m.dir, "action.sh").ifBlank { "action.sh finished (no output)" }
    fun uninstall(m: M): String { val r = sh(m.dir, "uninstall.sh"); m.dir.deleteRecursively(); return "Removed ${m.name}\n$r" }
    fun startServices(c: Context) = list(c).forEach { sh(it.dir, "service.sh", true) }
}
