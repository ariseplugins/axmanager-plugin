package com.boostra.app

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import kotlin.math.abs

class CrossView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    override fun onMeasure(w: Int, h: Int) { val s = (P.csize * resources.displayMetrics.density).toInt(); setMeasuredDimension(s, s) }
    override fun onDraw(c: Canvas) {
        val s = width.toFloat(); val m = s / 2; p.color = P.ccolor; p.strokeWidth = s / 20; p.style = Paint.Style.STROKE
        when (P.cross) {
            0 -> { p.style = Paint.Style.FILL; c.drawCircle(m, m, s / 12, p) }
            1 -> { c.drawLine(m, 0f, m, s, p); c.drawLine(0f, m, s, m, p) }
            2 -> { c.drawLine(m, 0f, m, s * .35f, p); c.drawLine(m, s * .65f, m, s, p); c.drawLine(0f, m, s * .35f, m, p); c.drawLine(s * .65f, m, s, m, p) }
            3 -> c.drawCircle(m, m, s * .3f, p)
            4 -> { c.drawCircle(m, m, s * .3f, p); p.style = Paint.Style.FILL; c.drawCircle(m, m, s / 14, p) }
            5 -> { c.drawLine(s * .15f, s * .3f, s * .85f, s * .3f, p); c.drawLine(m, s * .3f, m, s * .9f, p) }
            6 -> { c.drawLine(s * .2f, s * .2f, s * .4f, s * .4f, p); c.drawLine(s * .8f, s * .2f, s * .6f, s * .4f, p); c.drawLine(s * .2f, s * .8f, s * .4f, s * .6f, p); c.drawLine(s * .8f, s * .8f, s * .6f, s * .6f, p) }
            else -> { c.drawRect(s * .2f, s * .2f, s * .8f, s * .8f, p); p.style = Paint.Style.FILL; c.drawCircle(m, m, s / 16, p) }
        }
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: View? = null; private var cross: View? = null
    @Volatile private var alive = true
    private var rec = false
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("b", "Boostra", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "b").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Boostra overlay running").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        if (root == null) build()
        return START_STICKY
    }

    private fun lp(touch: Boolean) = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT)

    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun tv(t: String, sz: Float = 12f) = TextView(this).apply { text = t; textSize = sz; setTextColor(Color.WHITE); setPadding(dp(8), dp(4), dp(8), dp(4)) }
        val stats = tv("FPS -- | CPU -- | GPU -- | RAM -- | --°C").apply { setTextColor(0xFF22D3EE.toInt()); typeface = Typeface.DEFAULT_BOLD }
        val bubble = tv("⚡", 20f)
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        fun btn(t: String, f: () -> Unit) = tv(t, 18f).apply { setOnClickListener { f() } }
        val sb = SeekBar(this).apply { max = 255; progress = 120; layoutParams = LinearLayout.LayoutParams(dp(110), -2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { val v = progress; Thread { Sh.run("settings put system screen_brightness_mode 0;settings put system screen_brightness $v") }.start() } }) }
        body.addView(stats)
        body.addView(btn("📸") { Thread { val f = "/sdcard/Pictures/Boostra_${System.currentTimeMillis()}.png"; Sh.run("screencap -p $f"); toast("Saved $f") }.start() })
        body.addView(btn("⏺") { if (!rec) { rec = true; toast("Recording…"); Thread { Sh.run("screenrecord --time-limit 180 /sdcard/Movies/Boostra_${System.currentTimeMillis()}.mp4"); rec = false }.start() }
            else Thread { Sh.run("pkill -2 screenrecord"); toast("Recording saved") }.start() })
        body.addView(btn("✛") { P.xon = !P.xon; syncCross() })
        body.addView(sb)
        body.addView(btn("✕") { stopSelf() })
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(0xE6161A33.toInt()); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0xFF22D3EE.toInt()) }
            addView(bubble); addView(body) }
        val p = lp(true).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(40) }
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> { val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true; p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(r, p) }
                    MotionEvent.ACTION_UP -> if (!moved) body.visibility = if (body.visibility == View.GONE) View.VISIBLE else View.GONE
                }
                return true } })
        wm.addView(r, p); root = r; syncCross()
        Thread { var n = 0
            while (alive) {
                if (body.visibility == View.VISIBLE) {
                    val s = Stats.read(n++ % 5 == 0)
                    fun f(v: Int) = if (v < 0) "--" else "$v"
                    stats.post { stats.text = "FPS ${f(s.fps)} | CPU ${f(s.cpu)}% | GPU ${f(s.gpu)}% | RAM ${f(s.ram)}% | ${f(s.temp)}°C" }
                }
                Thread.sleep(1000)
            } }.start()
    }

    private fun syncCross() = Handler(Looper.getMainLooper()).post {
        cross?.let { wm.removeView(it); cross = null }
        if (P.xon) { val v = CrossView(this); wm.addView(v, lp(false).apply { gravity = Gravity.CENTER }); cross = v }
    }
    private fun toast(t: String) = Handler(Looper.getMainLooper()).post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

    override fun onDestroy() {
        alive = false
        try { root?.let { wm.removeView(it) }; cross?.let { wm.removeView(it) } } catch (e: Exception) {}
        super.onDestroy()
    }
}
