#!/system/bin/sh

# =========================================
# ARISE PERFORMANCE ENGINE - RESTORE
# =========================================

LOG="/sdcard/arise_restore.log"

log() {
    echo "[ARISE RESTORE] $1" | tee -a "$LOG"
}

log "Starting restore process..."

# =========================
# REFRESH RATE RESET
# =========================
settings delete system min_refresh_rate 2>/dev/null
settings delete system peak_refresh_rate 2>/dev/null
settings delete global peak_refresh_rate 2>/dev/null
settings delete global user_refresh_rate 2>/dev/null
settings delete global refresh_rate_switching 2>/dev/null

log "Refresh rate settings restored"

# =========================
# ANIMATION RESET
# =========================
settings put global animator_duration_scale 1
settings put global transition_animation_scale 1
settings put global window_animation_scale 1

log "Animation scale restored"

# =========================
# GPU / HWUI RESET
# =========================
setprop debug.hwui.renderer ""
setprop debug.egl.hw 0
setprop debug.sf.hw 0
setprop debug.composition.type ""
setprop persist.sys.composition.type ""
setprop debug.performance.tuning 0

log "GPU rendering properties restored"

# =========================
# FRAME STABILITY RESET
# =========================
setprop debug.sf.latch_unsignaled 0
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.use_buffer_age true

log "Frame pipeline restored"

# =========================
# TOUCH RESET
# =========================
setprop persist.sys.real_touch_boost 0
setprop debug.sf.touch_trace_enabled 0
settings put system pointer_speed 0

log "Touch response restored"

# =========================
# CPU / GPU BALANCE RESET
# =========================
setprop debug.hwui.render_priority normal
setprop debug.rs.max-threads 4
setprop debug.rs.min-threads 1

log "Thread configuration restored"

# =========================
# POWER RESET
# =========================
cmd power set-fixed-performance-mode-enabled false 2>/dev/null
cmd power set-adaptive-power-saver-enabled true 2>/dev/null

settings delete secure game_no_interruption 2>/dev/null
settings delete secure game_auto_temperature_control 2>/dev/null

log "Power configuration restored"

# =========================
# GAME DRIVER RESET
# =========================
settings delete global game_driver_all_apps 2>/dev/null
settings delete global game_mode 2>/dev/null

log "Game driver restored"

# =========================
# SURFACEFLINGER RESET
# =========================
setprop debug.sf.use_frame_rate_priority 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 0
setprop debug.sf.high_fps_late_app_phase_offset_ns 0

log "SurfaceFlinger restored"

# =========================
# VULKAN / SKIA RESET
# =========================
setprop debug.hwui.use_vulkan false
setprop debug.hwui.use_gpu_pixel_buffers false

log "Renderer configuration restored"

# =========================
# GAME OVERLAY RESET
# =========================
device_config delete game_overlay com.garena.game.codm 2>/dev/null
device_config delete game_overlay com.netease.newspike 2>/dev/null

cmd game reset com.garena.game.codm 2>/dev/null
cmd game reset com.netease.newspike 2>/dev/null

log "Game overlays removed"

# =========================
# CACHE / MEMORY RESET
# =========================
settings put global cached_apps_freezer enabled
settings put global app_standby_enabled 1

log "Memory management restored"

# =========================
# FINAL STATUS
# =========================
log "Restore completed successfully"
log "Device returned to default configuration"

echo ""
echo "========================================"
echo " ARISE RESTORE COMPLETED"
echo " SYSTEM BACK TO DEFAULT STATE"
echo "========================================"
echo ""