#!/system/bin/sh

# =========================================
# ARISE SYSTEM - GPU PERFORMANCE ENGINE
# Advanced Flashing Interface
# =========================================

# =========================
# COLOR SYSTEM
# =========================
GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
WHITE="\033[1;37m"
RED="\033[1;31m"
BLUE="\033[1;34m"
RESET="\033[0m"

# =========================
# LOGCAT BUFFER
# =========================
a=$(awk '/MemTotal/ {printf"%.0f\n",$2/1024/1024}' /proc/meminfo)
logcat -G "$a"m

# =========================
# AXERON DETECTION
# =========================
if [ "$AXERON" == "true" ]; then
    PRINT="printf"
else
    PRINT="ui_print"
fi

# =========================
# PRINT ENGINE
# =========================
print_msg() {
    case "$PRINT" in
        ui_print) ui_print "$1" ;;
        printf) printf "$1" ;;
    esac
}

line() {
    ui_print "========================================"
}

# =========================
# STORAGE TRIM
# =========================
trim_partition() {
    setsid sh -c '
    for partition in data cache metadata storage; do
        if command -v su >/dev/null; then
            fstrim -v "/$partition"
        else
            sm fstrim "/$partition"
        fi
    done
    ' >/dev/null 2>&1 &
}

# =========================
# DEVICE INFO
# =========================
ANDROIDVERSION=$(getprop ro.build.version.release)
DEVICES=$(getprop ro.product.board)
MANUFACTURER=$(getprop ro.product.manufacturer)
API=$(getprop ro.build.version.sdk)

NAME="ARISE GPU PERFORMANCE ENGINE"
VERSION="VIP EDITION"

# =========================
# HEADER
# =========================
ui_print ""
line
print_msg "        ARISE PERFORMANCE ENGINE"
print_msg "           GPU BOOST SYSTEM"
line
ui_print ""

sleep 0.3

# =========================
# SYSTEM INFO
# =========================
print_msg "- Engine Name      : ${NAME}"
sleep 0.2

print_msg "- Version          : ${VERSION}"
sleep 0.2

print_msg "- Android Version  : ${ANDROIDVERSION:-Unknown}"
sleep 0.2

print_msg "- API Level        : ${API:-Unknown}"
sleep 0.2

line

print_msg "- Device Board     : ${DEVICES:-Unknown}"
sleep 0.2

print_msg "- Manufacturer     : ${MANUFACTURER:-Unknown}"
sleep 0.2

line

# =========================
# PERFORMANCE INFO
# =========================
print_msg "- Initializing GPU optimization"
sleep 0.5

print_msg "- Stabilizing render pipeline"
sleep 0.5

print_msg "- Improving frame consistency"
sleep 0.5

print_msg "- Optimizing gaming response"
sleep 0.5

print_msg "- Preparing performance layer"
sleep 0.5

line

# =========================
# AXERON SUPPORT
# =========================
[ "${AXERON:-false}" = "true" ] && \
print_msg "- Axeron environment detected"

for f in CRFX; do
    [ -f "$AXERONXBIN/$f" ] || {
        mv -f "$MODPATH/system/bin/$f" "$AXERONXBIN/$f"
        chmod +x "$AXERONXBIN/$f"
    }
done

sleep 1

# =========================
# STORAGE OPTIMIZATION
# =========================
print_msg "- Trimming partitions for better performance"
trim_partition
sleep 2

# =========================
# PERMISSION SYSTEM
# =========================
if command -v su &>/dev/null; then

    print_msg "- Applying permission configuration"

    set_perm_recursive $MODPATH 0 0 0755 0755

    set_perm_recursive \
    $MODPATH/system/etc/init/gpuservice.rc \
    0 0 0755 0755
fi

# =========================
# FINAL STATUS
# =========================
line
print_msg "- ARISE ENGINE SUCCESSFULLY APPLIED"
print_msg "- Device ready for gaming"
line

ui_print ""
print_msg " Developer : ARISE SYSTEM"
print_msg " Telegram  : @ariseplugin"
print_msg " Partner   : @fckstark69"
ui_print ""

# =========================
# CLEAN LOGCAT
# =========================
logcat -c