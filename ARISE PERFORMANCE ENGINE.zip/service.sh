# =========================
# ARISE PERFORMANCE TUNING
# =========================

# FRAME / REFRESH
settings put system min_refresh_rate 90
settings put system peak_refresh_rate 120
settings put global peak_refresh_rate 120
settings put global user_refresh_rate 120
settings put global refresh_rate_switching 1

# ANIMATION SPEED
settings put global animator_duration_scale 0
settings put global transition_animation_scale 0
settings put global window_animation_scale 0

# GPU / HWUI
setprop debug.hwui.renderer skiavk
setprop debug.egl.hw 1
setprop debug.sf.hw 1
setprop debug.composition.type gpu
setprop persist.sys.composition.type gpu
setprop debug.performance.tuning 1

# FRAME STABILITY
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.use_buffer_age false

# TOUCH RESPONSE
setprop persist.sys.real_touch_boost 1
setprop debug.sf.touch_trace_enabled 1
settings put system pointer_speed 7

# CPU / GPU BALANCE
setprop debug.hwui.render_priority high
setprop debug.rs.max-threads 8
setprop debug.rs.min-threads 4

# GAME MODE
cmd power set-fixed-performance-mode-enabled true 2>/dev/null
cmd power set-adaptive-power-saver-enabled false 2>/dev/null

settings put secure game_no_interruption 1
settings put secure game_auto_temperature_control 0

# GAME DRIVER
settings put global game_driver_all_apps 1
settings put global game_mode 2

# SURFACEFLINGER
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000

# VULKAN / SKIA
setprop debug.hwui.use_vulkan true
setprop debug.hwui.use_gpu_pixel_buffers true

# GAME OVERLAY
device_config put game_overlay com.garena.game.codm \
mode=2,fps=90:mode=3,fps=30

device_config put game_overlay com.netease.newspike \
mode=2,fps=90:mode=3,fps=30

# GAME COMPILATION
cmd package compile -m speed --check-prof true \
com.garena.game.codm

cmd package compile -m speed --check-prof true \
com.netease.newspike

# CACHE / MEMORY
settings put global cached_apps_freezer enabled
settings put global app_standby_enabled 0