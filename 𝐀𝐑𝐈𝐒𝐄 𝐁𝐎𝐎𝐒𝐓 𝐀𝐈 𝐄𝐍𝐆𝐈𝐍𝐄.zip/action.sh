#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#            𝐀𝐑𝐈𝐒𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐂𝐎𝐑𝐄
#        PERFORMANCE + BOOST ANALYZER
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INK='\033[38;5;81m'
NEON='\033[38;5;51m'
VIOLET='\033[38;5;135m'
SOFT='\033[38;5;245m'
GOLD='\033[38;5;220m'
WHITE='\033[1;37m'
DIM='\033[2m'
GREEN='\033[1;92m'
BLUE='\033[1;94m'
RED='\033[1;91m'
RESET='\033[0m'

clear

echo -e "${NEON}╔══════════════════════════════════════╗${RESET}"
echo -e "${NEON}║         𝐀𝐑𝐈𝐒𝐄 𝐏𝐄𝐑𝐅𝐎𝐑𝐌𝐀𝐍𝐂𝐄 𝐀𝐈         ║${RESET}"
echo -e "${NEON}║        BOOST SERVICE ANALYZER       ║${RESET}"
echo -e "${NEON}║      ARISE SYSTEM CORE v3.0        ║${RESET}"
echo -e "${NEON}╚══════════════════════════════════════╝${RESET}"
echo ""

#━━━━━━━━ SERVICE CHECK ━━━━━━━━
[ -n "$(pgrep -f noop.sh)" ] && \
echo -e "${GREEN}[✓] ${WHITE}bBoost Service is running${RESET}" || \
echo -e "${RED}[X] ${WHITE}bBoost not running${RESET}"

kasane -a >/dev/null && \
echo -e "${GREEN}[✓] ${WHITE}DDload Detected !${RESET}" || \
echo -e "${RED}[X] ${WHITE}Can't Run BBoost ! DDload not found${RESET}"

echo ""

#━━━━━━━━ CONFIG PATH DETECTOR ━━━━━━━━
ls /sdcard/Btool/bin/config.ini >/dev/null && DIR="/sdcard/Btool" || DIR=$(cd "$(dirname "$0")" && pwd)
CONFIG_FILE="$DIR/bin/config.ini"

echo -e "${VIOLET}[ARISE] ${WHITE}Config Path Loaded:${RESET} ${SOFT}$CONFIG_FILE${RESET}"
echo ""

#━━━━━━━━ CONFIG READER ━━━━━━━━
read_config() {
   while IFS='=' read -r lowkey value; do
      [ -z "$lowkey" ] || [ "${lowkey###}" != "$lowkey" ] && continue
      lowkey=$(echo "$lowkey" | tr -d '[:space:]')
      case "$lowkey" in
         game) game="$value" ;;
      esac
   done < "$CONFIG_FILE"
}

read_config

#━━━━━━━━ GAME PROFILE ━━━━━━━━
echo -e "${GOLD}╔══════════════════════════════════════╗${RESET}"
echo -e "${GOLD}║        𝐀𝐑𝐈𝐒𝐄 𝐆𝐀𝐌𝐄 𝐏𝐑𝐎𝐅𝐈𝐋𝐄         ║${RESET}"
echo -e "${GOLD}╚══════════════════════════════════════╝${RESET}"
echo ""

echo -e "${WHITE}Listed Game : ${GREEN}$game${RESET}"
echo ""

echo -e "${DIM}Scanning installed packages...${RESET}"
echo ""

echo -e "${BLUE}Existed list:${RESET}"
cmd package list packages | cut -d: -f2 | grep -Ew "$(echo $game | sed 's/ /|/g')"

echo ""

#━━━━━━━━ SYSTEM NOTES ━━━━━━━━
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}This plugin is designed for performance & adaptive gaming mode${RESET}"
echo -e "${DIM}Warning: may increase battery usage and device temperature during gameplay${RESET}"
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

#━━━━━━━━ CONTACT / BRANDING ━━━━━━━━
echo -e "${WHITE}Developer Support:${RESET}"
echo -e "${GREEN}@ariseplugin${RESET}"
echo -e "${GREEN}@fckstark69${RESET}"
echo ""