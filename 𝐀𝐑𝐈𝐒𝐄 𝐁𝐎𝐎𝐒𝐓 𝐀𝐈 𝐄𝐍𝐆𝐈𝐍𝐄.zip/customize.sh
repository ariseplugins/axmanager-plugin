#!/system/bin/sh

#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#        𝐀𝐑𝐈𝐒𝐄 𝐁𝐑𝐀𝐍𝐃𝐈𝐍𝐆 𝐋𝐀𝐘𝐄𝐑
#      SYSTEM INSTALLER + BOOST MODULE
#━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INK='\033[38;5;81m'
NEON='\033[38;5;51m'
VIOLET='\033[38;5;135m'
SOFT='\033[38;5;245m'
GOLD='\033[38;5;220m'
WHITE='\033[1;37m'
DIM='\033[2m'
GREEN='\033[1;92m'
BLUE='\033[1;94m'
RED='\033[1;91m'
RESET='\033[0m'

clear

echo -e "${NEON}╔══════════════════════════════════════╗${RESET}"
echo -e "${NEON}║         𝐀𝐑𝐈𝐒𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐈𝐍𝐒𝐓𝐀𝐋𝐋𝐄𝐑         ║${RESET}"
echo -e "${NEON}║        PRISMATIC MODULE DEPLOY      ║${RESET}"
echo -e "${NEON}╚══════════════════════════════════════╝${RESET}"
echo ""

echo -e "${DIM}[ARISE] Preparing installation environment...${RESET}"
echo -e "${DIM}[ARISE] Checking storage access...${RESET}"
echo ""

#━━━━━━━━ SCRIPT SOURCE PATH ━━━━━━━━
echo -e "${VIOLET}[ARISE]${WHITE} Setting up Btool directory...${RESET}"

ls /sdcard/Btool >/dev/null || mkdir /sdcard/Btool
cp $MODPATH/Prismatic_Slime.png /sdcard/Btool
ls /sdcard/Btool/bin/config.ini >/dev/null || cp -r $MODPATH/bin /sdcard/Btool

echo -e "${GREEN}[✓] ${WHITE}Files deployed successfully${RESET}"
echo ""

#━━━━━━━━ MODULE INFO DISPLAY ━━━━━━━━
ui_print "╔══════════════════════════════════════╗"
ui_print "║        ARISE BOOST INSTALLER        ║"
ui_print "║      PRISMATIC SLIME ENGINE         ║"
ui_print "╚══════════════════════════════════════╝"

ui_print ""
ui_print "BBoost stable[26102025]

Changelog :
- Speedmode [MIUI]
- Added sysprop tweaks
- Apply Driver app game
- Auto Preload with CVP function [install jbox]
- Added battery performance [MIUI]
- Optimized for stable performance

Cr : @ariseplugin @fckstark69"

echo ""
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${WHITE}ARISE STATUS: INSTALLATION COMPLETE${RESET}"
echo -e "${GREEN}MODULE READY FOR DEPLOYMENT${RESET}"
echo -e "${NEON}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""