#!/system/bin/sh

# ARISE OWNER - AI PERFORMANCE TUNER SERVICE (MLBB)
# Background Optimization Engine v2

CONFIG_DIR="/data/local/tmp/ai_tuner_mlbb"
LOG_FILE="$CONFIG_DIR/service.log"

mkdir -p "$CONFIG_DIR"
echo "$(date): ARISE AI SERVICE started" > "$LOG_FILE"

# ============================================
# CODM PACKAGE LIST
# ============================================MLBB="com.mobile.legends"
MLBB_GLOBAL="com.mobile.legends"
MLBB_CHINA="com.tencent.tmgp.sgame"
MLBB_BETA="com.mobile.legends.beta"
MLBB_VNG="com.mobile.legends.vn"


# ============================================
# WAIT BOOT COMPLETION
# ============================================
wait_for_boot() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 2
    done
}

# ============================================
# CHECK GAME RUNNING
# ============================================
is_mlbb_running() {
    for pkg in $MLBB; do
        if pgrep -f "$pkg" >/dev/null 2>&1; then
            echo "$pkg"
            return 0
        fi
    done
    return 1
}

# ============================================
# LOAD SETTINGS
# ============================================
load_settings() {
    DOWNSCALE=1
    VULKAN=1
    FPS_STAB=1
    GPU_OPT=1

    [ -f "$CONFIG_DIR/settings.txt" ] && . "$CONFIG_DIR/settings.txt"
}

# ============================================
# SAVE RESOLUTION
# ============================================
save_res() {
    if [ ! -f "$CONFIG_DIR/original_res.txt" ]; then
        wm size 2>/dev/null | grep "Physical size" | cut -d':' -f2 | xargs > "$CONFIG_DIR/original_res.txt"
    fi
}

# ============================================
# APPLY DOWNSCALE
# ============================================
apply_downscale() {
    [ "$DOWNSCALE" != "1" ] && return

    RES=$(wm size 2>/dev/null | grep "Physical size" | cut -d':' -f2 | xargs)
    [ -z "$RES" ] && return

    W=$(echo $RES | cut -d'x' -f1)
    H=$(echo $RES | cut -d'x' -f2)

    NW=$((W * 65 / 100))
    NH=$((H * 65 / 100))

    wm size ${NW}x${NH} 2>/dev/null
    echo "$(date): Downscale applied ${NW}x${NH}" >> "$LOG_FILE"
}

# ============================================
# RESTORE RESOLUTION
# ============================================
restore_res() {
    [ -f "$CONFIG_DIR/original_res.txt" ] || return
    ORIG=$(cat "$CONFIG_DIR/original_res.txt")
    wm size $ORIG 2>/dev/null
    echo "$(date): Restored $ORIG" >> "$LOG_FILE"
}

# ============================================
# GPU / RENDER OPT
# ============================================
gpu_opt() {
    [ "$GPU_OPT" != "1" ] && return

    setprop debug.hwui.renderer opengl 2>/dev/null
    setprop debug.sf.hw 1 2>/dev/null
    setprop debug.composition.type gpu 2>/dev/null
}

# ============================================
# VULKAN / GAME DRIVER
# ============================================
game_driver() {
    [ "$VULKAN" != "1" ] && return

    setprop debug.vulkan.enable 1 2>/dev/null
    setprop debug.angle.backend vulkan 2>/dev/null
    setprop persist.graphics.game_driver 1 2>/dev/null
}

# ============================================
# FPS STABILIZER
# ============================================
fps_fix() {
    [ "$FPS_STAB" != "1" ] && return

    settings put system peak_refresh_rate 120 2>/dev/null
    settings put system min_refresh_rate 60 2>/dev/null
    setprop debug.egl.swapinterval 0 2>/dev/null
}

# ============================================
# MAIN LOOP
# ============================================
main() {
    wait_for_boot
    sleep 5

    save_res
    load_settings

    local ACTIVE=0

    while true; do
        load_settings

        if is_mlbb_running >/dev/null; then
            if [ "$ACTIVE" -eq 0 ]; then
                ACTIVE=1
                echo "$(date): MLBB detected - optimizing" >> "$LOG_FILE"

                apply_downscale
                game_driver
                fps_fix
                gpu_opt
            fi
        else
            if [ "$ACTIVE" -eq 1 ]; then
                ACTIVE=0
                echo "$(date): mlbb closed - restore" >> "$LOG_FILE"
                restore_res
            fi
        fi

        sleep 3
    done
}

main &