#!/system/bin/sh

# ARISE OWNER - AI PERFORMANCE TUNER (CODM)
# Installation Script v1.0

MOD_NAME="ARISE AI PERFORMANCE TUNER (MLBB)"
MOD_VER="V2.0"

ui_print "**********************************************"
ui_print "      $MOD_NAME"
ui_print "                BY ARISE OWNER               "
ui_print "**********************************************"
ui_print " "
ui_print "🎯 Target: Mobile Legend Bang Bang Optimization"
ui_print "⚡ Features Enabled:"
ui_print "   • Adaptive Render Scaling (0.65 Mode)"
ui_print "   • Vulkan / Game Driver Optimization"
ui_print "   • AI Frame Stabilization Layer"
ui_print "   • Smart Game Process Detection"
ui_print " "
ui_print "📱 Device Mode: Universal Android Support"
ui_print " "
ui_print "⚙️ Installing System Components..."

# Permissions setup
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm_recursive $MODPATH/webroot 0 0 0755 0644

# Config directory
mkdir -p /data/local/tmp/ai_tuner_mlbb

ui_print " "
ui_print "✅ INSTALLATION COMPLETE"
ui_print "🔄 Reboot required to activate module"
ui_print " "
ui_print "After reboot:"
ui_print "   • Background service auto-starts"
ui_print "   • Configure via AxManager WebUI"