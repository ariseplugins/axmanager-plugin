#!/system/bin/sh

MODDIR=${0%/*}
LOG="/sdcard/arise_nexus_service.log"

log() {
  echo "[NEXUS SERVICE] $1" | tee -a "$LOG"
}

log "===================================="
log "ARISE NEXUS CORE SERVICE BOOTING"
log "===================================="

# WAIT FOR FULL BOOT
log "Waiting for system boot completion..."
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

sleep 5
log "System boot completed successfully"

# STABILIZATION PHASE
log "System stabilization phase..."
sleep 3

# ENVIRONMENT CHECK
log "Checking system environment..."

for cmdcheck in sh settings cmd pm; do
  if command -v $cmdcheck >/dev/null 2>&1; then
    log "$cmdcheck : OK"
  else
    log "$cmdcheck : MISSING"
  fi
done

# START ENGINE
log "Launching NEXUS CORE engine..."

if [ -f "$MODDIR/action.sh" ]; then
  nohup sh "$MODDIR/action.sh" >/dev/null 2>&1 &
  log "Engine started successfully"
else
  log "ERROR: action.sh not found"
fi

# SERVICE MONITOR LOOP
log "Starting service monitor loop..."

while true; do
  BOOT=$(getprop sys.boot_completed)

  if [ "$BOOT" != "1" ]; then
    log "Boot lost, waiting recovery..."
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
      sleep 5
    done
    log "Boot restored"
  fi

  log "Service heartbeat OK"
  sleep 60
done