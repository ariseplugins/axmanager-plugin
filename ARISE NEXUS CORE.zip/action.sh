#!/system/bin/sh

LOG="/sdcard/arise_nexus_core.log"

log() {
  echo "[NEXUS CORE] $1" | tee -a "$LOG"
}

log "=============================="
log "NEXUS CORE ENGINE STARTED"
log "=============================="

# DEVICE INFO
MODEL=$(getprop ro.product.model)
BRAND=$(getprop ro.product.brand)
ANDROID=$(getprop ro.build.version.release)
RAM=$(grep MemTotal /proc/meminfo | awk '{print $2}')

log "Device Info:"
log "Brand: $BRAND"
log "Model: $MODEL"
log "Android: $ANDROID"
log "RAM: $RAM KB"

# PERFORMANCE CLASSIFICATION
if [ "$RAM" -ge 8000000 ]; then
  PROFILE="ULTRA PERFORMANCE"
  FPS=120
  SCALE=0.75
elif [ "$RAM" -ge 6000000 ]; then
  PROFILE="BALANCED PERFORMANCE"
  FPS=90
  SCALE=0.60
elif [ "$RAM" -ge 4000000 ]; then
  PROFILE="STABLE PERFORMANCE"
  FPS=60
  SCALE=0.50
else
  PROFILE="LOW-END OPTIMIZED"
  FPS=45
  SCALE=0.45
fi

log "Profile Selected: $PROFILE"
log "FPS Target: $FPS"
log "Downscale Factor: $SCALE"

# UI OPTIMIZATION LAYER
log "Applying UI optimization..."
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# DISPLAY OPTIMIZATION
log "Applying display tuning..."
settings put system peak_refresh_rate $FPS 2>/dev/null
settings put system min_refresh_rate $FPS 2>/dev/null

setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.hwui.renderer skiagl 2>/dev/null

# MEMORY OPTIMIZATION
log "Optimizing memory system..."
settings put global app_standby_enabled 0
settings put global cached_apps_freezer 1
cmd activity memory-factor set 0 2>/dev/null

# TOUCH RESPONSE
log "Boosting touch response..."
settings put system pointer_speed 7

[ -e /sys/module/msm_performance/parameters/touchboost ] && \
echo 1 > /sys/module/msm_performance/parameters/touchboost 2>/dev/null

# GAME MODE SYSTEM
log "Enabling game system..."
settings put global game_driver_all_apps 1
settings put global game_mode 2

# GAME OPTIMIZATION LOOP
log "Applying per-app optimization..."

APP_COUNT=0

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do

  cmd game mode performance "$pkg" 2>/dev/null
  device_config put game_overlay "$pkg" mode=2,downscaleFactor=$SCALE,fps=$FPS 2>/dev/null

  APP_COUNT=$((APP_COUNT + 1))
  log "Optimized [$APP_COUNT]: $pkg"

done

# CLEAN SYSTEM CACHE
log "Cleaning system cache..."
pm trim-caches 32G 2>/dev/null
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

# FINAL STATUS
log "===================================="
log "NEXUS CORE ENGINE ACTIVE"
log "PROFILE: $PROFILE"
log "FPS: $FPS | SCALE: $SCALE"
log "APPS OPTIMIZED: $APP_COUNT"
log "===================================="