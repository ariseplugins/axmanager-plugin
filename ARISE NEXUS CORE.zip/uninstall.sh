#!/system/bin/sh

log() {
  echo "[NEXUS REMOVE] $1"
}

log "Restoring system defaults..."

settings put global window_animation_scale 1
settings put global transition_animation_scale 1
settings put global animator_duration_scale 1

settings put system peak_refresh_rate 60 2>/dev/null
settings put system min_refresh_rate 60 2>/dev/null

settings put global app_standby_enabled 1
cmd activity memory-factor set 1 2>/dev/null

settings put global game_driver_all_apps 0
settings put global game_mode 0

for pkg in $(cmd package list packages -3 | cut -f2 -d:); do
  cmd game mode none "$pkg" 2>/dev/null
done

echo 3 > /proc/sys/vm/drop_caches 2>/dev/null

log "System fully restored"